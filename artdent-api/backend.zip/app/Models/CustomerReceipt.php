<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CustomerReceipt extends Model
{
    use SoftDeletes;

    protected $table = 'customer_receipts';

    protected $fillable = [
        'company_id',
        'customer_id',
        'user_id',
        'receipt_number',
        'receipt_date',
        'type',
        'amount_cash',
        'amount_transfer',
        'amount_check',
        'amount_card',
        'total',
        'check_number',
        'check_bank',
        'check_due_date',
        'account_name',
        'reference',
        'note',
        'ledger_entry_id',
    ];

    protected $casts = [
        'receipt_date'    => 'date:Y-m-d',
        'check_due_date'  => 'date:Y-m-d',
        'amount_cash'     => 'decimal:2',
        'amount_transfer' => 'decimal:2',
        'amount_check'    => 'decimal:2',
        'amount_card'     => 'decimal:2',
        'total'           => 'decimal:2',
    ];

    // ─── Relaciones ───────────────────────────────────────────────────────────

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function ledgerEntry()
    {
        return $this->belongsTo(LedgerEntry::class);
    }

    // ─── Scopes ──────────────────────────────────────────────────────────────

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id', $companyId);
    }

    public function scopeFilters($query, array $filters)
    {
        if (! empty($filters['customer_id'])) {
            $query->where('customer_id', $filters['customer_id']);
        }
        if (! empty($filters['type'])) {
            $query->where('type', $filters['type']);
        }
        if (! empty($filters['payment_method'])) {
            // Filtrar por medio de pago predominante
            match ($filters['payment_method']) {
                'Efectivo'      => $query->where('amount_cash', '>', 0),
                'Transferencia' => $query->where('amount_transfer', '>', 0),
                'Cheque'        => $query->where('amount_check', '>', 0),
                default         => null,
            };
        }
        if (! empty($filters['from'])) {
            $query->whereDate('receipt_date', '>=', $filters['from']);
        }
        if (! empty($filters['to'])) {
            $query->whereDate('receipt_date', '<=', $filters['to']);
        }
        if (! empty($filters['search'])) {
            $term = $filters['search'];
            $query->where(function ($q) use ($term) {
                $q->whereHas('customer', fn ($c) => $c->where('name', 'like', "%{$term}%"))
                  ->orWhere('receipt_number', 'like', "%{$term}%")
                  ->orWhere('reference',      'like', "%{$term}%")
                  ->orWhere('note',           'like', "%{$term}%");
            });
        }
        return $query;
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    /**
     * Determina el medio de pago principal para display en tabla.
     */
    public function getTipoPaymentAttribute(): string
    {
        if ($this->amount_cash > 0 && $this->amount_check > 0)     return 'Mixto';
        if ($this->amount_cash > 0 && $this->amount_transfer > 0)  return 'Mixto';
        if ($this->amount_check > 0)                                return 'Cheque';
        if ($this->amount_transfer > 0)                             return 'Transferencia';
        if ($this->amount_card > 0)                                 return 'Tarjeta';
        return 'Efectivo';
    }

    /**
     * Genera el próximo número de recibo para una empresa.
     */
    public static function nextReceiptNumber(int $companyId): string
    {
        $last = static::where('company_id', $companyId)
                      ->withTrashed()
                      ->orderByDesc('id')
                      ->value('receipt_number');

        if (! $last) return 'RC-0001';

        $num = (int) preg_replace('/\D/', '', $last);
        return 'RC-' . str_pad($num + 1, 4, '0', STR_PAD_LEFT);
    }
}
