<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * LedgerEntry — Movimiento individual en el libro mayor.
 * Tabla: ledger_entries (ya existe en DB)
 *  ledger_id | entry_date | type (debit|credit) | amount | balance_after
 *  reference_type | reference_id | note
 */
class LedgerEntry extends Model
{
    protected $table = 'ledger_entries';

    protected $fillable = [
        'ledger_id',
        'entry_date',
        'type',
        'amount',
        'balance_after',
        'reference_type',
        'reference_id',
        'note',
    ];

    protected $casts = [
        'entry_date'    => 'date:Y-m-d',
        'amount'        => 'decimal:2',
        'balance_after' => 'decimal:2',
    ];

    // ─── Relaciones ───────────────────────────────────────────────────────────

    public function ledger()
    {
        return $this->belongsTo(Ledger::class);
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    /**
     * Concepto legible según reference_type.
     */
    public function getConceptoAttribute(): string
    {
        return match ($this->reference_type) {
            'job'              => 'Trabajo Lab',
            'customer_receipt' => $this->type === 'credit' ? 'Pago Efectivo' : 'Nota Débito',
            'sale'             => 'Venta Insumos',
            'invoice'          => 'Factura',
            default            => ucfirst($this->reference_type ?? $this->note ?? '—'),
        };
    }

    /**
     * Debe / Haber para display en resumen_cta.
     * Convención: debit → el cliente debe (carga), credit → abona.
     */
    public function getDebeAttribute(): float
    {
        return $this->type === 'debit' ? (float) $this->amount : 0.0;
    }

    public function getHaberAttribute(): float
    {
        return $this->type === 'credit' ? (float) $this->amount : 0.0;
    }

    /**
     * Saldo para display: balance_after muestra cuánto debe el cliente.
     * Negativo = debe, positivo = a favor.
     */
    public function getSaldoAttribute(): float
    {
        return (float) $this->balance_after;
    }
}
