<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Ledger — Libro mayor por cliente o proveedor.
 * Tabla: ledgers (ya existe en DB)
 *  company_id | party_type (customer|vendor) | party_id | currency
 */
class Ledger extends Model
{
    protected $table = 'ledgers';

    protected $fillable = [
        'company_id',
        'party_type',
        'party_id',
        'currency',
    ];

    // ─── Relaciones ───────────────────────────────────────────────────────────

    public function entries()
    {
        return $this->hasMany(LedgerEntry::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'party_id')
                    ->where('party_type', 'customer');
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    /**
     * Obtiene o crea el ledger de un cliente.
     */
    public static function forCustomer(int $companyId, int $customerId): self
    {
        return static::firstOrCreate(
            [
                'company_id' => $companyId,
                'party_type' => 'customer',
                'party_id'   => $customerId,
            ],
            ['currency' => 'ARS']
        );
    }

    /**
     * Saldo actual del ledger.
     */
    public function currentBalance(): float
    {
        $last = $this->entries()->latest('entry_date')->latest('id')->first();
        return $last ? (float) $last->balance_after : 0.0;
    }

    /**
     * Registra un débito (el cliente debe dinero — genera cargo).
     * Ej: cuando se emite un trabajo de laboratorio o una venta.
     */
    public function debit(
        float $amount,
        string $entryDate,
        string $referenceType = null,
        int $referenceId = null,
        string $note = null
    ): LedgerEntry {
        $balance = $this->currentBalance() - $amount; // saldo baja (el cliente debe más)
        return $this->entries()->create([
            'entry_date'     => $entryDate,
            'type'           => 'debit',
            'amount'         => $amount,
            'balance_after'  => $balance,
            'reference_type' => $referenceType,
            'reference_id'   => $referenceId,
            'note'           => $note,
        ]);
    }

    /**
     * Registra un crédito (el cliente paga — reduce su deuda).
     * Ej: cuando registramos un cobro.
     */
    public function credit(
        float $amount,
        string $entryDate,
        string $referenceType = null,
        int $referenceId = null,
        string $note = null
    ): LedgerEntry {
        $balance = $this->currentBalance() + $amount; // saldo sube (el cliente debe menos)
        return $this->entries()->create([
            'entry_date'     => $entryDate,
            'type'           => 'credit',
            'amount'         => $amount,
            'balance_after'  => $balance,
            'reference_type' => $referenceType,
            'reference_id'   => $referenceId,
            'note'           => $note,
        ]);
    }
}
