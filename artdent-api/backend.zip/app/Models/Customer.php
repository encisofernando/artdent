<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Customer extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'customers';

    protected $fillable = [
        'company_id',
        'code',
        'name',
        'tax_id',
        'tax_condition',
        'email',
        'phone',
        'document',
        'address',
        'city',
        'state',
        'zip',
        'credit_limit',
        'is_active',
        'es_odontologo',
        'es_cliente_insumos',
        'clinica',
        'dentist_id',
        'ultima_actividad',
    ];

    protected $casts = [
        'credit_limit'       => 'float',
        'is_active'          => 'boolean',
        'es_odontologo'      => 'boolean',
        'es_cliente_insumos' => 'boolean',
        'ultima_actividad'   => 'date:Y-m-d',
    ];

    protected $dates = [
        'ultima_actividad',
    ];

    // ─── Relaciones ───────────────────────────────────────────────────────────

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function dentist()
    {
        return $this->belongsTo(Dentist::class);
    }

    public function receipts()
    {
        return $this->hasMany(CustomerReceipt::class);
    }

    public function ledger()
    {
        return $this->hasOne(Ledger::class, 'party_id')
                    ->where('party_type', 'customer');
    }

    public function sales()
    {
        return $this->hasMany(Sale::class);
    }

    public function ecommerceOrders()
    {
        return $this->hasMany(EcommerceOrder::class, 'user_id');
    }

    // ─── Scopes ──────────────────────────────────────────────────────────────

    public function scopeForCompany($query, $companyId)
    {
        return $query->where('company_id', $companyId);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeOdontologos($query)
    {
        return $query->where('es_odontologo', true);
    }

    public function scopeInsumos($query)
    {
        return $query->where('es_cliente_insumos', true);
    }

    public function scopeSearch($query, ?string $term)
    {
        if (!$term) {
            return $query;
        }

        return $query->where(function ($q) use ($term) {
            $q->where('name', 'like', "%{$term}%")
              ->orWhere('tax_id', 'like', "%{$term}%")
              ->orWhere('email', 'like', "%{$term}%")
              ->orWhere('phone', 'like', "%{$term}%")
              ->orWhere('code', 'like', "%{$term}%")
              ->orWhere('clinica', 'like', "%{$term}%");
        });
    }

    // ─── Accessors ────────────────────────────────────────────────────────────

    public function getSaldoAttribute(): float
    {
        if (!$this->relationLoaded('ledger') || !$this->ledger) {
            return 0.0;
        }

        $lastEntry = $this->ledger->entries()
            ->latest('entry_date')
            ->latest('id')
            ->first();

        return $lastEntry ? (float) $lastEntry->balance_after : 0.0;
    }

    public function getUltimaActividadAttribute($value)
    {
        return $value ? $value->format('Y-m-d') : null;
    }

    // ─── Stats (usadas por el index y transform) ──────────────────────────────

    public function labStats(): array
    {
        if (!$this->es_odontologo || !$this->dentist_id) {
            return [
                'trabajos_pendientes' => 0,
                'trabajos_total'      => 0,
                'monto_trabajos_mes'  => 0.0,
            ];
        }

        $pendientes = Job::where('dentist_id', $this->dentist_id)
            ->whereIn('status', ['pending', 'in_progress'])
            ->count();

        $total = Job::where('dentist_id', $this->dentist_id)->count();

        $mesActual = now()->format('Y-m');
        $montoMes = Job::where('dentist_id', $this->dentist_id)
            ->whereRaw("DATE_FORMAT(entry_date, '%Y-%m') = ?", [$mesActual])
            ->sum('total') ?? 0.0;

        return [
            'trabajos_pendientes' => (int) $pendientes,
            'trabajos_total'      => (int) $total,
            'monto_trabajos_mes'  => (float) $montoMes,
        ];
    }

    public function ecommerceStats(): array
    {
        if (!$this->es_cliente_insumos) {
            return [
                'pedidos_total'     => 0,
                'monto_pedidos_mes' => 0.0,
            ];
        }

        $pedidosTotal = Sale::where('customer_id', $this->id)->count();

        $mesActual = now()->format('Y-m');
        $montoMes = Sale::where('customer_id', $this->id)
            ->whereRaw("DATE_FORMAT(sale_date, '%Y-%m') = ?", [$mesActual])
            ->sum('total') ?? 0.0;

        return [
            'pedidos_total'     => (int) $pedidosTotal,
            'monto_pedidos_mes' => (float) $montoMes,
        ];
    }
}
