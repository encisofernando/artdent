<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\CustomerReceipt;
use App\Models\Ledger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * CustomerPaymentController
 *
 * Maneja los comprobantes de cobro/pago a clientes (pagos.jsx).
 * Cada operación:
 *   1. Crea el customer_receipt
 *   2. Registra el ledger_entry (actualiza saldo de cuenta corriente)
 *   3. Actualiza ultima_actividad del cliente
 */
class CustomerPaymentController extends Controller
{
    /**
     * GET /api/customers/payments
     *
     * Params: customer_id, type, payment_method, from, to, search, per_page
     */
    public function index(Request $request): JsonResponse
    {
        $companyId = $request->user()->company_id;

        $query = CustomerReceipt::forCompany($companyId)
            ->with(['customer:id,name,clinica', 'user:id,name'])
            ->filters($request->only([
                'customer_id', 'type', 'payment_method', 'from', 'to', 'search',
            ]))
            ->orderByDesc('receipt_date')
            ->orderByDesc('id');

        $perPage = min((int) $request->input('per_page', 50), 200);
        $results = $query->paginate($perPage);

        $items = $results->getCollection()->map(
            fn (CustomerReceipt $r) => $this->transformReceipt($r)
        );
        $results->setCollection($items);

        // Total para el campo "Total filtrado" del header
        $totalFiltrado = CustomerReceipt::forCompany($companyId)
            ->filters($request->only(['customer_id', 'type', 'payment_method', 'from', 'to', 'search']))
            ->sum('total');

        return response()->json([
            'data'           => $results,
            'total_filtrado' => (float) $totalFiltrado,
        ]);
    }

    /**
     * POST /api/customers/payments
     *
     * Body:
     *  customer_id, receipt_date, type (cobro|pago),
     *  amount_cash, amount_transfer, amount_check, amount_card,
     *  check_number, check_bank, check_due_date,
     *  account_name, reference, note
     */
    public function store(Request $request): JsonResponse
    {
        $companyId = $request->user()->company_id;

        $data = $request->validate([
            'customer_id'     => ['required', 'integer', 'exists:customers,id'],
            'receipt_date'    => ['required', 'date'],
            'type'            => ['required', 'in:cobro,pago'],
            'amount_cash'     => ['nullable', 'numeric', 'min:0'],
            'amount_transfer' => ['nullable', 'numeric', 'min:0'],
            'amount_check'    => ['nullable', 'numeric', 'min:0'],
            'amount_card'     => ['nullable', 'numeric', 'min:0'],
            'check_number'    => ['nullable', 'string', 'max:64'],
            'check_bank'      => ['nullable', 'string', 'max:100'],
            'check_due_date'  => ['nullable', 'date'],
            'account_name'    => ['nullable', 'string', 'max:100'],
            'reference'       => ['nullable', 'string', 'max:100'],
            'note'            => ['nullable', 'string', 'max:500'],
        ]);

        // Calcular total
        $total = ($data['amount_cash']     ?? 0)
               + ($data['amount_transfer'] ?? 0)
               + ($data['amount_check']    ?? 0)
               + ($data['amount_card']     ?? 0);

        if ($total <= 0) {
            return response()->json(['message' => 'El total debe ser mayor a cero'], 422);
        }

        $receipt = DB::transaction(function () use ($data, $companyId, $total, $request) {
            // 1. Crear recibo
            $receiptNumber = CustomerReceipt::nextReceiptNumber($companyId);

            $receipt = CustomerReceipt::create([
                ...$data,
                'company_id'     => $companyId,
                'user_id'        => $request->user()->id,
                'receipt_number' => $receiptNumber,
                'total'          => $total,
                'amount_cash'    => $data['amount_cash']     ?? 0,
                'amount_transfer'=> $data['amount_transfer'] ?? 0,
                'amount_check'   => $data['amount_check']    ?? 0,
                'amount_card'    => $data['amount_card']     ?? 0,
            ]);

            // 2. Registrar en ledger
            $ledger = Ledger::forCustomer($companyId, $data['customer_id']);

            $note = match ($receipt->tipo_payment) {
                'Cheque'         => "Cobro Cheque #{$data['check_number']}",
                'Transferencia'  => 'Cobro Transferencia',
                default          => "Cobro {$receipt->tipo_payment}",
            };

            if ($data['type'] === 'cobro') {
                // cobro → el cliente abona → credit en ledger (saldo sube = debe menos)
                $entry = $ledger->credit(
                    $total,
                    $data['receipt_date'],
                    'customer_receipt',
                    $receipt->id,
                    $note
                );
            } else {
                // pago → devolvemos dinero al cliente → debit en ledger (saldo baja)
                $entry = $ledger->debit(
                    $total,
                    $data['receipt_date'],
                    'customer_receipt',
                    $receipt->id,
                    'Pago a cliente'
                );
            }

            // 3. Vincular ledger_entry al receipt
            $receipt->update(['ledger_entry_id' => $entry->id]);

            // 4. Actualizar ultima_actividad del cliente
            Customer::where('id', $data['customer_id'])
                    ->update(['ultima_actividad' => $data['receipt_date']]);

            return $receipt->load(['customer:id,name,clinica', 'user:id,name']);
        });

        return response()->json($this->transformReceipt($receipt), 201);
    }

    /**
     * DELETE /api/customers/payments/{id}
     * Soft delete + reversión del ledger entry (contra-asiento)
     */
    public function destroy(Request $request, int $id): JsonResponse
    {
        $companyId = $request->user()->company_id;

        $receipt = CustomerReceipt::forCompany($companyId)->findOrFail($id);

        DB::transaction(function () use ($receipt, $request) {
            // Contra-asiento en ledger
            if ($receipt->ledger_entry_id) {
                $ledger = Ledger::forCustomer($receipt->company_id, $receipt->customer_id);

                // Revertir: si era cobro → ahora debitamos, y viceversa
                if ($receipt->type === 'cobro') {
                    $ledger->debit(
                        $receipt->total,
                        now()->format('Y-m-d'),
                        'customer_receipt',
                        $receipt->id,
                        "Anulación {$receipt->receipt_number}"
                    );
                } else {
                    $ledger->credit(
                        $receipt->total,
                        now()->format('Y-m-d'),
                        'customer_receipt',
                        $receipt->id,
                        "Anulación {$receipt->receipt_number}"
                    );
                }
            }

            $receipt->delete();
        });

        return response()->json(['message' => 'Comprobante anulado']);
    }

    // ─── Transform ────────────────────────────────────────────────────────────

    private function transformReceipt(CustomerReceipt $r): array
    {
        return [
            'id'              => $r->id,
            'receipt_number'  => $r->receipt_number,
            'receipt_date'    => $r->receipt_date?->format('Y-m-d'),
            'tipo'            => ucfirst($r->type),           // Cobro / Pago
            'clinica'         => $r->customer?->clinica ?? $r->customer?->name ?? '—',
            'tPago'           => $r->tipo_payment,            // Efectivo / Cheque / etc.
            'comp'            => $r->receipt_number,
            'observacion'     => $r->note ?? '',
            'cheque'          => $r->check_number ?? '',
            'fecha'           => $r->receipt_date?->format('Y-m-d'),
            'efectivo'        => (float) $r->amount_cash,
            'impCheque'       => (float) $r->amount_check,
            'total'           => (float) $r->total,
            'usuario'         => $r->user?->name ?? '—',
            'cuenta'          => $r->account_name ?? '—',
            'customer_id'     => $r->customer_id,
            'customer_name'   => $r->customer?->name,
        ];
    }
}
