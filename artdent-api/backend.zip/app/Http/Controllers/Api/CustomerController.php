<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Ledger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class CustomerController extends Controller
{
    /**
     * GET /api/customers
     *
     * Query params:
     *  search         string  — búsqueda en nombre, CUIT, email, código, clínica
     *  context        string  — todos | lab | ecommerce
     *  estado         string  — todos | activos | inactivos
     *  page           int
     *  per_page       int     (default 50)
     *  with_stats     bool    — incluye trabajos_pendientes, saldo, etc.
     */
    public function index(Request $request): JsonResponse
    {
        $companyId = $request->user()->company_id;

        $query = Customer::forCompany($companyId)
            ->search($request->input('search'))
            ->with(['ledger.entries' => fn ($q) => $q->latest('entry_date')->latest('id')->limit(1)]);

        // Filtro de contexto
        match ($request->input('context', 'todos')) {
            'lab'       => $query->odontologos(),
            'ecommerce' => $query->insumos(),
            default     => null,
        };

        // Filtro de estado
        match ($request->input('estado', 'todos')) {
            'activos'   => $query->active(),
            'inactivos' => $query->where('is_active', 0),
            default     => null,
        };

        $query->orderBy('name');

        $perPage = min((int) $request->input('per_page', 50), 200);
        $clientes = $query->paginate($perPage);

        // Transformar con stats
        $withStats = $request->boolean('with_stats', true);
        $items = $clientes->getCollection()->map(
            fn (Customer $c) => $this->transform($c, $withStats)
        );
        $clientes->setCollection($items);

        return response()->json($clientes);
    }

    /**
     * POST /api/customers
     */
    public function store(Request $request): JsonResponse
    {
        $companyId = $request->user()->company_id;

        $data = $request->validate([
            'code'               => ['nullable', 'string', 'max:32',
                                     Rule::unique('customers')->where('company_id', $companyId)->whereNull('deleted_at')],
            'name'               => ['required', 'string', 'max:191'],
            'tax_id'             => ['nullable', 'string', 'max:32',
                                     Rule::unique('customers')->where('company_id', $companyId)->whereNull('deleted_at')],
            'tax_condition'      => ['nullable', 'string', 'max:64'],
            'email'              => ['nullable', 'email', 'max:191'],
            'phone'              => ['nullable', 'string', 'max:64'],
            'document'           => ['nullable', 'string', 'max:50'],
            'address'            => ['nullable', 'string', 'max:191'],
            'city'               => ['nullable', 'string', 'max:191'],
            'state'              => ['nullable', 'string', 'max:191'],
            'zip'                => ['nullable', 'string', 'max:32'],
            'credit_limit'       => ['nullable', 'numeric', 'min:0'],
            'is_active'          => ['nullable', 'boolean'],
            'es_odontologo'      => ['nullable', 'boolean'],
            'es_cliente_insumos' => ['nullable', 'boolean'],
            'clinica'            => ['nullable', 'string', 'max:191'],
            'dentist_id'         => ['nullable', 'integer', 'exists:dentists,id'],
        ]);

        $data['company_id'] = $companyId;
        $data['is_active']  = $data['is_active'] ?? 1;
        $data['es_cliente_insumos'] = $data['es_cliente_insumos'] ?? 1;

        $customer = DB::transaction(function () use ($data) {
            $c = Customer::create($data);
            // Crear ledger vacío automáticamente
            Ledger::forCustomer($c->company_id, $c->id);
            return $c;
        });

        return response()->json($this->transform($customer), 201);
    }

    /**
     * GET /api/customers/{id}
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $customer = Customer::forCompany($request->user()->company_id)
            ->findOrFail($id);

        return response()->json($this->transform($customer, true));
    }

    /**
     * PUT /api/customers/{id}
     */
    public function update(Request $request, int $id): JsonResponse
    {
        $companyId = $request->user()->company_id;

        $customer = Customer::forCompany($companyId)->findOrFail($id);

        $data = $request->validate([
            'code'               => ['nullable', 'string', 'max:32',
                                     Rule::unique('customers')->where('company_id', $companyId)
                                         ->whereNull('deleted_at')->ignore($id)],
            'name'               => ['required', 'string', 'max:191'],
            'tax_id'             => ['nullable', 'string', 'max:32',
                                     Rule::unique('customers')->where('company_id', $companyId)
                                         ->whereNull('deleted_at')->ignore($id)],
            'tax_condition'      => ['nullable', 'string', 'max:64'],
            'email'              => ['nullable', 'email', 'max:191'],
            'phone'              => ['nullable', 'string', 'max:64'],
            'document'           => ['nullable', 'string', 'max:50'],
            'address'            => ['nullable', 'string', 'max:191'],
            'city'               => ['nullable', 'string', 'max:191'],
            'state'              => ['nullable', 'string', 'max:191'],
            'zip'                => ['nullable', 'string', 'max:32'],
            'credit_limit'       => ['nullable', 'numeric', 'min:0'],
            'is_active'          => ['nullable', 'boolean'],
            'es_odontologo'      => ['nullable', 'boolean'],
            'es_cliente_insumos' => ['nullable', 'boolean'],
            'clinica'            => ['nullable', 'string', 'max:191'],
            'dentist_id'         => ['nullable', 'integer', 'exists:dentists,id'],
        ]);

        $customer->update($data);

        return response()->json($this->transform($customer->fresh(), true));
    }

    /**
     * DELETE /api/customers/{id}   (soft delete)
     */
    public function destroy(Request $request, int $id): JsonResponse
    {
        $customer = Customer::forCompany($request->user()->company_id)->findOrFail($id);
        $customer->delete();
        return response()->json(['message' => 'Cliente eliminado'], 200);
    }

    /**
     * GET /api/customers/kpis
     * Totales para los KPI cards del hub.
     */
public function kpis(Request $request): JsonResponse
{
    $companyId = $request->user()->company_id;

    if (!$companyId) {
        return response()->json(['error' => 'No company associated'], 403);
    }

    $mes = now()->format('Y-m');

    $total = Customer::forCompany($companyId)->count();
    $lab   = Customer::forCompany($companyId)->odontologos()->count();
    $ecomm = Customer::forCompany($companyId)->insumos()->count();

    $pendientes = DB::table('jobs')
        ->where('company_id', $companyId)
        ->whereIn('status', ['pending', 'in_progress'])
        ->whereNull('deleted_at')
        ->whereExists(function ($q) use ($companyId) {
            $q->select(DB::raw(1))
              ->from('customers')
              ->whereColumn('customers.dentist_id', 'jobs.dentist_id')
              ->where('customers.company_id', $companyId)
              ->where('customers.es_odontologo', true)
              ->whereNull('customers.deleted_at');
        })
        ->count();

    $ventasMes = DB::table('sales')
        ->where('company_id', $companyId)
        ->whereRaw("DATE_FORMAT(sale_date, '%Y-%m') = ?", [$mes])
        ->whereNull('deleted_at')
        ->sum('total') ?? 0;

    $trabajosMes = DB::table('jobs')
        ->where('company_id', $companyId)
        ->whereRaw("DATE_FORMAT(entry_date, '%Y-%m') = ?", [$mes])
        ->whereNull('deleted_at')
        ->sum('total') ?? 0;

    return response()->json([
        'total'         => $total,
        'lab'           => $lab,
        'ecomm'         => $ecomm,
        'pendientes'    => (int) $pendientes,
        'facturacion'   => (float) $ventasMes + (float) $trabajosMes,
    ]);
}

    // ─── Transform ────────────────────────────────────────────────────────────

    private function transform(Customer $c, bool $withStats = false): array
    {
        $base = [
            'id'               => $c->id,
            'code'             => $c->code,
            'name'             => $c->name,
            'tax_id'           => $c->tax_id,
            'tax_condition'    => $c->tax_condition,
            'email'            => $c->email,
            'phone'            => $c->phone,
            'document'         => $c->document,
            'address'          => $c->address,
            'city'             => $c->city,
            'state'            => $c->state,
            'zip'              => $c->zip,
            'credit_limit'     => (float) $c->credit_limit,
            'is_active'        => (bool)  $c->is_active,
            // contexto
            'es_odontologo'      => (bool)  $c->es_odontologo,
            'es_cliente_insumos' => (bool)  $c->es_cliente_insumos,
            'clinica'            => $c->clinica,
            'dentist_id'         => $c->dentist_id,
            'ultima_actividad'   => $c->ultima_actividad?->format('Y-m-d'),
            // saldo
            'saldo'            => $c->saldo,
        ];

        if ($withStats) {
            $base = array_merge($base, $c->labStats(), $c->ecommerceStats());
        }

        return $base;
    }
}
