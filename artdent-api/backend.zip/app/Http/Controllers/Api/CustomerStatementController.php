<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Ledger;
use App\Models\LedgerEntry;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * CustomerStatementController
 *
 * Devuelve el resumen de cuenta corriente de un cliente (resumen_cta.jsx).
 * Lee directamente de ledger_entries.
 */
class CustomerStatementController extends Controller
{
    /**
     * GET /api/customers/{id}/statement
     *
     * Params: from (date), to (date)
     *
     * Devuelve todos los movimientos del ledger del cliente, con:
     *  - saldo anterior (al inicio del período)
     *  - lista de movimientos (debe, haber, saldo acumulado)
     *  - resumen: suma_pagos, suma_deuda, saldo_actual
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $companyId = $request->user()->company_id;

        $customer = Customer::forCompany($companyId)->findOrFail($id);

        $request->validate([
            'from' => ['nullable', 'date'],
            'to'   => ['nullable', 'date'],
        ]);

        $from = $request->input('from');
        $to   = $request->input('to');

        // Obtener o crear ledger del cliente
        $ledger = Ledger::forCustomer($companyId, $id);

        // Saldo anterior: último balance_after ANTES del período 'from'
        $saldoAnterior = 0.0;
        if ($from) {
            $prevEntry = $ledger->entries()
                ->where('entry_date', '<', $from)
                ->latest('entry_date')->latest('id')
                ->first();
            $saldoAnterior = $prevEntry ? (float) $prevEntry->balance_after : 0.0;
        }

        // Movimientos del período
        $query = $ledger->entries()->orderBy('entry_date')->orderBy('id');
        if ($from) $query->where('entry_date', '>=', $from);
        if ($to)   $query->where('entry_date', '<=', $to);

        $entries = $query->get();

        // Construir filas con referencia legible
        $rows = $entries->map(function (LedgerEntry $e) {
            // Obtener nombre del comprobante según reference_type
            $comp = $this->resolveComp($e->reference_type, $e->reference_id);

            return [
                'id'        => $e->id,
                'fecha'     => $e->entry_date?->format('Y-m-d'),
                'comp'      => $comp,
                'concepto'  => $e->concepto,
                'tPago'     => $this->resolveTipoPayment($e->reference_type, $e->reference_id),
                'dPago'     => '',
                'observ'    => $e->note ?? '',
                'debe'      => $e->debe,
                'haber'     => $e->haber,
                'saldo'     => $e->saldo,
                'destino'   => '',
            ];
        });

        // Totales del período
        $sumaDebe    = $entries->sum(fn ($e) => $e->debe);
        $sumaHaber   = $entries->sum(fn ($e) => $e->haber);
        $saldoActual = $entries->last()?->balance_after ?? $saldoAnterior;

        return response()->json([
            'customer' => [
                'id'    => $customer->id,
                'name'  => $customer->name,
                'email' => $customer->email,
                'phone' => $customer->phone,
            ],
            'saldo_anterior' => $saldoAnterior,
            'suma_pagos'     => (float) $sumaHaber,
            'suma_deuda'     => (float) $sumaDebe,
            'saldo_actual'   => (float) $saldoActual,
            'data'           => $rows,
        ]);
    }

    /**
     * GET /api/customers/{id}/statement/summary
     * Sólo los totales, sin el detalle (para el KPI del listado).
     */
    public function summary(Request $request, int $id): JsonResponse
    {
        $companyId = $request->user()->company_id;
        Customer::forCompany($companyId)->findOrFail($id);

        $ledger = Ledger::forCustomer($companyId, $id);
        $saldo  = $ledger->currentBalance();

        return response()->json(['saldo' => $saldo]);
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private function resolveComp(?string $refType, ?int $refId): string
    {
        if (! $refType || ! $refId) return '—';

        return match ($refType) {
            'customer_receipt' => DB::table('customer_receipts')->where('id', $refId)->value('receipt_number') ?? "RC-{$refId}",
            'job'              => DB::table('jobs')->where('id', $refId)->value('ticket_number') ?? "OT-{$refId}",
            'sale'             => DB::table('sales')->where('id', $refId)->value('number') ?? "VT-{$refId}",
            'invoice'          => "FA-{$refId}",
            default            => "{$refType}-{$refId}",
        };
    }

    private function resolveTipoPayment(?string $refType, ?int $refId): string
    {
        if ($refType !== 'customer_receipt' || ! $refId) return '';

        $r = DB::table('customer_receipts')->where('id', $refId)
                ->select('amount_cash','amount_transfer','amount_check','amount_card')
                ->first();

        if (! $r) return '';

        if ($r->amount_check > 0 && $r->amount_cash > 0)    return 'Mixto';
        if ($r->amount_check > 0)                            return 'Cheque';
        if ($r->amount_transfer > 0)                         return 'Transferencia';
        if ($r->amount_card > 0)                             return 'Tarjeta';
        return 'Efectivo';
    }
}
