<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('jobs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->unsignedBigInteger('dentist_id')->nullable(); // FK a customers.dentist_id
            $table->string('ticket_number', 32)->unique();
            $table->date('entry_date');
            $table->date('delivery_date')->nullable();
            $table->enum('status', ['pending', 'in_progress', 'completed', 'cancelled'])->default('pending');
            $table->decimal('total', 14, 2)->default(0.00);
            $table->text('description')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('company_id')->references('id')->on('companies')->onDelete('cascade');
            $table->foreign('dentist_id')->references('dentist_id')->on('customers')->onDelete('set null');
            $table->index(['company_id', 'status']);
            $table->index('dentist_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('jobs');
    }
};
