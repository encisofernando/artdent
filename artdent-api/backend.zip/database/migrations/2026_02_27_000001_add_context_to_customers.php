<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Agrega columnas de contexto a `customers`.
 * Cada columna / índice está protegido con hasColumn() para ser idempotente.
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Columnas ───────────────────────────────────────────────────────
        Schema::table('customers', function (Blueprint $table) {
            if (! Schema::hasColumn('customers', 'es_odontologo')) {
                $table->tinyInteger('es_odontologo')
                      ->default(0)
                      ->comment('1 = es cliente del laboratorio')
                      ->after('is_active');
            }
            if (! Schema::hasColumn('customers', 'es_cliente_insumos')) {
                $table->tinyInteger('es_cliente_insumos')
                      ->default(1)
                      ->comment('1 = es cliente de POS / e-commerce')
                      ->after('es_odontologo');
            }
            if (! Schema::hasColumn('customers', 'clinica')) {
                $table->string('clinica', 191)
                      ->nullable()
                      ->comment('Nombre de la clínica u consultorio')
                      ->after('es_cliente_insumos');
            }
            if (! Schema::hasColumn('customers', 'dentist_id')) {
                $table->unsignedBigInteger('dentist_id')
                      ->nullable()
                      ->comment('FK a dentists.id (opcional)')
                      ->after('clinica');
            }
            if (! Schema::hasColumn('customers', 'ultima_actividad')) {
                $table->date('ultima_actividad')
                      ->nullable()
                      ->comment('Última fecha de trabajo o pago registrado')
                      ->after('dentist_id');
            }
        });

        // ── FK a dentists (solo si la tabla existe y la FK no está ya) ─────
        if (Schema::hasTable('dentists') && Schema::hasColumn('customers', 'dentist_id')) {
            $fkExists = DB::select("
                SELECT COUNT(*) as cnt
                FROM information_schema.KEY_COLUMN_USAGE
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME   = 'customers'
                  AND COLUMN_NAME  = 'dentist_id'
                  AND REFERENCED_TABLE_NAME IS NOT NULL
            ")[0]->cnt > 0;

            if (! $fkExists) {
                Schema::table('customers', function (Blueprint $table) {
                    $table->foreign('dentist_id')
                          ->references('id')->on('dentists')
                          ->onDelete('set null')->onUpdate('cascade');
                });
            }
        }

        // ── Índices ───────────────────────────────────────────────────────
        $existing = $this->indexNames('customers');

        Schema::table('customers', function (Blueprint $table) use ($existing) {
            if (! in_array('customers_es_odontologo_index', $existing)) {
                $table->index('es_odontologo');
            }
            if (! in_array('customers_es_cliente_insumos_index', $existing)) {
                $table->index('es_cliente_insumos');
            }
            if (! in_array('customers_dentist_id_index', $existing)) {
                $table->index('dentist_id');
            }
        });
    }

    public function down(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            try { $table->dropForeign(['dentist_id']); } catch (\Throwable $e) {}

            $existing = $this->indexNames('customers');
            if (in_array('customers_es_odontologo_index',      $existing)) $table->dropIndex(['es_odontologo']);
            if (in_array('customers_es_cliente_insumos_index', $existing)) $table->dropIndex(['es_cliente_insumos']);
            if (in_array('customers_dentist_id_index',         $existing)) $table->dropIndex(['dentist_id']);

            foreach (['es_odontologo','es_cliente_insumos','clinica','dentist_id','ultima_actividad'] as $col) {
                if (Schema::hasColumn('customers', $col)) {
                    $table->dropColumn($col);
                }
            }
        });
    }

    private function indexNames(string $table): array
    {
        $rows = DB::select("SHOW INDEX FROM `{$table}`");
        return array_map(fn ($r) => $r->Key_name, $rows);
    }
};
