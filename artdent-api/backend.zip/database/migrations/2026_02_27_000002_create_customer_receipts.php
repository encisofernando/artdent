<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tabla `customer_receipts` — Comprobantes de cobro/pago a clientes
 *
 * Cada registro es un comprobante de caja (recibo de cobro o nota de débito/crédito).
 * Al crear un receipt se genera automáticamente un ledger_entry que actualiza
 * el saldo de la cuenta corriente del cliente.
 *
 * Columnas principales:
 *  - type           → cobro | pago   (cobro = ingresa dinero, pago = egresa)
 *  - amount_cash    → parte en efectivo
 *  - amount_transfer → parte en transferencia
 *  - amount_check   → parte en cheque
 *  - amount_card    → parte en tarjeta
 *  - total          → suma de todos los medios
 *  - account_name   → caja / banco destino del cobro
 *  - check_number   → N° cheque si corresponde
 *  - reference      → N° comprobante generado (ej: RC-0001)
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('customer_receipts', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->unsignedBigInteger('customer_id');
            $table->unsignedBigInteger('user_id')->nullable()->comment('Usuario que registró');

            // Comprobante
            $table->string('receipt_number', 32)->comment('Número de recibo generado: RC-XXXX');
            $table->date('receipt_date');
            $table->enum('type', ['cobro', 'pago'])->default('cobro')
                  ->comment('cobro = cliente paga / pago = devolvemos dinero al cliente');

            // Medios de pago
            $table->decimal('amount_cash', 14, 2)->default(0)->comment('Efectivo');
            $table->decimal('amount_transfer', 14, 2)->default(0)->comment('Transferencia bancaria');
            $table->decimal('amount_check', 14, 2)->default(0)->comment('Cheque');
            $table->decimal('amount_card', 14, 2)->default(0)->comment('Tarjeta débito/crédito');
            $table->decimal('total', 14, 2)->default(0)->comment('Suma de todos los medios');

            // Detalles
            $table->string('check_number', 64)->nullable()->comment('N° cheque');
            $table->string('check_bank', 100)->nullable()->comment('Banco del cheque');
            $table->date('check_due_date')->nullable()->comment('Fecha de vencimiento del cheque');
            $table->string('account_name', 100)->nullable()->comment('Caja / Banco destino');
            $table->string('reference', 100)->nullable()->comment('Referencia externa / N° transferencia');
            $table->text('note')->nullable()->comment('Observación libre');

            // Ledger link (se crea automáticamente al guardar el receipt)
            $table->unsignedBigInteger('ledger_entry_id')->nullable()
                  ->comment('FK al ledger_entry generado');

            $table->timestamps();
            $table->softDeletes();

            // Índices y FKs
            $table->unique(['company_id', 'receipt_number'], 'uq_receipt_company_number');
            $table->index(['company_id', 'receipt_date'], 'idx_receipt_company_date');
            $table->index(['customer_id', 'receipt_date'], 'idx_receipt_customer_date');

            $table->foreign('company_id')->references('id')->on('companies')
                  ->onUpdate('cascade');
            $table->foreign('customer_id')->references('id')->on('customers')
                  ->onUpdate('cascade');
            $table->foreign('user_id')->references('id')->on('users')
                  ->onDelete('set null');
            $table->foreign('ledger_entry_id')->references('id')->on('ledger_entries')
                  ->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('customer_receipts');
    }
};
