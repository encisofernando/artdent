# Script de Verificación de Imágenes - ArtDent
# Ejecutar en PowerShell desde la raíz del proyecto

Write-Host "=== Diagnóstico de Imágenes ===" -ForegroundColor Cyan
Write-Host ""

# 1. Verificar storage link
Write-Host "1. Verificando storage link..." -ForegroundColor Yellow
$storagePath = "public\storage"
if (Test-Path $storagePath -PathType Container) {
    Write-Host "   ✓ public\storage existe" -ForegroundColor Green
    
    # Verificar si es un link simbólico
    $item = Get-Item $storagePath
    if ($item.LinkType -eq "SymbolicLink") {
        Write-Host "   ✓ Es un enlace simbólico correcto" -ForegroundColor Green
        Write-Host "     → Apunta a: $($item.Target)" -ForegroundColor Gray
    } else {
        Write-Host "   ⚠ Existe pero no es un enlace simbólico" -ForegroundColor Yellow
        Write-Host "     Ejecuta: php artisan storage:link" -ForegroundColor Yellow
    }
} else {
    Write-Host "   ✗ public\storage NO existe" -ForegroundColor Red
    Write-Host "     Ejecuta: php artisan storage:link" -ForegroundColor Yellow
}

Write-Host ""

# 2. Verificar directorio de productos
Write-Host "2. Verificando directorio de productos..." -ForegroundColor Yellow
$productsPath = "storage\app\public\products"
if (Test-Path $productsPath -PathType Container) {
    $folders = Get-ChildItem $productsPath -Directory | Measure-Object
    Write-Host "   ✓ Directorio existe" -ForegroundColor Green
    Write-Host "     → Carpetas de productos: $($folders.Count)" -ForegroundColor Gray
    
    # Mostrar algunos ejemplos
    $examples = Get-ChildItem $productsPath -Directory | Select-Object -First 3
    foreach ($folder in $examples) {
        $files = Get-ChildItem $folder.FullName -File | Measure-Object
        Write-Host "     → Producto $($folder.Name): $($files.Count) imagen(es)" -ForegroundColor Gray
    }
} else {
    Write-Host "   ⚠ Directorio no existe aún" -ForegroundColor Yellow
    Write-Host "     Se creará automáticamente al subir la primera imagen" -ForegroundColor Gray
}

Write-Host ""

# 3. Verificar .env
Write-Host "3. Verificando configuración..." -ForegroundColor Yellow
if (Test-Path ".env" -PathType Leaf) {
    $appUrl = Select-String -Path ".env" -Pattern "^APP_URL=" | Select-Object -First 1
    if ($appUrl) {
        Write-Host "   ✓ APP_URL encontrado" -ForegroundColor Green
        Write-Host "     → $($appUrl.Line)" -ForegroundColor Gray
        
        # Verificar trailing slash
        if ($appUrl.Line -match "/$") {
            Write-Host "   ⚠ APP_URL termina con '/' (puede causar problemas)" -ForegroundColor Yellow
            Write-Host "     Elimina el '/' final" -ForegroundColor Yellow
        }
    } else {
        Write-Host "   ⚠ APP_URL no encontrado en .env" -ForegroundColor Yellow
    }
} else {
    Write-Host "   ✗ Archivo .env no encontrado" -ForegroundColor Red
}

Write-Host ""

# 4. Probar conexión a base de datos
Write-Host "4. Verificando imágenes en base de datos..." -ForegroundColor Yellow
Write-Host "   Ejecuta esta query SQL:" -ForegroundColor Gray
Write-Host "   SELECT COUNT(*) as total FROM product_images;" -ForegroundColor Cyan
Write-Host ""
Write-Host "   Para ver detalles:" -ForegroundColor Gray
Write-Host "   SELECT id, product_id, path, is_primary FROM product_images ORDER BY id DESC LIMIT 5;" -ForegroundColor Cyan

Write-Host ""

# 5. Verificar permisos (solo informativo en Windows)
Write-Host "5. Verificación de permisos..." -ForegroundColor Yellow
Write-Host "   En Windows generalmente no hay problemas de permisos" -ForegroundColor Gray
Write-Host "   Si tienes errores, ejecuta PowerShell como Administrador" -ForegroundColor Gray

Write-Host ""

# 6. Comandos sugeridos
Write-Host "=== Comandos para Solucionar Problemas ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Si el storage link no existe o está mal:" -ForegroundColor Yellow
Write-Host "  php artisan storage:link" -ForegroundColor White
Write-Host ""
Write-Host "Si cambias el .env:" -ForegroundColor Yellow
Write-Host "  php artisan config:clear" -ForegroundColor White
Write-Host "  php artisan cache:clear" -ForegroundColor White
Write-Host ""
Write-Host "Para probar subir una imagen:" -ForegroundColor Yellow
Write-Host "  1. Abre el navegador en http://localhost:8000" -ForegroundColor White
Write-Host "  2. Ve a Productos → Editar → Imágenes" -ForegroundColor White
Write-Host "  3. Sube una imagen de prueba" -ForegroundColor White
Write-Host "  4. Verifica que aparezca en:" -ForegroundColor White
Write-Host "     storage\app\public\products\{id}\imagen.jpg" -ForegroundColor Gray
Write-Host ""

# 7. URL de prueba
Write-Host "=== URL de Prueba ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Si tienes una imagen en:" -ForegroundColor Yellow
Write-Host "  storage\app\public\products\574\imagen.jpg" -ForegroundColor Gray
Write-Host ""
Write-Host "Debería ser accesible en:" -ForegroundColor Yellow
Write-Host "  http://localhost:8000/storage/products/574/imagen.jpg" -ForegroundColor Cyan
Write-Host ""
Write-Host "Prueba abriendo esa URL en tu navegador" -ForegroundColor Gray
Write-Host ""

Write-Host "=== Fin del Diagnóstico ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Presiona Enter para continuar..." -ForegroundColor Gray
$null = Read-Host
