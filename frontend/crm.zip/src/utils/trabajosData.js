// src/utils/trabajosData.js
// Datos mock y helpers compartidos para el módulo de Trabajos

export const odontologosMock = [
  { id: 1, nombre: "CARLOS CONSIGLIO",  clinica: "Clínica Dental Norte",    telefono: "011-4555-1234" },
  { id: 2, nombre: "MARIA GONZALEZ",    clinica: "Centro Odontológico Sur",  telefono: "011-4666-5678" },
  { id: 3, nombre: "JORGE MARTINEZ",    clinica: "Consultorio Integral",     telefono: "011-4777-9012" },
  { id: 4, nombre: "LAURA PEREZ",       clinica: "OdontoCenter",             telefono: "011-4888-3456" },
];

export const pacientesMock = [
  { id: 1, nombre: "ACOSTA CORINA",               dni: "28.111.001" },
  { id: 2, nombre: "VILLAGOMEZ ANA MARIA",         dni: "30.222.002" },
  { id: 3, nombre: "IBARRA SARA Y ROTELA CLAUDIO", dni: "25.333.003" },
  { id: 4, nombre: "BENITEZ MIRIAN",               dni: "32.444.004" },
  { id: 5, nombre: "FERNANDEZ JUAN",               dni: "27.555.005" },
];

export const arancelesMock = [
  { id:  1, descripcion: "Acrílico APC 1 a 3 dientes",              importe: 105000, estado: "Habilitado" },
  { id:  2, descripcion: "Acrílico APC 4 a 8 dientes",              importe: 120000, estado: "Habilitado" },
  { id:  3, descripcion: "Acrílico APC 9 o más dientes",            importe: 125000, estado: "Habilitado" },
  { id:  4, descripcion: "Acrílico Inyectado o Flex 1 a 3 dientes", importe: 105000, estado: "Habilitado" },
  { id:  5, descripcion: "Acrílico Inyectado o Flex 4 a 8 dientes", importe: 120000, estado: "Habilitado" },
  { id:  6, descripcion: "Acrílico Inyectado o Flex 9 o más",       importe: 125000, estado: "Habilitado" },
  { id:  7, descripcion: "Corona Porcelana Sobre Metal",             importe: 185000, estado: "Habilitado" },
  { id:  8, descripcion: "Corona Zirconio Full",                     importe: 250000, estado: "Habilitado" },
  { id:  9, descripcion: "Incrustación Metal",                       importe:  95000, estado: "Habilitado" },
  { id: 10, descripcion: "Pilar Implante",                           importe: 165000, estado: "Habilitado" },
  { id: 11, descripcion: "Puente 3 piezas",                          importe: 420000, estado: "Habilitado" },
  { id: 12, descripcion: "Rebase Acrílico",                          importe:  75000, estado: "Habilitado" },
];

export const opcionesAdicionalesList = [
  "Cubeta", "Impresión", "Antagonista",
  "Mordida", "Transfer",  "Torn/Trans",
  "Análogo", "Ucla/Abut", "Perno/Pref",
];

export const listasMock = ["LP1", "LP2", "LP3", "LISTA ESPECIAL"];

export const trabajosMock = [
  {
    id: 1056, ticket: "1056",
    odontólogo: "CARLOS CONSIGLIO", clinica: "",
    paciente:   "VILLAGOMEZ ANA MARIA",
    fechaDesde: "2026-02-25", fechaHasta: "2026-02-25",
    total: 135000, estado: "En proceso",
    estadoEntrega: "Pendiente", tipo: "Ticket",
    fechaAlta: "2026-02-25 12:57:00",
    items: [{ id: 1, trabajo: "Corona Porcelana Sobre Metal", piezas: "PD 11 Color A3", importe: 135000, cantidad: 1, total: 135000 }],
  },
  {
    id: 1043, ticket: "1043",
    odontólogo: "CARLOS CONSIGLIO", clinica: "",
    paciente:   "IBARRA SARA Y ROTELA CLAUDIO",
    fechaDesde: "2026-02-24", fechaHasta: "2026-02-24",
    total: 220000, estado: "Terminado",
    estadoEntrega: "Pendiente", tipo: "Ticket",
    fechaAlta: "2026-02-24 13:14:48",
    items: [{ id: 1, trabajo: "Acrílico APC 4 a 8 dientes", piezas: "PD 14-21 Color B2", importe: 220000, cantidad: 1, total: 220000 }],
  },
  {
    id: 1042, ticket: "1042",
    odontólogo: "CARLOS CONSIGLIO", clinica: "",
    paciente:   "BENITEZ MIRIAN",
    fechaDesde: "2026-02-24", fechaHasta: "2026-02-24",
    total: 275000, estado: "Terminado",
    estadoEntrega: "Pendiente", tipo: "Ticket",
    fechaAlta: "2026-02-24 13:10:36",
    items: [{ id: 1, trabajo: "Corona Zirconio Full", piezas: "PD 21 Color A1", importe: 275000, cantidad: 1, total: 275000 }],
  },
];

export const coloresDentales = [
  { code: "#f5ede0", label: "A1"   },
  { code: "#f2e4d0", label: "A2"   },
  { code: "#edd5b8", label: "A3"   },
  { code: "#e8c9a0", label: "A3.5" },
  { code: "#e0b882", label: "A4"   },
  { code: "#f5efdf", label: "B1"   },
  { code: "#f0e5c8", label: "B2"   },
  { code: "#e8d4aa", label: "B3"   },
  { code: "#e0c488", label: "B34"  },
  { code: "#f2ebe0", label: "C1"   },
  { code: "#e8d8c0", label: "C2"   },
  { code: "#d8c4a0", label: "C3"   },
  { code: "#c8b082", label: "C4"   },
  { code: "#ede8d8", label: "D2"   },
  { code: "#e0d8c0", label: "D3"   },
  { code: "#d4cca8", label: "D4"   },
];

export const upperTeeth = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28];
export const lowerTeeth = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38];

export const formatARS = (value) =>
  new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    maximumFractionDigits: 0,
  }).format(value ?? 0);

export const today = new Date().toISOString().split("T")[0];
export const firstOfMonth = `${today.slice(0, 7)}-01`;

export const statusColor = (estado, theme) => {
  const isDark = theme.palette.mode === "dark";
  const map = {
    "En proceso": { bg: "rgba(57,123,156,0.18)",  text: "#ACD6CE" },
    "Terminado":  { bg: "rgba(90,173,156,0.18)",  text: "#5AAD9C" },
    "Pendiente":  { bg: "rgba(255,176,32,0.18)",  text: "#FFB020" },
    "Sale hoy":   { bg: "rgba(230,57,70,0.18)",   text: "#E63946" },
  };
  return map[estado] ?? map["Pendiente"];
};