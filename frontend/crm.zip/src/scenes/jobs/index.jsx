// src/scenes/jobs/index.jsx  →  ruta: /trabajos/ingresar
import { useState } from "react";
import {
  Box, Grid, Typography, TextField, Button, Autocomplete,
  RadioGroup, FormControlLabel, Radio, Checkbox, Paper,
  Table, TableHead, TableBody, TableRow, TableCell,
  Chip, IconButton, InputAdornment, Tooltip, Stack,
  useTheme, alpha, Divider,
} from "@mui/material";
import SaveIcon          from "@mui/icons-material/Save";
import AddIcon           from "@mui/icons-material/Add";
import CheckCircleIcon   from "@mui/icons-material/CheckCircle";
import ReceiptIcon       from "@mui/icons-material/Receipt";
import DeleteIcon        from "@mui/icons-material/Delete";
import PersonAddIcon     from "@mui/icons-material/PersonAdd";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";

import ToothSelector from "../../components/ToothSelector";
import {
  odontologosMock, pacientesMock, arancelesMock,
  opcionesAdicionalesList, today, formatARS,
} from "../../utils/trabajosData";

/* ─── SectionCard: Paper con borde izquierdo de color marca ─── */
const SectionCard = ({ children, sx = {} }) => {
  const theme = useTheme();
  return (
    <Paper sx={{
      p: { xs: 2, md: 2.5 },
      borderLeft: `3px solid ${theme.palette.primary.main}`,
      ...sx,
    }}>
      {children}
    </Paper>
  );
};

/* ─── Label caption ─── */
const FieldLabel = ({ children }) => {
  const theme = useTheme();
  return (
    <Typography variant="caption" sx={{
      display: "block", mb: 0.5,
      fontWeight: 700, letterSpacing: "0.07em",
      textTransform: "uppercase", fontSize: "0.65rem",
      color: theme.palette.text.secondary,
    }}>
      {children}
    </Typography>
  );
};

/* ─── Estado Chip ─── */
const EstadoChip = ({ estado }) => {
  const map = {
    "En proceso": { bg: "rgba(57,123,156,0.18)",  text: "#ACD6CE" },
    "Terminado":  { bg: "rgba(90,173,156,0.18)",  text: "#5AAD9C" },
    "Pendiente":  { bg: "rgba(255,176,32,0.18)",  text: "#FFB020" },
  };
  const s = map[estado] ?? map["Pendiente"];
  return (
    <Chip label={estado} size="small" sx={{
      background: s.bg, color: s.text,
      fontWeight: 700, fontSize: "0.7rem",
      border: `1px solid ${alpha(s.text, 0.3)}`,
    }} />
  );
};

let ticketCounter = 1057; // Simulación – en prod viene del backend

/* ════════════════════════════════════ */
export default function Trabajos() {
  const theme  = useTheme();
  const isDark = theme.palette.mode === "dark";

  /* Form state */
  const [form, setForm] = useState({
    odontólogo:    odontologosMock[0],
    paciente:      null,
    fechaDesde:    today,
    fechaHasta:    today,
    tipo:          "Ticket",
    tipoLista:     "odontólogo",
    trabajo:       null,
    especificaciones: "",
    pieza:         "",
    teethSelected: [],
    colorSelected: "A3",
    importe:       0,
    cantidad:      1,
    adicionales:   {},
  });

  const [items,       setItems]       = useState([]);
  const [toothOpen,   setToothOpen]   = useState(false);
  const [currentTicket] = useState(ticketCounter);

  const totalItem  = (form.importe || 0) * (form.cantidad || 1);
  const sumaTotal  = items.reduce((s, i) => s + i.total, 0) + (form.trabajo ? totalItem : 0);

  const setField = (key, val) => setForm((p) => ({ ...p, [key]: val }));

  const handleWorkChange = (val) => {
    setField("trabajo", val);
    if (val) setField("importe", val.importe);
  };

  const addItem = () => {
    if (!form.trabajo) return;
    setItems((prev) => [...prev, {
      id:       prev.length + 1,
      trabajo:  form.trabajo.descripcion,
      piezas:   form.pieza,
      importe:  form.importe,
      cantidad: form.cantidad,
      total:    totalItem,
    }]);
    setField("trabajo", null);
    setField("importe", 0);
    setField("cantidad", 1);
    setField("pieza", "");
    setField("especificaciones", "");
    setField("teethSelected", []);
    setField("adicionales", {});
  };

  const removeItem = (id) => setItems((prev) => prev.filter((i) => i.id !== id));

  /* ── Input shared sx ── */
  const inp = {
    "& .MuiOutlinedInput-root": {
      backgroundColor: theme.palette.background.paper,
    },
  };

  /* ── TYPE BUTTONS (Ticket / Presupuesto) ── */
  const TypeBtn = ({ label }) => (
    <Button
      variant={form.tipo === label ? "contained" : "outlined"}
      size="small"
      onClick={() => setField("tipo", label)}
      sx={{
        flex: 1,
        ...(form.tipo !== label && {
          borderColor: theme.palette.divider,
          color: theme.palette.text.secondary,
        }),
      }}
    >
      {label}
    </Button>
  );

  return (
    <Box>
      {/* ── Page header ── */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3 }}>
        <Box>
          <Typography variant="h4" fontWeight={700}>Nuevo Trabajo</Typography>
          <Typography variant="body2" sx={{ color: theme.palette.text.secondary, mt: 0.3 }}>
            Ingreso de orden de trabajo para laboratorio
          </Typography>
        </Box>
        <Chip
          label={`Ticket #${currentTicket}`}
          sx={{
            background: alpha(theme.palette.primary.main, 0.15),
            color: theme.palette.primary.main,
            fontWeight: 800, fontSize: "0.85rem",
            border: `1px solid ${alpha(theme.palette.primary.main, 0.3)}`,
          }}
        />
      </Box>

      {/* ── Section 1: Encabezado ── */}
      <SectionCard sx={{ mb: 2.5 }}>
        <Grid container spacing={2}>
          {/* Odontólogo */}
          <Grid item xs={12} md={5}>
            <FieldLabel>Odontólogo</FieldLabel>
            <Box sx={{ display: "flex", gap: 1 }}>
              <Autocomplete
                fullWidth
                options={odontologosMock}
                getOptionLabel={(o) => o.nombre}
                value={form.odontólogo}
                onChange={(_, v) => setField("odontólogo", v)}
                renderInput={(p) => <TextField {...p} size="small" sx={inp} />}
              />
              <Tooltip title="Nuevo odontólogo">
                <IconButton size="small" color="secondary" sx={{ border: `1px solid ${theme.palette.divider}` }}>
                  <PersonAddIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>
          </Grid>

          {/* Paciente */}
          <Grid item xs={12} md={7}>
            <FieldLabel>Paciente</FieldLabel>
            <Box sx={{ display: "flex", gap: 1 }}>
              <Autocomplete
                fullWidth
                options={pacientesMock}
                getOptionLabel={(p) => `${p.nombre} - DNI: ${p.dni}`}
                value={form.paciente}
                onChange={(_, v) => setField("paciente", v)}
                renderInput={(p) => (
                  <TextField {...p} size="small" placeholder="Buscar paciente..." sx={inp} />
                )}
              />
              <Tooltip title="Nuevo paciente">
                <IconButton size="small" color="secondary" sx={{ border: `1px solid ${theme.palette.divider}` }}>
                  <PersonAddIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>
          </Grid>

          {/* Fecha desde */}
          <Grid item xs={6} sm={4} md={3}>
            <FieldLabel>Fecha desde</FieldLabel>
            <TextField fullWidth size="small" type="date"
              value={form.fechaDesde}
              onChange={(e) => setField("fechaDesde", e.target.value)}
              sx={inp}
              InputProps={{ startAdornment: <InputAdornment position="start"><CalendarTodayIcon sx={{ fontSize: 15, color: "text.secondary" }} /></InputAdornment> }}
            />
          </Grid>

          {/* Fecha hasta */}
          <Grid item xs={6} sm={4} md={3}>
            <FieldLabel>Fecha hasta</FieldLabel>
            <TextField fullWidth size="small" type="date"
              value={form.fechaHasta}
              onChange={(e) => setField("fechaHasta", e.target.value)}
              sx={inp}
              InputProps={{ startAdornment: <InputAdornment position="start"><CalendarTodayIcon sx={{ fontSize: 15, color: "text.secondary" }} /></InputAdornment> }}
            />
          </Grid>

          {/* Tipo */}
          <Grid item xs={12} sm={4} md={3}>
            <FieldLabel>Tipo</FieldLabel>
            <Box sx={{ display: "flex", gap: 1, mt: 0.5 }}>
              <TypeBtn label="Ticket" />
              <TypeBtn label="Presupuesto" />
            </Box>
          </Grid>
        </Grid>
      </SectionCard>

      {/* ── Section 2: Detalle ── */}
      <SectionCard sx={{ mb: 2.5 }}>
        {/* Tipo de lista */}
        <Box sx={{ mb: 2 }}>
          <FieldLabel>Tipo de Lista</FieldLabel>
          <RadioGroup row value={form.tipoLista} onChange={(e) => setField("tipoLista", e.target.value)} sx={{ mt: 0.3 }}>
            <FormControlLabel value="odontólogo" control={<Radio size="small" />} label={<Typography variant="body2">Lista de odontólogo</Typography>} />
            <FormControlLabel value="libre"      control={<Radio size="small" />} label={<Typography variant="body2">Lista libre</Typography>} />
          </RadioGroup>
        </Box>

        <Grid container spacing={2.5}>
          {/* ── Left column ── */}
          <Grid item xs={12} md={7}>
            {/* Trabajo selector */}
            <Box sx={{ mb: 2 }}>
              <FieldLabel>Trabajo *</FieldLabel>
              <Autocomplete
                fullWidth
                options={arancelesMock}
                getOptionLabel={(t) => t.descripcion}
                value={form.trabajo}
                onChange={(_, v) => handleWorkChange(v)}
                renderInput={(p) => <TextField {...p} size="small" sx={inp} />}
              />
            </Box>

            {/* Especificaciones */}
            <Box sx={{ mb: 2 }}>
              <FieldLabel>Especificaciones</FieldLabel>
              <TextField fullWidth multiline rows={3} size="small"
                placeholder="Detalles adicionales para la orden de trabajo"
                value={form.especificaciones}
                onChange={(e) => setField("especificaciones", e.target.value)}
                sx={inp}
              />
            </Box>

            {/* Amounts grid */}
            <Grid container spacing={1.5}>
              {[
                { label: "Importe *",  value: form.importe,   key: "importe",  prefix: "$",  readonly: false },
                { label: "Cantidad *", value: form.cantidad,  key: "cantidad", prefix: null, readonly: false },
                { label: "Total Ítem", value: totalItem,      key: null,       prefix: "$",  readonly: true  },
                { label: "Suma Total", value: sumaTotal,      key: null,       prefix: "$",  readonly: true  },
              ].map((f) => (
                <Grid item xs={6} sm={3} key={f.label}>
                  <FieldLabel>{f.label}</FieldLabel>
                  <TextField fullWidth size="small" type="number"
                    value={f.value}
                    onChange={f.readonly ? undefined : (e) => setField(f.key, Number(e.target.value))}
                    InputProps={{
                      readOnly: f.readonly,
                      startAdornment: f.prefix
                        ? <InputAdornment position="start"><Typography variant="caption" sx={{ color: "text.secondary" }}>{f.prefix}</Typography></InputAdornment>
                        : null,
                    }}
                    sx={{
                      ...inp,
                      ...(f.readonly && { "& .MuiOutlinedInput-root": { backgroundColor: alpha(theme.palette.background.paper, 0.5) } }),
                    }}
                  />
                </Grid>
              ))}
            </Grid>
          </Grid>

          {/* ── Right column ── */}
          <Grid item xs={12} md={5}>
            {/* Pieza - Color */}
            <Box sx={{ p: 2, border: `1px solid ${theme.palette.divider}`, borderRadius: 2, mb: 2 }}>
              <Typography variant="caption" sx={{
                display: "flex", alignItems: "center", gap: 0.5, mb: 1,
                fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase",
                fontSize: "0.65rem", color: theme.palette.secondary.main,
              }}>
                🦷 Pieza – Color
              </Typography>
              <Box sx={{ display: "flex", gap: 1 }}>
                <TextField fullWidth size="small" value={form.pieza}
                  placeholder="Sin pieza seleccionada"
                  InputProps={{ readOnly: true }}
                  sx={inp}
                />
                <Tooltip title="Seleccionar dientes">
                  <Button variant="outlined" size="small"
                    onClick={() => setToothOpen(true)}
                    sx={{ minWidth: 44, borderColor: theme.palette.primary.main, color: theme.palette.primary.main }}>
                    🦷
                  </Button>
                </Tooltip>
              </Box>
            </Box>

            {/* Opciones adicionales */}
            <Box sx={{ p: 2, border: `1px solid ${theme.palette.divider}`, borderRadius: 2 }}>
              <Typography variant="caption" sx={{
                display: "block", mb: 1.5,
                fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase",
                fontSize: "0.65rem", color: theme.palette.text.secondary,
              }}>
                ⚙️ Opciones Adicionales
              </Typography>
              <Grid container>
                {opcionesAdicionalesList.map((opt) => (
                  <Grid item xs={6} key={opt}>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, mb: 0.5 }}>
                      <Checkbox size="small"
                        checked={!!form.adicionales[opt]}
                        onChange={(e) => setField("adicionales", { ...form.adicionales, [opt]: e.target.checked })}
                        sx={{ p: 0.4 }}
                      />
                      <Typography variant="caption" sx={{ fontSize: "0.72rem" }}>{opt}</Typography>
                      <TextField size="small" defaultValue={0}
                        sx={{ ml: "auto", width: 42, "& input": { p: "3px 6px", fontSize: "0.72rem" }, ...inp }}
                        type="number"
                      />
                    </Box>
                  </Grid>
                ))}
              </Grid>
            </Box>
          </Grid>
        </Grid>

        {/* ── Action Buttons ── */}
        <Box sx={{ display: "flex", gap: 1.5, mt: 3, flexWrap: "wrap" }}>
          <Button variant="contained" startIcon={<SaveIcon />} color="secondary" onClick={addItem}
            disabled={!form.trabajo || !form.paciente}>
            Guardar y Continuar
          </Button>
          <Button variant="contained" startIcon={<AddIcon />} color="primary">
            Nuevo Trabajo
          </Button>
          <Button variant="contained" startIcon={<CheckCircleIcon />}
            sx={{ background: "#FFB020", "&:hover": { background: "#d4901e" }, color: "#000" }}>
            Terminar
          </Button>
          <Button variant="outlined" startIcon={<ReceiptIcon />}>
            Ticket
          </Button>
        </Box>
      </SectionCard>

      {/* ── Items Table ── */}
      {items.length > 0 && (
        <Paper>
          <Box sx={{
            px: 2.5, py: 1.5,
            borderBottom: `1px solid ${theme.palette.divider}`,
            display: "flex", alignItems: "center", justifyContent: "space-between",
          }}>
            <Typography variant="subtitle2" fontWeight={700}>Ítems del trabajo</Typography>
            <Chip label={`${items.length} ítem${items.length > 1 ? "s" : ""}`} size="small"
              sx={{ background: alpha(theme.palette.primary.main, 0.15), color: theme.palette.primary.main, fontWeight: 700 }}
            />
          </Box>
          <Box sx={{ overflowX: "auto" }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  {["#", "Descripción", "Pieza/Color", "Importe", "Cant.", "Total", ""].map((h) => (
                    <TableCell key={h}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {items.map((item) => (
                  <TableRow key={item.id} hover>
                    <TableCell>
                      <Chip label={item.id} size="small"
                        sx={{ background: alpha(theme.palette.primary.main, 0.15), color: theme.palette.primary.main, fontWeight: 700, minWidth: 28 }}
                      />
                    </TableCell>
                    <TableCell><Typography variant="body2" fontWeight={500}>{item.trabajo}</Typography></TableCell>
                    <TableCell>
                      <Typography variant="caption" sx={{ color: theme.palette.secondary.main }}>{item.piezas}</Typography>
                    </TableCell>
                    <TableCell><Typography variant="body2">{formatARS(item.importe)}</Typography></TableCell>
                    <TableCell sx={{ textAlign: "center" }}>{item.cantidad}</TableCell>
                    <TableCell>
                      <Typography variant="body2" fontWeight={700} sx={{ color: theme.palette.secondary.main }}>
                        {formatARS(item.total)}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <IconButton size="small" onClick={() => removeItem(item.id)} color="error">
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                {/* Total row */}
                <TableRow sx={{ backgroundColor: alpha(theme.palette.background.paper, 0.5) }}>
                  <TableCell colSpan={5} sx={{ textAlign: "right", fontWeight: 700, color: theme.palette.text.secondary }}>
                    TOTAL
                  </TableCell>
                  <TableCell>
                    <Typography variant="subtitle1" fontWeight={800} sx={{ color: theme.palette.secondary.main }}>
                      {formatARS(items.reduce((s, i) => s + i.total, 0))}
                    </Typography>
                  </TableCell>
                  <TableCell />
                </TableRow>
              </TableBody>
            </Table>
          </Box>
        </Paper>
      )}

      {/* ── ToothSelector Modal ── */}
      <ToothSelector
        open={toothOpen}
        onClose={() => setToothOpen(false)}
        initialTeeth={form.teethSelected}
        initialColor={form.colorSelected}
        onSave={(label, teeth, color) => {
          setField("pieza", label);
          setField("teethSelected", teeth);
          setField("colorSelected", color);
        }}
      />
    </Box>
  );
}