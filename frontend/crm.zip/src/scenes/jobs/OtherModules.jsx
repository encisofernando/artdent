import React, { useState } from 'react';
import {
  Box, Typography, Paper, Grid, Card, CardContent, Button, TextField,
  Table, TableHead, TableBody, TableRow, TableCell, Chip, IconButton,
  Stack, Divider, Avatar, List, ListItem, ListItemAvatar, ListItemText,
  Autocomplete, InputAdornment, FormControl, Select, MenuItem, Dialog,
  DialogTitle, DialogContent, DialogActions, Switch, FormControlLabel
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import SearchIcon from '@mui/icons-material/Search';
import PrintIcon from '@mui/icons-material/Print';
import ReceiptLongIcon from '@mui/icons-material/ReceiptLong';
import ScienceIcon from '@mui/icons-material/Science';
import PersonIcon from '@mui/icons-material/Person';
import BarChartIcon from '@mui/icons-material/BarChart';
import PlayCircleIcon from '@mui/icons-material/PlayCircle';
import SettingsIcon from '@mui/icons-material/Settings';
import LockResetIcon from '@mui/icons-material/LockReset';
import { artdentColors } from './theme/artdentTheme';
import { odontologos, colaboradores, formatCurrency, initialTrabajos } from '../../data/mockData';

const inputSx = { '& .MuiOutlinedInput-root': { background: artdentColors.darkSurface, '& fieldset': { borderColor: artdentColors.darkBorder } } };

// ================== FACTURACION ==================
export function FacturacionModule() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={700} sx={{ mb: 3 }}>Facturación</Typography>
      <Grid container spacing={2} sx={{ mb: 3 }}>
        {[
          { label: 'Facturas emitidas', value: '12', color: artdentColors.primary, icon: '🧾' },
          { label: 'Total facturado', value: formatCurrency(1250000), color: artdentColors.secondary, icon: '💰' },
          { label: 'Pendientes de cobro', value: '5', color: artdentColors.warning, icon: '⏳' },
          { label: 'Notas de crédito', value: '2', color: artdentColors.teal, icon: '📋' },
        ].map(stat => (
          <Grid item xs={6} sm={3} key={stat.label}>
            <Paper sx={{ p: 2, background: `${stat.color}15`, border: `1px solid ${stat.color}30`, borderRadius: 2 }}>
              <Typography variant="h3" sx={{ mb: 0.5 }}>{stat.icon}</Typography>
              <Typography variant="caption" sx={{ color: stat.color, fontWeight: 600, fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{stat.label}</Typography>
              <Typography variant="h6" fontWeight={700} sx={{ color: stat.color }}>{stat.value}</Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Paper sx={{ p: 3, background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2, mb: 3 }}>
        <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap' }}>
          <Button variant="contained" startIcon={<AddIcon />} sx={{ background: artdentColors.secondary }}>Nueva Factura</Button>
          <Button variant="outlined" startIcon={<PrintIcon />} sx={{ borderColor: artdentColors.darkBorder, color: artdentColors.textSecondary }}>Imprimir</Button>
        </Box>
        <TextField fullWidth size="small" placeholder="Buscar factura..." sx={inputSx}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment> }} />
      </Paper>

      <Paper sx={{ background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2, overflow: 'hidden' }}>
        <Table size="small">
          <TableHead>
            <TableRow>
              {['N° Factura', 'Cliente', 'Fecha', 'Importe', 'Estado', 'Acciones'].map(h => <TableCell key={h}>{h}</TableCell>)}
            </TableRow>
          </TableHead>
          <TableBody>
            {[
              { num: 'A-0001-00001056', cliente: 'Carlos Consiglio', fecha: '2026-02-25', importe: 135000, estado: 'Emitida' },
              { num: 'A-0001-00001055', cliente: 'Carlos Consiglio', fecha: '2026-02-24', importe: 220000, estado: 'Cobrada' },
              { num: 'A-0001-00001054', cliente: 'Carlos Consiglio', fecha: '2026-02-24', importe: 275000, estado: 'Cobrada' },
            ].map((f, i) => (
              <TableRow key={i}>
                <TableCell><Typography variant="body2" fontWeight={600} sx={{ color: artdentColors.primary }}>{f.num}</Typography></TableCell>
                <TableCell><Typography variant="body2">{f.cliente}</Typography></TableCell>
                <TableCell><Typography variant="caption" sx={{ color: artdentColors.textSecondary }}>{f.fecha}</Typography></TableCell>
                <TableCell><Typography variant="body2" fontWeight={700} sx={{ color: artdentColors.secondary }}>{formatCurrency(f.importe)}</Typography></TableCell>
                <TableCell>
                  <Chip label={f.estado} size="small" sx={{
                    background: f.estado === 'Cobrada' ? artdentColors.secondary + '20' : artdentColors.warning + '20',
                    color: f.estado === 'Cobrada' ? artdentColors.secondary : artdentColors.warning,
                    fontWeight: 700,
                  }} />
                </TableCell>
                <TableCell>
                  <Box sx={{ display: 'flex', gap: 0.5 }}>
                    <IconButton size="small" sx={{ color: artdentColors.primary }}><EditIcon sx={{ fontSize: 14 }} /></IconButton>
                    <IconButton size="small" sx={{ color: artdentColors.teal }}><PrintIcon sx={{ fontSize: 14 }} /></IconButton>
                  </Box>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
}

// ================== LABORATORIO ==================
export function LaboratorioModule() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={700} sx={{ mb: 3 }}>Laboratorio</Typography>
      <Grid container spacing={2} sx={{ mb: 3 }}>
        {[
          { label: 'En producción', value: '8', color: artdentColors.primary, desc: 'trabajos activos' },
          { label: 'Colaboradores', value: colaboradores.length, color: artdentColors.secondary, desc: 'activos' },
          { label: 'Entrega hoy', value: '3', color: artdentColors.warning, desc: 'trabajos' },
          { label: 'Rendimiento', value: '94%', color: artdentColors.teal, desc: 'este mes' },
        ].map(s => (
          <Grid item xs={6} sm={3} key={s.label}>
            <Paper sx={{ p: 2, background: `${s.color}15`, border: `1px solid ${s.color}30`, borderRadius: 2 }}>
              <Typography variant="caption" sx={{ color: s.color, fontWeight: 600, fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{s.label}</Typography>
              <Typography variant="h5" fontWeight={800} sx={{ color: s.color }}>{s.value}</Typography>
              <Typography variant="caption" sx={{ color: artdentColors.textSecondary }}>{s.desc}</Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="subtitle1" fontWeight={700}>Colaboradores</Typography>
              <Button size="small" variant="outlined" startIcon={<AddIcon />} sx={{ borderColor: artdentColors.secondary, color: artdentColors.secondary }}>Nuevo</Button>
            </Box>
            <Stack spacing={1.5}>
              {colaboradores.map(c => (
                <Box key={c.id} sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 1.5, background: artdentColors.darkSurface, borderRadius: 2 }}>
                  <Avatar sx={{ width: 36, height: 36, background: `linear-gradient(135deg, ${artdentColors.primary}, ${artdentColors.secondary})`, fontSize: '0.85rem', fontWeight: 700 }}>
                    {c.nombre.charAt(0)}
                  </Avatar>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="body2" fontWeight={600}>{c.nombre}</Typography>
                    <Typography variant="caption" sx={{ color: artdentColors.textSecondary }}>{c.rol}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', gap: 0.5 }}>
                    <IconButton size="small" sx={{ color: artdentColors.primary }}><EditIcon sx={{ fontSize: 14 }} /></IconButton>
                  </Box>
                </Box>
              ))}
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2 }}>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Trabajos en Proceso</Typography>
            <Stack spacing={1.5}>
              {initialTrabajos.filter(t => t.estado === 'En proceso').map(t => (
                <Box key={t.id} sx={{ p: 1.5, background: artdentColors.darkSurface, borderRadius: 2, borderLeft: `3px solid ${artdentColors.primary}` }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Chip label={`#${t.ticket}`} size="small" sx={{ background: artdentColors.primary + '20', color: artdentColors.primary, fontWeight: 700 }} />
                    <Typography variant="caption" sx={{ color: artdentColors.textSecondary }}>{t.fechaHasta}</Typography>
                  </Box>
                  <Typography variant="body2" fontWeight={600} sx={{ mt: 0.5 }}>{t.paciente}</Typography>
                  <Typography variant="caption" sx={{ color: artdentColors.textSecondary }}>{t.items?.[0]?.trabajo}</Typography>
                </Box>
              ))}
            </Stack>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}

// ================== CLIENTES/PROVEEDORES ==================
export function ClientesModule() {
  const [activeTab, setActiveTab] = useState('clientes');
  const [search, setSearch] = useState('');
  const [openNew, setOpenNew] = useState(false);
  const [form, setForm] = useState({ nombre: '', tipo: 'Odontólogo', telefono: '', email: '', direccion: '' });

  const clientes = [
    ...odontologos.map(o => ({ ...o, tipo: 'Odontólogo', email: `${o.nombre.toLowerCase().replace(' ','')}@email.com`, saldo: -350000 })),
    { id: 5, nombre: 'CLINICA DENTAL NORTE', tipo: 'Clínica', telefono: '011-4555-9999', email: 'clinica@norte.com', saldo: 120000 },
  ];

  const proveedores = [
    { id: 1, nombre: 'DENTAL SUPPLY SA', tipo: 'Materiales', telefono: '011-4444-1111', email: 'dental@supply.com', saldo: 80000 },
    { id: 2, nombre: 'IMPORT DENT', tipo: 'Importador', telefono: '011-4444-2222', email: 'import@dent.com', saldo: 45000 },
  ];

  const data = activeTab === 'clientes' ? clientes : proveedores;
  const filtered = data.filter(c => c.nombre.toLowerCase().includes(search.toLowerCase()));

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5" fontWeight={700}>Clientes / Proveedores</Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => setOpenNew(true)}
          sx={{ background: artdentColors.secondary }}>
          Nuevo
        </Button>
      </Box>

      <Box sx={{ display: 'flex', gap: 1, mb: 3, p: 1, background: artdentColors.darkSurface, borderRadius: 2, border: `1px solid ${artdentColors.darkBorder}` }}>
        {[
          { key: 'clientes', label: '👥 Clientes' },
          { key: 'proveedores', label: '🏭 Proveedores' },
        ].map(tab => (
          <Button key={tab.key} onClick={() => setActiveTab(tab.key)} variant={activeTab === tab.key ? 'contained' : 'text'}
            sx={{ flex: 1, ...(activeTab !== tab.key && { color: artdentColors.textSecondary }) }}>
            {tab.label}
          </Button>
        ))}
      </Box>

      <Paper sx={{ p: 2, mb: 2, background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2 }}>
        <TextField fullWidth size="small" placeholder="Buscar..." value={search} onChange={e => setSearch(e.target.value)} sx={inputSx}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment> }} />
      </Paper>

      <Grid container spacing={2}>
        {filtered.map(c => (
          <Grid item xs={12} sm={6} md={4} key={c.id}>
            <Paper sx={{ p: 2.5, background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2, '&:hover': { borderColor: artdentColors.primary + '60' }, transition: 'border-color 0.2s' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
                <Avatar sx={{ background: `linear-gradient(135deg, ${artdentColors.primary}, ${artdentColors.secondary})`, width: 40, height: 40, fontWeight: 700 }}>
                  {c.nombre.charAt(0)}
                </Avatar>
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Typography variant="body2" fontWeight={700} noWrap>{c.nombre}</Typography>
                  <Chip label={c.tipo} size="small" sx={{ height: 18, fontSize: '0.62rem', background: artdentColors.primary + '20', color: artdentColors.primary, fontWeight: 600 }} />
                </Box>
              </Box>
              <Typography variant="caption" sx={{ color: artdentColors.textSecondary, display: 'block' }}>📞 {c.telefono}</Typography>
              <Typography variant="caption" sx={{ color: artdentColors.textSecondary, display: 'block' }}>✉️ {c.email}</Typography>
              {c.saldo !== undefined && (
                <Box sx={{ mt: 1.5, pt: 1.5, borderTop: `1px solid ${artdentColors.darkBorder}`, display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="caption" sx={{ color: artdentColors.textSecondary }}>Saldo:</Typography>
                  <Typography variant="caption" fontWeight={700} sx={{ color: c.saldo < 0 ? artdentColors.error : artdentColors.secondary }}>
                    {formatCurrency(c.saldo)}
                  </Typography>
                </Box>
              )}
              <Box sx={{ display: 'flex', gap: 1, mt: 1.5 }}>
                <Button size="small" variant="outlined" fullWidth sx={{ fontSize: '0.7rem', borderColor: artdentColors.primary + '40', color: artdentColors.primary }}>
                  Ver cuenta
                </Button>
                <IconButton size="small" sx={{ color: artdentColors.primary }}><EditIcon sx={{ fontSize: 14 }} /></IconButton>
                <IconButton size="small" sx={{ color: artdentColors.error }}><DeleteIcon sx={{ fontSize: 14 }} /></IconButton>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Dialog open={openNew} onClose={() => setOpenNew(false)} maxWidth="sm" fullWidth>
        <DialogTitle fontWeight={700}>Nuevo {activeTab === 'clientes' ? 'Cliente' : 'Proveedor'}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField fullWidth size="small" label="Nombre/Razón Social" value={form.nombre} onChange={e => setForm(f => ({...f, nombre: e.target.value}))} sx={inputSx} />
            <FormControl fullWidth size="small" sx={inputSx}>
              <Select value={form.tipo} onChange={e => setForm(f => ({...f, tipo: e.target.value}))}>
                {['Odontólogo', 'Clínica', 'Otro Lab', 'Colegio'].map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
              </Select>
            </FormControl>
            <TextField fullWidth size="small" label="Teléfono" value={form.telefono} onChange={e => setForm(f => ({...f, telefono: e.target.value}))} sx={inputSx} />
            <TextField fullWidth size="small" label="Email" value={form.email} onChange={e => setForm(f => ({...f, email: e.target.value}))} sx={inputSx} />
            <TextField fullWidth size="small" label="Dirección" value={form.direccion} onChange={e => setForm(f => ({...f, direccion: e.target.value}))} sx={inputSx} />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenNew(false)} sx={{ color: artdentColors.textSecondary }}>Cancelar</Button>
          <Button variant="contained" onClick={() => setOpenNew(false)}>Guardar</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

// ================== BALANCE ==================
export function BalanceModule() {
  const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
  const data = [980000, 1250000, 1100000, 1420000, 1380000, 1600000, 1450000, 1720000, 1550000, 1800000, 1680000, 1950000];
  const maxVal = Math.max(...data);

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} sx={{ mb: 3 }}>Balance</Typography>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        {[
          { label: 'Ingresos este mes', value: formatCurrency(1250000), change: '+12%', pos: true, color: artdentColors.secondary },
          { label: 'Egresos este mes', value: formatCurrency(420000), change: '-5%', pos: true, color: artdentColors.error },
          { label: 'Resultado', value: formatCurrency(830000), change: '+18%', pos: true, color: artdentColors.primary },
          { label: 'Trabajos en curso', value: formatCurrency(2450000), change: '+8%', pos: true, color: artdentColors.teal },
        ].map(s => (
          <Grid item xs={6} sm={3} key={s.label}>
            <Paper sx={{ p: 2, background: `${s.color}15`, border: `1px solid ${s.color}30`, borderRadius: 2 }}>
              <Typography variant="caption" sx={{ color: s.color, fontWeight: 600, fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{s.label}</Typography>
              <Typography variant="h6" fontWeight={800} sx={{ color: s.color, mt: 0.3 }}>{s.value}</Typography>
              <Chip label={s.change} size="small" sx={{ height: 18, fontSize: '0.62rem', background: s.pos ? artdentColors.secondary + '20' : artdentColors.error + '20', color: s.pos ? artdentColors.secondary : artdentColors.error, fontWeight: 700 }} />
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* Bar Chart */}
      <Paper sx={{ p: 3, background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2, mb: 3 }}>
        <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 3 }}>Facturación Anual 2026</Typography>
        <Box sx={{ display: 'flex', alignItems: 'flex-end', gap: 1, height: 160 }}>
          {data.map((val, i) => (
            <Box key={i} sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0.5 }}>
              <Box sx={{
                width: '100%',
                height: `${(val / maxVal) * 130}px`,
                background: i === 1
                  ? `linear-gradient(0deg, ${artdentColors.primary}, ${artdentColors.secondary})`
                  : `linear-gradient(0deg, ${artdentColors.primary}60, ${artdentColors.secondary}40)`,
                borderRadius: '4px 4px 0 0',
                transition: 'height 0.3s ease',
                cursor: 'pointer',
                '&:hover': { background: `linear-gradient(0deg, ${artdentColors.primary}, ${artdentColors.secondary})` },
              }} />
              <Typography variant="caption" sx={{ color: artdentColors.textSecondary, fontSize: '0.6rem' }}>{months[i]}</Typography>
            </Box>
          ))}
        </Box>
      </Paper>

      {/* Summary table */}
      <Paper sx={{ background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2, overflow: 'hidden' }}>
        <Box sx={{ p: 2, borderBottom: `1px solid ${artdentColors.darkBorder}` }}>
          <Typography variant="subtitle2" fontWeight={700}>Resumen por Odontólogo</Typography>
        </Box>
        <Table size="small">
          <TableHead>
            <TableRow>
              {['Odontólogo', 'Trabajos', 'Total facturado', 'Pendiente cobro', 'Estado'].map(h => <TableCell key={h}>{h}</TableCell>)}
            </TableRow>
          </TableHead>
          <TableBody>
            {odontologos.map((o, i) => (
              <TableRow key={o.id}>
                <TableCell><Typography variant="body2" fontWeight={600}>{o.nombre}</Typography></TableCell>
                <TableCell><Typography variant="body2">{[3,1,2,4][i]}</Typography></TableCell>
                <TableCell><Typography variant="body2" fontWeight={700} sx={{ color: artdentColors.secondary }}>{formatCurrency([630000,135000,275000,490000][i])}</Typography></TableCell>
                <TableCell><Typography variant="body2" sx={{ color: artdentColors.warning }}>{formatCurrency([180000,0,0,120000][i])}</Typography></TableCell>
                <TableCell>
                  <Chip label="Al día" size="small" sx={{ background: artdentColors.secondary + '20', color: artdentColors.secondary, fontWeight: 600 }} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
}

// ================== TUTORIALES ==================
export function TutorialesModule() {
  const tutorials = [
    { id: 1, titulo: 'Cómo crear un nuevo trabajo', duracion: '5:30', nivel: 'Básico', color: artdentColors.secondary },
    { id: 2, titulo: 'Gestión de cuenta corriente', duracion: '8:15', nivel: 'Intermedio', color: artdentColors.primary },
    { id: 3, titulo: 'Configuración de aranceles', duracion: '6:45', nivel: 'Básico', color: artdentColors.secondary },
    { id: 4, titulo: 'Facturación electrónica AFIP', duracion: '12:20', nivel: 'Avanzado', color: artdentColors.warning },
    { id: 5, titulo: 'Reportes y estadísticas', duracion: '7:10', nivel: 'Intermedio', color: artdentColors.teal },
    { id: 6, titulo: 'Gestión de clientes y proveedores', duracion: '9:50', nivel: 'Básico', color: artdentColors.secondary },
  ];

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} sx={{ mb: 1 }}>Tutoriales</Typography>
      <Typography variant="body2" sx={{ color: artdentColors.textSecondary, mb: 3 }}>Aprende a usar todas las funcionalidades del sistema</Typography>

      <Grid container spacing={2}>
        {tutorials.map(t => (
          <Grid item xs={12} sm={6} md={4} key={t.id}>
            <Paper sx={{
              overflow: 'hidden', background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2,
              '&:hover': { borderColor: t.color + '60', transform: 'translateY(-2px)' }, transition: 'all 0.2s ease',
            }}>
              <Box sx={{ height: 100, background: `linear-gradient(135deg, ${t.color}30, ${artdentColors.darkSurface})`, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
                <PlayCircleIcon sx={{ fontSize: 48, color: t.color, opacity: 0.8 }} />
                <Chip label={t.duracion} size="small" sx={{ position: 'absolute', top: 8, right: 8, background: 'rgba(0,0,0,0.6)', color: 'white', fontWeight: 600, fontSize: '0.7rem' }} />
              </Box>
              <Box sx={{ p: 2 }}>
                <Chip label={t.nivel} size="small" sx={{ background: t.color + '20', color: t.color, fontWeight: 700, fontSize: '0.65rem', mb: 1 }} />
                <Typography variant="body2" fontWeight={700}>{t.titulo}</Typography>
                <Button size="small" variant="text" startIcon={<PlayCircleIcon />} sx={{ mt: 1, color: t.color, p: 0, fontSize: '0.78rem' }}>
                  Ver tutorial
                </Button>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}

// ================== USUARIO ==================
export function UsuarioModule() {
  const [form, setForm] = useState({ nombre: 'Admin ArtDent', email: 'admin@artdent.com', rol: 'Administrador', notif: true, dark: true });
  const inputSx = { '& .MuiOutlinedInput-root': { background: artdentColors.darkSurface, '& fieldset': { borderColor: artdentColors.darkBorder } } };

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} sx={{ mb: 3 }}>Usuario</Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2, textAlign: 'center' }}>
            <Avatar sx={{ width: 80, height: 80, mx: 'auto', mb: 2, background: `linear-gradient(135deg, ${artdentColors.primary}, ${artdentColors.secondary})`, fontSize: '2rem', fontWeight: 700 }}>A</Avatar>
            <Typography variant="h6" fontWeight={700}>{form.nombre}</Typography>
            <Typography variant="body2" sx={{ color: artdentColors.textSecondary }}>{form.email}</Typography>
            <Chip label={form.rol} size="small" sx={{ mt: 1, background: artdentColors.primary + '20', color: artdentColors.primary, fontWeight: 700 }} />
            <Button variant="outlined" fullWidth startIcon={<LockResetIcon />} sx={{ mt: 3, borderColor: artdentColors.darkBorder, color: artdentColors.textSecondary }}>
              Cambiar contraseña
            </Button>
          </Paper>
        </Grid>

        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2, mb: 2 }}>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Datos del perfil</Typography>
            <Stack spacing={2}>
              <TextField fullWidth size="small" label="Nombre completo" value={form.nombre} onChange={e => setForm(f => ({...f, nombre: e.target.value}))} sx={inputSx} />
              <TextField fullWidth size="small" label="Email" value={form.email} onChange={e => setForm(f => ({...f, email: e.target.value}))} sx={inputSx} />
              <FormControl fullWidth size="small" sx={inputSx}>
                <Select value={form.rol} onChange={e => setForm(f => ({...f, rol: e.target.value}))}>
                  {['Administrador', 'Técnico', 'Recepción'].map(r => <MenuItem key={r} value={r}>{r}</MenuItem>)}
                </Select>
              </FormControl>
            </Stack>
            <Button variant="contained" sx={{ mt: 2 }}>Guardar cambios</Button>
          </Paper>

          <Paper sx={{ p: 3, background: artdentColors.darkCard, border: `1px solid ${artdentColors.darkBorder}`, borderRadius: 2 }}>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>Preferencias</Typography>
            <Stack spacing={1.5}>
              <FormControlLabel control={<Switch checked={form.notif} onChange={e => setForm(f => ({...f, notif: e.target.checked}))} color="primary" />}
                label={<Typography variant="body2">Notificaciones del sistema</Typography>} />
              <FormControlLabel control={<Switch checked={form.dark} onChange={e => setForm(f => ({...f, dark: e.target.checked}))} color="primary" />}
                label={<Typography variant="body2">Tema oscuro</Typography>} />
            </Stack>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}