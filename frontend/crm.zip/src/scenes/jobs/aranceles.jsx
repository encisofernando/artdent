// src/scenes/jobs/aranceles.jsx  →  ruta: /trabajos/aranceles
import { useState } from "react";
import {
  Box, Grid, Typography, TextField, Button, Select, MenuItem,
  FormControl, RadioGroup, FormControlLabel, Radio, Paper,
  Table, TableHead, TableBody, TableRow, TableCell, Chip,
  IconButton, InputAdornment, Tooltip, Stack, Divider,
  Dialog, DialogTitle, DialogContent, DialogActions,
  useTheme, alpha,
} from "@mui/material";
import AddIcon         from "@mui/icons-material/Add";
import EditIcon        from "@mui/icons-material/Edit";
import DeleteIcon      from "@mui/icons-material/Delete";
import SaveIcon        from "@mui/icons-material/Save";
import SearchIcon      from "@mui/icons-material/Search";
import UploadIcon      from "@mui/icons-material/Upload";
import DownloadIcon    from "@mui/icons-material/Download";
import PrintIcon       from "@mui/icons-material/Print";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";

import { arancelesMock, listasMock, formatARS } from "../../utils/trabajosData";

/* ─── Inline-editable row ─── */
function ArancelRow({ row, onUpdate, onDelete }) {
  const theme   = useTheme();
  const isDark  = theme.palette.mode === "dark";
  const [editing, setEditing] = useState(false);
  const [val,     setVal    ] = useState(row.importe);

  const confirmEdit = () => {
    onUpdate(row.id, val);
    setEditing(false);
  };

  const inp = { "& .MuiOutlinedInput-root": { backgroundColor: theme.palette.background.paper } };

  return (
    <TableRow hover>
      {/* Actions */}
      <TableCell>
        <Box sx={{ display: "flex", gap: 0.5 }}>
          <Tooltip title="Editar importe" arrow>
            <IconButton size="small" onClick={() => setEditing((p) => !p)} sx={{
              color: theme.palette.primary.main,
              background: alpha(theme.palette.primary.main, 0.1),
              borderRadius: "7px", p: 0.7,
              "&:hover": { background: alpha(theme.palette.primary.main, 0.2) },
            }}>
              <EditIcon sx={{ fontSize: 14 }} />
            </IconButton>
          </Tooltip>
          <Tooltip title="Duplicar" arrow>
            <IconButton size="small" sx={{
              color: "#FFB020",
              background: alpha("#FFB020", 0.1),
              borderRadius: "7px", p: 0.7,
              "&:hover": { background: alpha("#FFB020", 0.2) },
            }}>
              <ContentCopyIcon sx={{ fontSize: 14 }} />
            </IconButton>
          </Tooltip>
          <Tooltip title="Eliminar" arrow>
            <IconButton size="small" onClick={() => onDelete(row.id)} sx={{
              color: theme.palette.error.main,
              background: alpha(theme.palette.error.main, 0.1),
              borderRadius: "7px", p: 0.7,
              "&:hover": { background: alpha(theme.palette.error.main, 0.2) },
            }}>
              <DeleteIcon sx={{ fontSize: 14 }} />
            </IconButton>
          </Tooltip>
        </Box>
      </TableCell>

      <TableCell>
        <Typography variant="body2" fontWeight={500}>{row.descripcion}</Typography>
      </TableCell>
      <TableCell sx={{ color: theme.palette.text.secondary }}>{row.stockActual ?? 0}</TableCell>
      <TableCell sx={{ color: theme.palette.text.secondary }}>{row.stockMinimo ?? 0}</TableCell>

      {/* Editable importe */}
      <TableCell>
        {editing ? (
          <TextField
            size="small" type="number" value={val} autoFocus
            onChange={(e) => setVal(Number(e.target.value))}
            onBlur={confirmEdit}
            onKeyDown={(e) => e.key === "Enter" && confirmEdit()}
            sx={{ width: 130, ...inp }}
            InputProps={{ startAdornment: <InputAdornment position="start"><Typography variant="caption" sx={{ color: "text.secondary" }}>$</Typography></InputAdornment> }}
          />
        ) : (
          <Typography variant="body2" fontWeight={700}
            onClick={() => setEditing(true)}
            sx={{ cursor: "pointer", color: theme.palette.secondary.main, "&:hover": { textDecoration: "underline" } }}>
            {formatARS(row.importe)}
          </Typography>
        )}
      </TableCell>

      <TableCell>
        <Chip label={row.estado} size="small" sx={{
          background: alpha(theme.palette.secondary.main, 0.15),
          color: theme.palette.secondary.main,
          fontWeight: 700,
          border: `1px solid ${alpha(theme.palette.secondary.main, 0.3)}`,
        }} />
      </TableCell>
      <TableCell>
        <Chip label="IARA" size="small" sx={{
          background: alpha(theme.palette.divider, 1),
          color: theme.palette.text.secondary,
          fontWeight: 600, fontSize: "0.65rem",
        }} />
      </TableCell>
    </TableRow>
  );
}

/* ─── Nuevo Arancel Dialog ─── */
function NuevoDialog({ open, onClose, onSave }) {
  const theme = useTheme();
  const [form, setForm] = useState({ descripcion: "", importe: 0, estado: "Habilitado" });
  const inp = { "& .MuiOutlinedInput-root": { backgroundColor: theme.palette.background.paper } };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
      <DialogTitle fontWeight={700}>Nuevo Arancel</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField fullWidth label="Descripción" value={form.descripcion}
            onChange={(e) => setForm((f) => ({ ...f, descripcion: e.target.value }))} sx={inp} />
          <TextField fullWidth label="Importe" type="number" value={form.importe}
            onChange={(e) => setForm((f) => ({ ...f, importe: Number(e.target.value) }))}
            InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment> }}
            sx={inp} />
          <FormControl fullWidth sx={inp}>
            <Select value={form.estado} onChange={(e) => setForm((f) => ({ ...f, estado: e.target.value }))}>
              <MenuItem value="Habilitado">Habilitado</MenuItem>
              <MenuItem value="Deshabilitado">Deshabilitado</MenuItem>
            </Select>
          </FormControl>
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose}>Cancelar</Button>
        <Button variant="contained" onClick={() => { onSave(form); onClose(); }}>Guardar</Button>
      </DialogActions>
    </Dialog>
  );
}

/* ════════════════════════════════════ */
export default function TrabajosAranceles() {
  const theme    = useTheme();
  const [rows,   setRows]   = useState(arancelesMock);
  const [lista,  setLista]  = useState("LP1");
  const [search, setSearch] = useState("");
  const [pct,    setPct]    = useState({ tipo: "Incrementar", decimales: "Sin decimales", valor: "" });
  const [openNew, setOpenNew] = useState(false);

  const filtered = rows.filter((r) => r.descripcion.toLowerCase().includes(search.toLowerCase()));

  const handleUpdate = (id, importe) =>
    setRows((prev) => prev.map((r) => r.id === id ? { ...r, importe } : r));

  const handleDelete = (id) =>
    setRows((prev) => prev.filter((r) => r.id !== id));

  const handleNew = (form) =>
    setRows((prev) => [...prev, { id: Date.now(), ...form, stockActual: 0, stockMinimo: 0 }]);

  const handleAjuste = () => {
    if (!pct.valor) return;
    const p = parseFloat(pct.valor) / 100;
    setRows((prev) => prev.map((r) => {
      const n = pct.tipo === "Incrementar" ? r.importe * (1 + p) : r.importe * (1 - p);
      return { ...r, importe: pct.decimales === "Sin decimales" ? Math.round(n) : n };
    }));
    setPct((p) => ({ ...p, valor: "" }));
  };

  const inp = { "& .MuiOutlinedInput-root": { backgroundColor: theme.palette.background.paper } };

  return (
    <Box>
      {/* ── Header ── */}
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" fontWeight={700}>Aranceles</Typography>
        <Typography variant="body2" sx={{ color: theme.palette.text.secondary, mt: 0.3 }}>
          Gestión de precios por lista
        </Typography>
      </Box>

      {/* ── Controls ── */}
      <Paper sx={{ p: { xs: 2, md: 2.5 }, mb: 3, borderLeft: `3px solid ${theme.palette.primary.main}` }}>
        <Grid container spacing={2} alignItems="flex-end">
          {/* Lista selector */}
          <Grid item xs={12} sm={4} md={3}>
            <Typography variant="caption" sx={{ display: "block", mb: 0.5, fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase", fontSize: "0.65rem", color: theme.palette.text.secondary }}>
              Lista
            </Typography>
            <FormControl fullWidth size="small" sx={inp}>
              <Select value={lista} onChange={(e) => setLista(e.target.value)}>
                {listasMock.map((l) => <MenuItem key={l} value={l}>{l}</MenuItem>)}
              </Select>
            </FormControl>
          </Grid>
          {/* Especial */}
          <Grid item xs={12} sm={4} md={3}>
            <Typography variant="caption" sx={{ display: "block", mb: 0.5, fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase", fontSize: "0.65rem", color: theme.palette.text.secondary }}>
              Especial
            </Typography>
            <FormControl fullWidth size="small" sx={inp}>
              <Select defaultValue="TODOS...">
                <MenuItem value="TODOS...">TODOS...</MenuItem>
                <MenuItem value="IARA">IARA</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          {/* Warning */}
          <Grid item xs={12} md={6}>
            <Box sx={{ p: 1.5, background: alpha("#FFB020", 0.1), border: `1px solid ${alpha("#FFB020", 0.3)}`, borderRadius: 2 }}>
              <Typography variant="caption" sx={{ color: "#FFB020", fontWeight: 700 }}>⚠️ Atención</Typography>
              <Typography variant="caption" sx={{ display: "block", color: theme.palette.text.secondary, mt: 0.3, fontSize: "0.72rem" }}>
                El arancel deshabilitado en una lista será deshabilitado en <strong>todas</strong> las listas
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12}><Button variant="contained" startIcon={<SearchIcon />}>Buscar</Button></Grid>
        </Grid>

        <Divider sx={{ my: 2 }} />

        {/* Ajuste de precios */}
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>Ajuste de Precios</Typography>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} sm={6} md={4}>
            <RadioGroup row value={pct.tipo} onChange={(e) => setPct((p) => ({ ...p, tipo: e.target.value }))}>
              <FormControlLabel value="Incrementar"  control={<Radio size="small" />} label={<Typography variant="body2">Incrementar</Typography>} />
              <FormControlLabel value="Decrementar"  control={<Radio size="small" />} label={<Typography variant="body2">Decrementar</Typography>} />
            </RadioGroup>
            <RadioGroup row value={pct.decimales} onChange={(e) => setPct((p) => ({ ...p, decimales: e.target.value }))}>
              <FormControlLabel value="Con decimales"  control={<Radio size="small" />} label={<Typography variant="body2">Con decimales</Typography>} />
              <FormControlLabel value="Sin decimales"  control={<Radio size="small" />} label={<Typography variant="body2">Sin decimales</Typography>} />
            </RadioGroup>
          </Grid>
          <Grid item xs={6} sm={4} md={2}>
            <TextField fullWidth size="small" label="Porcentaje" type="number" value={pct.valor}
              onChange={(e) => setPct((p) => ({ ...p, valor: e.target.value }))}
              InputProps={{ endAdornment: <InputAdornment position="end">%</InputAdornment> }}
              sx={inp} />
          </Grid>
          <Grid item xs={6} sm={2} md={2}>
            <Button variant="outlined" fullWidth onClick={handleAjuste}
              sx={{ borderColor: alpha(theme.palette.secondary.main, 0.6), color: theme.palette.secondary.main }}>
              Actualizar
            </Button>
          </Grid>
        </Grid>

        <Divider sx={{ my: 2 }} />

        {/* Export/Import row */}
        <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap" }}>
          <Button variant="outlined" startIcon={<PrintIcon />}
            sx={{ borderColor: theme.palette.divider, color: theme.palette.text.secondary }}>
            Imprimir
          </Button>
          <Button variant="contained" startIcon={<UploadIcon />} color="primary">Importar</Button>
          <Button variant="contained" startIcon={<DownloadIcon />} color="secondary">Exportar</Button>
          <Button variant="contained" startIcon={<SaveIcon />} sx={{ ml: "auto" }}>Guardar</Button>
        </Box>
      </Paper>

      {/* ── Table ── */}
      <Paper>
        <Box sx={{
          px: 2, py: 1.5,
          borderBottom: `1px solid ${theme.palette.divider}`,
          display: "flex", gap: 1.5, alignItems: "center", flexWrap: "wrap",
        }}>
          <Button variant="contained" size="small" startIcon={<AddIcon />} color="secondary"
            onClick={() => setOpenNew(true)}>
            Nuevo
          </Button>
          <Button variant="outlined" size="small" startIcon={<ContentCopyIcon />}
            sx={{ borderColor: alpha("#FFB020", 0.5), color: "#FFB020" }}>
            Copiar entre listas
          </Button>
          <TextField
            size="small" placeholder="Buscar..." value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ ml: "auto", width: { xs: "100%", sm: 220 }, ...inp }}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment> }}
          />
        </Box>

        <Box sx={{ overflowX: "auto" }}>
          <Table size="small">
            <TableHead>
              <TableRow>
                {["Operación", "Descripción", "Stock Actual", "Stock Mínimo", "Importe", "Estado", "IARA"].map((h) => (
                  <TableCell key={h}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {filtered.map((r) => (
                <ArancelRow key={r.id} row={r} onUpdate={handleUpdate} onDelete={handleDelete} />
              ))}
            </TableBody>
          </Table>
        </Box>

        <Box sx={{ px: 2, py: 1, borderTop: `1px solid ${theme.palette.divider}`, display: "flex", justifyContent: "space-between" }}>
          <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>
            Mostrando {filtered.length} de {rows.length} registros
          </Typography>
          <Typography variant="caption" sx={{ color: theme.palette.secondary.main, fontWeight: 700 }}>
            Importe promedio: {formatARS(rows.reduce((s, r) => s + r.importe, 0) / rows.length)}
          </Typography>
        </Box>
      </Paper>

      <NuevoDialog open={openNew} onClose={() => setOpenNew(false)} onSave={handleNew} />
    </Box>
  );
}