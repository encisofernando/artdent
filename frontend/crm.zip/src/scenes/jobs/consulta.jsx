// src/scenes/jobs/consulta.jsx  →  ruta: /trabajos/consultar
import { useState, useMemo } from "react";
import {
  Box, Grid, Typography, TextField, Button, Autocomplete,
  Checkbox, FormControlLabel, Paper, Table, TableHead,
  TableBody, TableRow, TableCell, Chip, IconButton,
  Stack, InputAdornment, Tooltip, useTheme, alpha,
  useMediaQuery, Dialog, DialogTitle, DialogContent,
  DialogActions, Divider,
} from "@mui/material";
import SearchIcon        from "@mui/icons-material/Search";
import PrintIcon         from "@mui/icons-material/Print";
import ClearIcon         from "@mui/icons-material/Clear";
import CheckCircleIcon   from "@mui/icons-material/CheckCircle";
import VisibilityIcon    from "@mui/icons-material/Visibility";
import EditIcon          from "@mui/icons-material/Edit";
import CloseIcon         from "@mui/icons-material/Close";

import {
  odontologosMock, trabajosMock, firstOfMonth, today, formatARS,
} from "../../utils/trabajosData";

/* ─── Status chip ─── */
const EstadoChip = ({ estado }) => {
  const map = {
    "En proceso": { bg: "rgba(57,123,156,0.18)",  text: "#ACD6CE" },
    "Terminado":  { bg: "rgba(90,173,156,0.18)",  text: "#5AAD9C" },
    "Pendiente":  { bg: "rgba(255,176,32,0.18)",  text: "#FFB020" },
    "Sale hoy":   { bg: "rgba(230,57,70,0.18)",   text: "#E63946" },
  };
  const s = map[estado] ?? map["Pendiente"];
  return (
    <Chip label={estado} size="small" sx={{
      background: s.bg, color: s.text,
      fontWeight: 700, fontSize: "0.7rem",
      border: `1px solid ${alpha(s.text, 0.3)}`,
    }} />
  );
};

/* ─── Detalle Dialog ─── */
function DetalleDialog({ trabajo, open, onClose }) {
  const theme = useTheme();
  if (!trabajo) return null;
  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
      <DialogTitle sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", pb: 1 }}>
        <Box>
          <Typography variant="h6" fontWeight={700}>Detalle — Ticket #{trabajo.ticket}</Typography>
          <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{trabajo.paciente}</Typography>
        </Box>
        <IconButton size="small" onClick={onClose}><CloseIcon fontSize="small" /></IconButton>
      </DialogTitle>
      <DialogContent>
        <Grid container spacing={1.5} sx={{ mb: 2 }}>
          {[
            { l: "Odontólogo",  v: trabajo.odontólogo },
            { l: "Paciente",    v: trabajo.paciente },
            { l: "Tipo",        v: trabajo.tipo },
            { l: "Estado",      v: <EstadoChip estado={trabajo.estado} /> },
            { l: "Fecha Desde", v: trabajo.fechaDesde },
            { l: "Fecha Hasta", v: trabajo.fechaHasta },
            { l: "Entrega",     v: trabajo.estadoEntrega },
            { l: "Alta",        v: trabajo.fechaAlta },
          ].map(({ l, v }) => (
            <Grid item xs={6} key={l}>
              <Typography variant="caption" sx={{ color: theme.palette.text.secondary, fontWeight: 700, textTransform: "uppercase", fontSize: "0.62rem", letterSpacing: "0.06em" }}>{l}</Typography>
              <Box sx={{ mt: 0.3 }}>
                {typeof v === "string"
                  ? <Typography variant="body2" fontWeight={600}>{v || "—"}</Typography>
                  : v}
              </Box>
            </Grid>
          ))}
        </Grid>
        <Divider sx={{ mb: 2 }} />
        <Typography variant="caption" sx={{ color: theme.palette.text.secondary, fontWeight: 700, textTransform: "uppercase", fontSize: "0.65rem", letterSpacing: "0.07em" }}>Ítems</Typography>
        <Paper sx={{ mt: 1, overflow: "hidden" }}>
          <Table size="small">
            <TableHead>
              <TableRow>
                {["Trabajo", "Pieza/Color", "Importe", "Cant.", "Total"].map((h) => <TableCell key={h}>{h}</TableCell>)}
              </TableRow>
            </TableHead>
            <TableBody>
              {trabajo.items.map((item) => (
                <TableRow key={item.id} hover>
                  <TableCell><Typography variant="body2">{item.trabajo}</Typography></TableCell>
                  <TableCell><Typography variant="caption" sx={{ color: theme.palette.secondary.main }}>{item.piezas}</Typography></TableCell>
                  <TableCell>{formatARS(item.importe)}</TableCell>
                  <TableCell sx={{ textAlign: "center" }}>{item.cantidad}</TableCell>
                  <TableCell><Typography fontWeight={700} sx={{ color: theme.palette.secondary.main }}>{formatARS(item.total)}</Typography></TableCell>
                </TableRow>
              ))}
              <TableRow>
                <TableCell colSpan={4} sx={{ textAlign: "right", fontWeight: 700, color: theme.palette.text.secondary }}>TOTAL</TableCell>
                <TableCell><Typography variant="subtitle2" fontWeight={800} sx={{ color: theme.palette.secondary.main }}>{formatARS(trabajo.total)}</Typography></TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </Paper>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button variant="outlined" startIcon={<PrintIcon />}>Imprimir Ticket</Button>
        <Button variant="contained" onClick={onClose}>Cerrar</Button>
      </DialogActions>
    </Dialog>
  );
}

/* ════════════════════════════════════ */
export default function TrabajosConsulta() {
  const theme    = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const [filters, setFilters] = useState({
    nro:        "",
    odontólogo: odontologosMock[0].nombre,
    paciente:   "",
    fechaDesde: firstOfMonth,
    fechaHasta: "2026-12-31",
    ticket:     true,
    presupuesto: false,
  });

  const [results,  setResults]  = useState(trabajosMock);
  const [detalle,  setDetalle]  = useState(null);

  const handleBuscar = () => {
    let r = [...trabajosMock];
    if (filters.nro)       r = r.filter((t) => t.ticket.includes(filters.nro));
    if (filters.paciente)  r = r.filter((t) => t.paciente.toLowerCase().includes(filters.paciente.toLowerCase()));
    if (filters.odontólogo) r = r.filter((t) => t.odontólogo.toLowerCase().includes(filters.odontólogo.toLowerCase()));
    setResults(r);
  };

  const handleLimpiar = () => {
    setFilters((f) => ({ ...f, nro: "", paciente: "" }));
    setResults(trabajosMock);
  };

  const stats = useMemo(() => ({
    pendientes: results.filter((t) => t.estado === "Pendiente").length,
    enProceso:  results.filter((t) => t.estado === "En proceso").length,
    terminados: results.filter((t) => t.estado === "Terminado").length,
    total:      results.reduce((s, t) => s + t.total, 0),
  }), [results]);

  /* ── shared input sx ── */
  const inp = { "& .MuiOutlinedInput-root": { backgroundColor: theme.palette.background.paper } };

  /* ── border color by estado ── */
  const borderBy = (e) =>
    e === "En proceso" ? "#397B9C" : e === "Terminado" ? "#5AAD9C" : "#FFB020";

  return (
    <Box>
      {/* ── Page header ── */}
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" fontWeight={700}>Consulta de Trabajos</Typography>
        <Typography variant="body2" sx={{ color: theme.palette.text.secondary, mt: 0.3 }}>
          Búsqueda y gestión de órdenes de trabajo
        </Typography>
      </Box>

      {/* ── KPI chips ── */}
      <Grid container spacing={1.5} sx={{ mb: 3 }}>
        {[
          { label: "Pendientes", value: stats.pendientes, color: "#FFB020" },
          { label: "En Proceso", value: stats.enProceso,  color: "#397B9C" },
          { label: "Terminados", value: stats.terminados, color: "#5AAD9C" },
          { label: "Total",      value: formatARS(stats.total), color: "#49949C" },
        ].map((s) => (
          <Grid item xs={6} sm={3} key={s.label}>
            <Paper sx={{
              p: 1.5,
              borderLeft: `3px solid ${s.color}`,
              background: alpha(s.color, 0.07),
            }}>
              <Typography variant="caption" sx={{ color: s.color, fontWeight: 700, fontSize: "0.65rem", textTransform: "uppercase", letterSpacing: "0.06em" }}>
                {s.label}
              </Typography>
              <Typography variant="h6" fontWeight={800} sx={{ color: s.color }}>{s.value}</Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* ── Filtros ── */}
      <Paper sx={{ p: { xs: 2, md: 2.5 }, mb: 3, borderLeft: `3px solid ${theme.palette.primary.main}` }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 2, color: theme.palette.primary.main }}>
          Filtros de Búsqueda
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={6} sm={3} md={2}>
            <TextField fullWidth size="small" label="N°" value={filters.nro}
              onChange={(e) => setFilters((f) => ({ ...f, nro: e.target.value }))} sx={inp} />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <Autocomplete
              options={odontologosMock.map((o) => o.nombre)}
              value={filters.odontólogo}
              onChange={(_, v) => setFilters((f) => ({ ...f, odontólogo: v || "" }))}
              renderInput={(p) => <TextField {...p} size="small" label="Odontólogo" sx={inp} />}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <TextField fullWidth size="small" label="Paciente" value={filters.paciente}
              onChange={(e) => setFilters((f) => ({ ...f, paciente: e.target.value }))} sx={inp} />
          </Grid>
          <Grid item xs={6} sm={3} md={2}>
            <TextField fullWidth size="small" type="date" label="Desde"
              value={filters.fechaDesde}
              onChange={(e) => setFilters((f) => ({ ...f, fechaDesde: e.target.value }))}
              InputLabelProps={{ shrink: true }} sx={inp} />
          </Grid>
          <Grid item xs={6} sm={3} md={2}>
            <TextField fullWidth size="small" type="date" label="Hasta"
              value={filters.fechaHasta}
              onChange={(e) => setFilters((f) => ({ ...f, fechaHasta: e.target.value }))}
              InputLabelProps={{ shrink: true }} sx={inp} />
          </Grid>
          <Grid item xs={12}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 2, flexWrap: "wrap" }}>
              <FormControlLabel
                control={<Checkbox size="small" checked={filters.ticket} onChange={(e) => setFilters((f) => ({ ...f, ticket: e.target.checked }))} />}
                label={<Typography variant="body2">Ticket</Typography>}
              />
              <FormControlLabel
                control={<Checkbox size="small" checked={filters.presupuesto} onChange={(e) => setFilters((f) => ({ ...f, presupuesto: e.target.checked }))} />}
                label={<Typography variant="body2">Presupuesto</Typography>}
              />
              <Box sx={{ display: "flex", gap: 1, ml: "auto", flexWrap: "wrap" }}>
                <Button variant="contained" startIcon={<SearchIcon />} onClick={handleBuscar}>Buscar</Button>
                <Button variant="outlined" startIcon={<PrintIcon />}
                  sx={{ borderColor: theme.palette.divider, color: theme.palette.text.secondary }}>
                  Imprimir
                </Button>
                <Button variant="outlined" startIcon={<ClearIcon />} onClick={handleLimpiar}
                  sx={{ borderColor: alpha("#FFB020", 0.5), color: "#FFB020" }}>
                  Limpiar
                </Button>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Paper>

      {/* ── Results ── */}
      <Paper>
        {/* Toolbar */}
        <Box sx={{
          px: 2, py: 1.5,
          borderBottom: `1px solid ${theme.palette.divider}`,
          display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 1,
        }}>
          <Typography variant="subtitle2" fontWeight={700}>
            Resultados{" "}
            <Typography component="span" variant="caption" sx={{ color: theme.palette.text.secondary }}>
              ({results.length} registro{results.length !== 1 ? "s" : ""})
            </Typography>
          </Typography>
          <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap" }}>
            <Button size="small" variant="outlined"
              startIcon={<CheckCircleIcon sx={{ fontSize: 14 }} />}
              sx={{ borderColor: alpha(theme.palette.secondary.main, 0.5), color: theme.palette.secondary.main, fontSize: "0.72rem" }}>
              Terminar seleccionados
            </Button>
            <Button size="small" variant="outlined"
              startIcon={<PrintIcon sx={{ fontSize: 14 }} />}
              sx={{ borderColor: alpha(theme.palette.primary.main, 0.5), color: theme.palette.primary.main, fontSize: "0.72rem" }}>
              Imprimir tickets
            </Button>
          </Box>
        </Box>

        {/* Mobile: card list */}
        {isMobile ? (
          <Stack spacing={1.5} sx={{ p: 2 }}>
            {results.map((t) => (
              <Box key={t.id} sx={{
                p: 2, border: `1px solid ${theme.palette.divider}`,
                borderLeft: `4px solid ${borderBy(t.estado)}`,
                borderRadius: "12px",
                background: theme.palette.background.paper,
              }}>
                <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1 }}>
                  <Chip label={`#${t.ticket}`} size="small" sx={{ background: alpha("#397B9C", 0.15), color: "#397B9C", fontWeight: 700 }} />
                  <EstadoChip estado={t.estado} />
                </Box>
                <Typography variant="body2" fontWeight={700}>{t.paciente}</Typography>
                <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{t.odontólogo}</Typography>
                <Box sx={{ display: "flex", justifyContent: "space-between", mt: 1.5 }}>
                  <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{t.fechaDesde}</Typography>
                  <Typography variant="body2" fontWeight={800} sx={{ color: "#5AAD9C" }}>{formatARS(t.total)}</Typography>
                </Box>
                <Button size="small" startIcon={<VisibilityIcon sx={{ fontSize: 13 }} />}
                  onClick={() => setDetalle(t)}
                  sx={{ mt: 1, color: theme.palette.primary.main, p: 0, fontSize: "0.72rem" }}>
                  Ver detalle
                </Button>
              </Box>
            ))}
          </Stack>
        ) : (
          /* Desktop: table */
          <Box sx={{ overflowX: "auto" }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell padding="checkbox"><Checkbox size="small" /></TableCell>
                  {["Ticket", "Clínica", "Odontólogo", "Paciente", "Fec. Desde", "Fec. Hasta", "Total", "Estado", "Entrega", "Alta", "Opciones"].map((h) => (
                    <TableCell key={h}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {results.map((t) => (
                  <TableRow key={t.id} hover
                    sx={{ borderLeft: `3px solid ${borderBy(t.estado)}` }}>
                    <TableCell padding="checkbox"><Checkbox size="small" /></TableCell>
                    <TableCell>
                      <Chip label={t.ticket} size="small" sx={{ background: alpha("#397B9C", 0.15), color: "#397B9C", fontWeight: 700 }} />
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{t.clinica || "—"}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 500, fontSize: "0.8rem" }}>{t.odontólogo}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" fontWeight={600}>{t.paciente}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{t.fechaDesde}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{t.fechaHasta}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" fontWeight={700} sx={{ color: "#5AAD9C" }}>{formatARS(t.total)}</Typography>
                    </TableCell>
                    <TableCell><EstadoChip estado={t.estado} /></TableCell>
                    <TableCell>
                      <Chip label={t.estadoEntrega || "Pendiente"} size="small" sx={{ background: alpha("#FFB020", 0.15), color: "#FFB020", fontWeight: 600 }} />
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" sx={{ color: theme.palette.text.secondary, fontSize: "0.68rem" }}>{t.fechaAlta}</Typography>
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: "flex", gap: 0.5 }}>
                        <Tooltip title="Ver detalle">
                          <IconButton size="small" sx={{ color: theme.palette.primary.main }} onClick={() => setDetalle(t)}>
                            <VisibilityIcon sx={{ fontSize: 16 }} />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Editar">
                          <IconButton size="small" sx={{ color: theme.palette.secondary.main }}>
                            <EditIcon sx={{ fontSize: 16 }} />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        )}

        <Box sx={{ px: 2, py: 1, borderTop: `1px solid ${theme.palette.divider}` }}>
          <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>
            Mostrando {results.length} de {trabajosMock.length} registros
          </Typography>
        </Box>
      </Paper>

      {/* ── Detalle Dialog ── */}
      <DetalleDialog trabajo={detalle} open={Boolean(detalle)} onClose={() => setDetalle(null)} />
    </Box>
  );
}