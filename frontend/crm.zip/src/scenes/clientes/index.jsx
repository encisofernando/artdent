// src/scenes/clientes/index.jsx
// Hub unificado de Clientes — CRM · Laboratorio · E-commerce
// ✅ Conectado a API real vía customerService
import React, { useState, useMemo, useCallback, useEffect } from "react";
import {
  Box, Grid, Typography, TextField, Button, Paper,
  Table, TableHead, TableBody, TableRow, TableCell,
  Chip, IconButton, Stack, Avatar, Tooltip, InputAdornment,
  Tabs, Tab, CircularProgress, useTheme, useMediaQuery, alpha,
  Select, MenuItem, FormControl, Divider, Alert,
} from "@mui/material";

import SearchIcon          from "@mui/icons-material/Search";
import AddIcon             from "@mui/icons-material/Add";
import RefreshIcon         from "@mui/icons-material/Refresh";
import VisibilityIcon      from "@mui/icons-material/Visibility";
import EditIcon            from "@mui/icons-material/Edit";
import WhatsAppIcon        from "@mui/icons-material/WhatsApp";
import WorkIcon            from "@mui/icons-material/Work";
import StorefrontIcon      from "@mui/icons-material/Storefront";
import ScienceIcon         from "@mui/icons-material/Science";
import PeopleIcon          from "@mui/icons-material/People";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import TrendingUpIcon      from "@mui/icons-material/TrendingUp";

import customerService from "../../services/customerService";
import Ficha           from "./Ficha";
import ClienteForm     from "./ClienteForm";
import ClienteFormEdit from "./ClienteFormEdit";

const formatARS = (n = 0) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(Number(n) || 0);

const CONTEXT_TABS = [
  { label: "Todos",        key: "todos"     },
  { label: "Laboratorio",  key: "lab"       },
  { label: "E-commerce",   key: "ecommerce" },
];

const ClientAvatar = ({ name, size = 38 }) => {
  const initials = (name || "?").split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  return (
    <Avatar sx={{
      width: size, height: size,
      background: "linear-gradient(135deg, #397B9C 0%, #5AAD9C 100%)",
      fontSize: size * 0.37, fontWeight: 800, flexShrink: 0,
    }}>
      {initials}
    </Avatar>
  );
};

const ContextChips = ({ cliente }) => (
  <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
    {cliente.es_odontologo && (
      <Chip icon={<ScienceIcon sx={{ fontSize: 11 }} />} label="Lab"
        size="small" sx={{ background: alpha("#397B9C", 0.13), color: "#397B9C", fontWeight: 700, fontSize: "0.65rem", "& .MuiChip-icon": { color: "#397B9C" } }} />
    )}
    {cliente.es_cliente_insumos && (
      <Chip icon={<StorefrontIcon sx={{ fontSize: 11 }} />} label="E-comm"
        size="small" sx={{ background: alpha("#5AAD9C", 0.13), color: "#5AAD9C", fontWeight: 700, fontSize: "0.65rem", "& .MuiChip-icon": { color: "#5AAD9C" } }} />
    )}
  </Stack>
);

const KpiCard = ({ label, value, color, icon }) => (
  <Paper sx={{
    p: 2, borderLeft: `3px solid ${color}`, background: alpha(color, 0.06),
    display: "flex", gap: 1.5, alignItems: "center",
  }}>
    <Box sx={{ width: 36, height: 36, borderRadius: "10px", background: alpha(color, 0.15),
      display: "grid", placeItems: "center", color, flexShrink: 0 }}>
      {icon}
    </Box>
    <Box>
      <Typography variant="caption" sx={{ fontWeight: 700, color, fontSize: "0.62rem", textTransform: "uppercase", letterSpacing: "0.07em" }}>
        {label}
      </Typography>
      <Typography variant="subtitle1" fontWeight={800} sx={{ color, lineHeight: 1.2 }}>{value}</Typography>
    </Box>
  </Paper>
);

export default function Clientes() {
  const theme    = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const [contextTab, setContextTab] = useState(0);
  const [search,     setSearch]     = useState("");
  const [estado,     setEstado]     = useState("todos");
  const [loading,    setLoading]    = useState(true);
  const [error,      setError]      = useState("");
  const [clientes,   setClientes]   = useState([]);
  const [kpis,       setKpis]       = useState({ total: 0, lab: 0, ecomm: 0, pendientes: 0, facturacion: 0 });

  const [fichaOpen,    setFichaOpen]    = useState(false);
  const [fichaCliente, setFichaCliente] = useState(null);
  const [newOpen,      setNewOpen]      = useState(false);
  const [editOpen,     setEditOpen]     = useState(false);
  const [editCliente,  setEditCliente]  = useState(null);

  const inp = { "& .MuiOutlinedInput-root": { backgroundColor: theme.palette.background.paper } };

  // ── Fetch clientes ──────────────────────────────────────────────────────
  const fetchClientes = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [clientesRes, kpisRes] = await Promise.all([
        customerService.getCustomers({
          search:     search || undefined,
          context:    CONTEXT_TABS[contextTab].key,
          estado,
          with_stats: true,
          per_page:   100,
        }),
        customerService.getCustomerKpis(),
      ]);
      // Soporta respuesta paginada { data: [...] } o array directo
      setClientes(clientesRes.data ?? clientesRes ?? []);
      setKpis(kpisRes);
    } catch (e) {
      console.error("[Clientes] fetch error:", e);
      setError("Error al cargar clientes. Verificá tu conexión.");
    } finally {
      setLoading(false);
    }
  }, [search, contextTab, estado]);

  useEffect(() => { fetchClientes(); }, [fetchClientes]);

  // ── Filtrado local (sobre la respuesta ya filtrada por server) ──────────
  const filtered = useMemo(() => clientes, [clientes]);

  const saldoColor = (s) => s >= 0 ? "#5AAD9C" : "#E63946";

  const openFicha = (c) => { setFichaCliente(c); setFichaOpen(true); };
  const openEdit  = (c) => { setEditCliente(c);  setEditOpen(true); };

  // ── Mobile card ─────────────────────────────────────────────────────────
  const MobileCard = ({ c }) => (
    <Paper sx={{ p: 1.75, borderLeft: `4px solid ${c.es_odontologo ? "#397B9C" : "#5AAD9C"}`, display: "flex", gap: 1.5 }}>
      <ClientAvatar name={c.name} />
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <Typography variant="body2" fontWeight={700} sx={{ lineHeight: 1.2 }}>{c.name}</Typography>
          <Typography variant="caption" fontWeight={700} sx={{ color: saldoColor(c.saldo), flexShrink: 0, ml: 1 }}>
            {formatARS(c.saldo)}
          </Typography>
        </Box>
        <Typography variant="caption" sx={{ color: theme.palette.text.secondary, display: "block" }}>
          {c.clinica || c.email || "—"}
        </Typography>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mt: 1 }}>
          <ContextChips cliente={c} />
          <Button size="small" onClick={() => openFicha(c)} sx={{ fontSize: "0.7rem", p: "2px 8px", color: theme.palette.primary.main }}>
            Ver ficha
          </Button>
        </Box>
      </Box>
    </Paper>
  );

  return (
    <Box>
      {/* ── Header ── */}
      <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", mb: 3, gap: 2, flexWrap: "wrap" }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Clientes</Typography>
          <Typography variant="body2" sx={{ color: theme.palette.text.secondary, mt: 0.3 }}>
            Gestión unificada — Laboratorio · E-commerce · CRM
          </Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Tooltip title="Actualizar">
            <IconButton size="small" onClick={fetchClientes} sx={{ border: `1px solid ${theme.palette.divider}` }}>
              <RefreshIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <Button variant="contained" startIcon={<AddIcon />} color="primary" onClick={() => setNewOpen(true)}>
            Nuevo Cliente
          </Button>
        </Stack>
      </Box>

      {/* ── Error ── */}
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* ── KPIs ── */}
      <Grid container spacing={1.5} sx={{ mb: 3 }}>
        <Grid item xs={6} sm={3} md={2.4}>
          <KpiCard label="Total clientes" value={kpis.total} color="#397B9C" icon={<PeopleIcon sx={{ fontSize: 18 }} />} />
        </Grid>
        <Grid item xs={6} sm={3} md={2.4}>
          <KpiCard label="Odontólogos/Lab" value={kpis.lab} color="#49949C" icon={<ScienceIcon sx={{ fontSize: 18 }} />} />
        </Grid>
        <Grid item xs={6} sm={3} md={2.4}>
          <KpiCard label="E-commerce" value={kpis.ecomm} color="#5AAD9C" icon={<StorefrontIcon sx={{ fontSize: 18 }} />} />
        </Grid>
        <Grid item xs={6} sm={3} md={2.4}>
          <KpiCard label="OT Pendientes" value={kpis.pendientes} color="#FFB020" icon={<WorkIcon sx={{ fontSize: 18 }} />} />
        </Grid>
        <Grid item xs={12} sm={6} md={2.4}>
          <KpiCard label="Facturación mes" value={formatARS(kpis.facturacion)} color="#ACD6CE" icon={<TrendingUpIcon sx={{ fontSize: 18 }} />} />
        </Grid>
      </Grid>

      {/* ── Context tabs + filtros ── */}
      <Paper sx={{ mb: 2 }}>
        <Tabs
          value={contextTab}
          onChange={(_, v) => setContextTab(v)}
          sx={{
            px: 2, borderBottom: `1px solid ${theme.palette.divider}`,
            "& .MuiTab-root": { fontWeight: 700, textTransform: "none", fontSize: "0.82rem" },
            "& .Mui-selected": { color: theme.palette.primary.main },
            "& .MuiTabs-indicator": { backgroundColor: theme.palette.primary.main },
          }}
        >
          {CONTEXT_TABS.map((t, i) => (
            <Tab key={i} label={
              <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
                {t.label}
                <Chip label={t.key === "todos" ? kpis.total : t.key === "lab" ? kpis.lab : kpis.ecomm}
                  size="small" sx={{ height: 18, fontSize: "0.65rem", fontWeight: 700 }} />
              </Box>
            } />
          ))}
        </Tabs>

        <Box sx={{ p: { xs: 1.5, md: 2 }, display: "flex", gap: 1.5, flexWrap: "wrap", alignItems: "center" }}>
          <TextField
            size="small" placeholder="Buscar por nombre, CUIT, email…"
            value={search} onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && fetchClientes()}
            sx={{ flex: "1 1 220px", maxWidth: 360, ...inp }}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18, color: "text.secondary" }} /></InputAdornment> }}
          />
          <FormControl size="small" sx={{ minWidth: 140, ...inp }}>
            <Select value={estado} onChange={(e) => setEstado(e.target.value)}>
              <MenuItem value="todos">Estado: Todos</MenuItem>
              <MenuItem value="activos">Activos</MenuItem>
              <MenuItem value="inactivos">Inactivos</MenuItem>
            </Select>
          </FormControl>
          <Typography variant="caption" sx={{ color: theme.palette.text.secondary, ml: "auto" }}>
            {filtered.length} resultado{filtered.length !== 1 ? "s" : ""}
          </Typography>
        </Box>
      </Paper>

      {/* ── Content ── */}
      {loading ? (
        <Box sx={{ display: "grid", placeItems: "center", py: 8 }}>
          <CircularProgress sx={{ color: "#397B9C" }} />
        </Box>
      ) : isMobile ? (
        <Stack spacing={1.5}>
          {filtered.map((c) => <MobileCard key={c.id} c={c} />)}
        </Stack>
      ) : (
        <Paper sx={{ overflow: "hidden" }}>
          <Box sx={{ overflowX: "auto" }}>
            <Table>
              <TableHead>
                <TableRow>
                  {["Cliente", "Contexto", "Contacto", "Trabajos Lab", "Pedidos", "Saldo", "Última actividad", ""].map((h) => (
                    <TableCell key={h} sx={{ fontWeight: 700, fontSize: "0.72rem", textTransform: "uppercase", letterSpacing: "0.05em", color: theme.palette.text.secondary, whiteSpace: "nowrap" }}>
                      {h}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {filtered.map((c) => (
                  <TableRow key={c.id} hover sx={{ cursor: "pointer", "&:hover .row-actions": { opacity: 1 } }}
                    onClick={() => openFicha(c)}>
                    <TableCell>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                        <ClientAvatar name={c.name} size={34} />
                        <Box>
                          <Typography variant="body2" fontWeight={700}>{c.name}</Typography>
                          <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{c.code} · {c.tax_id || "—"}</Typography>
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell><ContextChips cliente={c} /></TableCell>
                    <TableCell>
                      <Typography variant="caption" sx={{ display: "block" }}>{c.email || "—"}</Typography>
                      <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{c.phone || "—"}</Typography>
                    </TableCell>
                    <TableCell>
                      {c.es_odontologo ? (
                        <Box>
                          {c.trabajos_pendientes > 0 && (
                            <Chip label={`${c.trabajos_pendientes} pend.`} size="small"
                              sx={{ background: alpha("#FFB020", 0.15), color: "#FFB020", fontWeight: 700, mr: 0.5 }} />
                          )}
                          <Typography variant="body2" fontWeight={700} sx={{ color: "#397B9C" }}>
                            {formatARS(c.monto_trabajos_mes)}
                            <Typography component="span" variant="caption" sx={{ color: "text.secondary" }}>/mes</Typography>
                          </Typography>
                        </Box>
                      ) : <Typography variant="caption" sx={{ color: "text.disabled" }}>—</Typography>}
                    </TableCell>
                    <TableCell>
                      {c.es_cliente_insumos ? (
                        <Box>
                          <Typography variant="body2" fontWeight={600} sx={{ color: "#5AAD9C" }}>{c.pedidos_total} pedidos</Typography>
                          <Typography variant="caption" sx={{ color: "text.secondary" }}>{formatARS(c.monto_pedidos_mes)}/mes</Typography>
                        </Box>
                      ) : <Typography variant="caption" sx={{ color: "text.disabled" }}>—</Typography>}
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" fontWeight={800} sx={{ color: saldoColor(c.saldo) }}>
                        {formatARS(c.saldo)}
                      </Typography>
                      <Typography variant="caption" sx={{ color: "text.secondary" }}>límite {formatARS(c.credit_limit)}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{c.ultima_actividad || "—"}</Typography>
                    </TableCell>
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <Stack direction="row" spacing={0.5} className="row-actions" sx={{ opacity: 0, transition: "opacity .15s" }}>
                        <Tooltip title="Ver ficha">
                          <IconButton size="small" sx={{ color: theme.palette.primary.main }} onClick={() => openFicha(c)}>
                            <VisibilityIcon sx={{ fontSize: 16 }} />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Editar">
                          <IconButton size="small" sx={{ color: theme.palette.secondary.main }} onClick={() => openEdit(c)}>
                            <EditIcon sx={{ fontSize: 16 }} />
                          </IconButton>
                        </Tooltip>
                        {c.phone && (
                          <Tooltip title="WhatsApp">
                            <IconButton size="small" sx={{ color: "#25D366" }}
                              onClick={() => window.open(`https://wa.me/${c.phone.replace(/\D/g, "")}`, "_blank")}>
                              <WhatsAppIcon sx={{ fontSize: 16 }} />
                            </IconButton>
                          </Tooltip>
                        )}
                      </Stack>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
          <Box sx={{ px: 2, py: 1, borderTop: `1px solid ${theme.palette.divider}` }}>
            <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>
              {filtered.length} clientes
            </Typography>
          </Box>
        </Paper>
      )}

      {/* ── Dialogs ── */}
      <Ficha
        open={fichaOpen}
        onClose={() => setFichaOpen(false)}
        cliente={fichaCliente}
        onEdit={() => { setFichaOpen(false); openEdit(fichaCliente); }}
      />

      <ClienteForm
        open={newOpen}
        onClose={() => setNewOpen(false)}
        onCreated={() => { setNewOpen(false); fetchClientes(); }}
      />

      {editOpen && editCliente && (
        <Box sx={{ position: "fixed", inset: 0, zIndex: 1300, display: "flex", alignItems: "center", justifyContent: "center",
          bgcolor: "rgba(0,0,0,.5)", backdropFilter: "blur(4px)" }}
          onClick={() => setEditOpen(false)}
        >
          <Paper sx={{ width: "100%", maxWidth: 700, maxHeight: "90vh", overflow: "auto", borderRadius: 3 }}
            onClick={(e) => e.stopPropagation()}>
            <ClienteFormEdit
              open={editOpen}
              onClose={() => setEditOpen(false)}
              cliente={editCliente}
              onUpdated={() => { setEditOpen(false); fetchClientes(); }}
            />
          </Paper>
        </Box>
      )}
    </Box>
  );
}