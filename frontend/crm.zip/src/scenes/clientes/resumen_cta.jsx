// src/scenes/clientes/resumen_cta.jsx
// ✅ Conectado a API real vía customerService
import React, { useState, useCallback } from "react";
import {
  Box, Grid, Stack, TextField, Typography, Button, Autocomplete,
  Paper, Divider, CircularProgress, useMediaQuery, useTheme, alpha,
  Alert, IconButton, Chip, Tooltip,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import SearchIcon          from "@mui/icons-material/Search";
import PrintIcon           from "@mui/icons-material/Print";
import EmailIcon           from "@mui/icons-material/Email";
import WhatsAppIcon        from "@mui/icons-material/WhatsApp";
import AddCircleIcon       from "@mui/icons-material/AddCircle";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import TrendingDownIcon    from "@mui/icons-material/TrendingDown";
import TrendingUpIcon      from "@mui/icons-material/TrendingUp";
import ReceiptLongIcon     from "@mui/icons-material/ReceiptLong";
import CloseIcon           from "@mui/icons-material/Close";

import customerService from "../../services/customerService";

const formatARS = (n = 0) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(Number(n) || 0);

const TIPO_TABS = ["Clínica", "Odontólogo", "Otro Lab", "Colegio"];

// ── Summary Card ─────────────────────────────────────────────────────────────
const SummaryCard = ({ label, value, color, icon, sub }) => {
  const theme = useTheme();
  return (
    <Paper sx={{
      p: { xs: 1.5, md: 2 }, flex: 1,
      borderLeft: `3px solid ${color}`,
      background: alpha(color, 0.06),
    }}>
      <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 0.5 }}>
        <Box sx={{
          width: 32, height: 32, borderRadius: "9px",
          background: alpha(color, 0.15), display: "grid", placeItems: "center",
          color, flexShrink: 0,
        }}>
          {icon}
        </Box>
        <Typography variant="caption" sx={{
          fontWeight: 700, color, textTransform: "uppercase",
          letterSpacing: "0.07em", fontSize: "0.6rem",
        }}>
          {label}
        </Typography>
      </Box>
      <Typography variant="h6" fontWeight={900} sx={{ color, lineHeight: 1.2 }}>
        {typeof value === "number" ? formatARS(value) : value}
      </Typography>
      {sub && (
        <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>
          {sub}
        </Typography>
      )}
    </Paper>
  );
};

export default function ResumenCta() {
  const theme  = useTheme();
  const isDark = theme.palette.mode === "dark";
  const isXs   = useMediaQuery(theme.breakpoints.down("sm"));

  const [tipoTab, setTipoTab] = useState(0);

  // Búsqueda
  const [clienteOptions, setClienteOptions]   = useState([]);
  const [clienteLoading, setClienteLoading]   = useState(false);
  const [clienteSel,     setClienteSel]        = useState(null);
  const [desde,          setDesde]             = useState("");
  const [hasta,          setHasta]             = useState("");

  // Resultados
  const [rows,    setRows]    = useState([]);
  const [summary, setSummary] = useState({ saldo_anterior: 0, suma_deuda: 0, suma_pagos: 0, saldo_actual: 0, customer: null });
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");
  const [searched, setSearched] = useState(false);

  const inp = { "& .MuiOutlinedInput-root": { backgroundColor: theme.palette.background.paper } };

  // Buscar clientes mientras escribe (debounce simple)
  const handleClienteInputChange = useCallback(async (_, val) => {
    if (!val || val.length < 2) { setClienteOptions([]); return; }
    setClienteLoading(true);
    try {
      const res = await customerService.getCustomers({ search: val, per_page: 30, with_stats: false });
      setClienteOptions(res.data ?? res ?? []);
    } catch {
      setClienteOptions([]);
    } finally {
      setClienteLoading(false);
    }
  }, []);

  const buscar = useCallback(async () => {
    if (!clienteSel) { setError("Seleccioná un cliente"); return; }
    setLoading(true); setError("");
    try {
      const res = await customerService.getCustomerStatement(clienteSel.id, {
        from: desde || undefined,
        to:   hasta || undefined,
      });
      setSummary({
        saldo_anterior: res.saldo_anterior,
        suma_deuda:     res.suma_deuda,
        suma_pagos:     res.suma_pagos,
        saldo_actual:   res.saldo_actual,
        customer:       res.customer,
      });
      setRows(res.data ?? []);
      setSearched(true);
    } catch (e) {
      setError(e?.response?.data?.message || "Error al cargar cuenta corriente");
    } finally {
      setLoading(false);
    }
  }, [clienteSel, desde, hasta]);

  const limpiar = () => {
    setClienteSel(null); setDesde(""); setHasta("");
    setRows([]); setSummary({ saldo_anterior: 0, suma_deuda: 0, suma_pagos: 0, saldo_actual: 0, customer: null });
    setSearched(false); setError("");
  };

  const saldoColor = (s) => s >= 0 ? "#5AAD9C" : "#E63946";

  const columns = [
    {
      field: "fecha", headerName: "Fecha", width: 110,
      renderCell: ({ value }) => (
        <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{value}</Typography>
      ),
    },
    {
      field: "comp", headerName: "Comprobante", width: 130,
      renderCell: ({ value }) => (
        <Chip label={value || "—"} size="small" sx={{ fontWeight: 700, fontSize: "0.68rem", height: 22 }} />
      ),
    },
    { field: "concepto", headerName: "Concepto",   flex: 1, minWidth: 160 },
    { field: "tPago",    headerName: "T.Pago",     width: 120 },
    { field: "dPago",    headerName: "D.Pago",     width: 100 },
    { field: "observ",   headerName: "Observación", flex: 1, minWidth: 140 },
    {
      field: "debe", headerName: "Debe", width: 130,
      renderCell: ({ value }) =>
        value > 0 ? (
          <Typography variant="body2" fontWeight={700} sx={{ color: "#E63946" }}>{formatARS(value)}</Typography>
        ) : <Typography variant="caption" sx={{ color: "text.disabled" }}>—</Typography>,
    },
    {
      field: "haber", headerName: "Haber", width: 130,
      renderCell: ({ value }) =>
        value > 0 ? (
          <Typography variant="body2" fontWeight={700} sx={{ color: "#5AAD9C" }}>{formatARS(value)}</Typography>
        ) : <Typography variant="caption" sx={{ color: "text.disabled" }}>—</Typography>,
    },
    {
      field: "saldo", headerName: "Saldo", width: 140,
      renderCell: ({ value }) => (
        <Typography variant="body2" fontWeight={800} sx={{ color: saldoColor(value) }}>{formatARS(value)}</Typography>
      ),
    },
    { field: "destino", headerName: "Destino", width: 130 },
  ];

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", mb: 3, flexWrap: "wrap", gap: 1 }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Resumen de Cuenta</Typography>
          <Typography variant="body2" sx={{ color: theme.palette.text.secondary, mt: 0.3 }}>
            Estado de cuenta corriente por cliente
          </Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Tooltip title="Imprimir"><IconButton size="small" sx={{ border: `1px solid ${theme.palette.divider}` }}><PrintIcon fontSize="small" /></IconButton></Tooltip>
          <Tooltip title="Enviar por email"><IconButton size="small" sx={{ border: `1px solid ${theme.palette.divider}` }}><EmailIcon fontSize="small" /></IconButton></Tooltip>
          {summary.customer?.phone && (
            <Tooltip title="WhatsApp">
              <IconButton size="small" sx={{ border: `1px solid ${theme.palette.divider}`, color: "#25D366" }}
                onClick={() => window.open(`https://wa.me/${summary.customer.phone.replace(/\D/g, "")}`, "_blank")}>
                <WhatsAppIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          )}
        </Stack>
      </Box>

      {/* Context chips */}
      <Stack direction="row" spacing={1} sx={{ mb: 2.5, flexWrap: "wrap", gap: 1 }}>
        {TIPO_TABS.map((t, i) => (
          <Chip key={t} label={t} onClick={() => setTipoTab(i)} variant={tipoTab === i ? "filled" : "outlined"}
            sx={{ fontWeight: 700, cursor: "pointer",
              ...(tipoTab === i
                ? { background: alpha(theme.palette.primary.main, 0.15), color: theme.palette.primary.main, border: `1px solid ${alpha(theme.palette.primary.main, 0.4)}` }
                : { borderColor: theme.palette.divider }) }} />
        ))}
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Selector */}
      <Paper sx={{ p: { xs: 2, md: 2.5 }, mb: 3, borderLeft: `3px solid ${theme.palette.primary.main}` }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 2, color: theme.palette.primary.main }}>
          Seleccionar cliente y período
        </Typography>
        <Grid container spacing={2} alignItems="flex-end">
          <Grid item xs={12} sm={5} md={4}>
            <Typography variant="caption" sx={{ mb: 0.5, display: "block", color: theme.palette.text.secondary }}>
              Odontólogo / Cliente *
            </Typography>
            <Autocomplete
              options={clienteOptions}
              loading={clienteLoading}
              value={clienteSel}
              onChange={(_, v) => setClienteSel(v)}
              onInputChange={handleClienteInputChange}
              getOptionLabel={(o) => o.name}
              filterOptions={(x) => x}     // filtrado server-side
              noOptionsText="Escribí para buscar…"
              renderInput={(p) => (
                <TextField {...p} size="small" placeholder="Buscar cliente..." sx={inp} />
              )}
              renderOption={(props, o) => (
                <Box component="li" {...props}>
                  <Box>
                    <Typography variant="body2" fontWeight={700}>{o.name}</Typography>
                    <Typography variant="caption" color="text.secondary">{o.tax_id || o.email || "—"}</Typography>
                  </Box>
                </Box>
              )}
            />
          </Grid>
          <Grid item xs={6} sm={3} md={2}>
            <Typography variant="caption" sx={{ mb: 0.5, display: "block", color: theme.palette.text.secondary }}>Desde</Typography>
            <TextField fullWidth size="small" type="date" value={desde} onChange={(e) => setDesde(e.target.value)} sx={inp} />
          </Grid>
          <Grid item xs={6} sm={3} md={2}>
            <Typography variant="caption" sx={{ mb: 0.5, display: "block", color: theme.palette.text.secondary }}>Hasta</Typography>
            <TextField fullWidth size="small" type="date" value={hasta} onChange={(e) => setHasta(e.target.value)} sx={inp} />
          </Grid>
          <Grid item xs={12} sm={12} md={4}>
            <Stack direction="row" spacing={1}>
              <Button variant="contained" startIcon={loading ? <CircularProgress size={15} /> : <SearchIcon />}
                onClick={buscar} disabled={loading}
                sx={{ bgcolor: "#397B9C", "&:hover": { bgcolor: "#49949C" } }}>
                {loading ? "Buscando…" : "Buscar"}
              </Button>
              {searched && (
                <Button variant="outlined" startIcon={<CloseIcon />} onClick={limpiar}>Limpiar</Button>
              )}
            </Stack>
          </Grid>
        </Grid>
      </Paper>

      {/* Summary cards */}
      {searched && !loading && (
        <>
          {/* Nombre del cliente */}
          {summary.customer && (
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle1" fontWeight={700}>
                {summary.customer.name}
                {summary.customer.email && (
                  <Typography component="span" variant="caption" sx={{ ml: 1, color: "text.secondary" }}>
                    {summary.customer.email}
                  </Typography>
                )}
              </Typography>
            </Box>
          )}

          <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5} sx={{ mb: 3 }} flexWrap="wrap" useFlexGap>
            <SummaryCard
              label="Saldo anterior"
              value={summary.saldo_anterior}
              color={saldoColor(summary.saldo_anterior)}
              icon={<ReceiptLongIcon sx={{ fontSize: 16 }} />}
            />
            <SummaryCard
              label="Total debe"
              value={summary.suma_deuda}
              color="#E63946"
              icon={<TrendingDownIcon sx={{ fontSize: 16 }} />}
              sub="Cargos del período"
            />
            <SummaryCard
              label="Suma pagos"
              value={summary.suma_pagos}
              color="#5AAD9C"
              icon={<TrendingUpIcon sx={{ fontSize: 16 }} />}
              sub="Cobros del período"
            />
            <SummaryCard
              label="Saldo actual"
              value={summary.saldo_actual}
              color={saldoColor(summary.saldo_actual)}
              icon={<AccountBalanceWalletIcon sx={{ fontSize: 16 }} />}
              sub={summary.saldo_actual >= 0 ? "A favor" : "Debe"}
            />
          </Stack>

          {/* Grilla de movimientos */}
          <Paper sx={{ p: { xs: 1.5, md: 2 } }}>
            <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
              <Typography variant="subtitle1" fontWeight={700}>Movimientos ({rows.length})</Typography>
              <Stack direction="row" spacing={0.75}>
                {["Imprimir", "Email", "WhatsApp"].map((lbl) => (
                  <Button key={lbl} size="small" variant="outlined"
                    startIcon={lbl === "Imprimir" ? <PrintIcon /> : lbl === "Email" ? <EmailIcon /> : <WhatsAppIcon />}
                    sx={{ fontSize: "0.72rem" }}>
                    {lbl}
                  </Button>
                ))}
              </Stack>
            </Stack>
            <Divider sx={{ mb: 1.5 }} />

            {isXs ? (
              <Stack spacing={1}>
                {rows.map((r) => (
                  <Box key={r.id} sx={{ p: 1.5, border: `1px solid ${theme.palette.divider}`, borderRadius: 2 }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
                      <Box>
                        <Typography variant="body2" fontWeight={700}>{r.concepto}</Typography>
                        <Typography variant="caption" color="text.secondary">{r.fecha} · {r.comp}</Typography>
                      </Box>
                      <Typography variant="body2" fontWeight={800} sx={{ color: saldoColor(r.saldo) }}>
                        {formatARS(r.saldo)}
                      </Typography>
                    </Stack>
                    {(r.debe > 0 || r.haber > 0) && (
                      <Stack direction="row" spacing={2} sx={{ mt: 0.75 }}>
                        {r.debe  > 0 && <Typography variant="caption" sx={{ color: "#E63946" }}>Debe: {formatARS(r.debe)}</Typography>}
                        {r.haber > 0 && <Typography variant="caption" sx={{ color: "#5AAD9C" }}>Haber: {formatARS(r.haber)}</Typography>}
                      </Stack>
                    )}
                  </Box>
                ))}
              </Stack>
            ) : (
              <DataGrid
                rows={rows}
                columns={columns}
                disableRowSelectionOnClick
                density="compact"
                hideFooterSelectedRowCount
                pageSizeOptions={[10, 25, 50]}
                initialState={{ pagination: { paginationModel: { pageSize: 25 } } }}
                sx={{
                  height: 450, border: `1px solid ${theme.palette.divider}`, borderRadius: 2,
                  "& .MuiDataGrid-columnHeaders": { backgroundColor: alpha(theme.palette.primary.main, 0.06) },
                  "& .MuiDataGrid-row:hover":     { backgroundColor: alpha(theme.palette.primary.main, 0.04) },
                  "& .MuiDataGrid-cell":           { borderBottom: `1px solid ${theme.palette.divider}` },
                  "& .MuiDataGrid-footerContainer":{ borderTop: `1px solid ${theme.palette.divider}` },
                }}
              />
            )}
          </Paper>
        </>
      )}

      {/* Estado vacío */}
      {!searched && !loading && (
        <Paper sx={{ py: 8, display: "flex", flexDirection: "column", alignItems: "center", gap: 2, color: "text.secondary" }}>
          <AccountBalanceWalletIcon sx={{ fontSize: 56, opacity: 0.25 }} />
          <Box sx={{ textAlign: "center" }}>
            <Typography fontWeight={700}>Seleccioná un cliente</Typography>
            <Typography variant="body2">Buscar y filtrar por período para ver la cuenta corriente</Typography>
          </Box>
        </Paper>
      )}
    </Box>
  );
}