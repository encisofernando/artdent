// src/scenes/clientes/pagos.jsx
// ✅ Conectado a API real vía customerService
import React, { useEffect, useMemo, useState, useCallback } from "react";
import {
  Box, Grid, Stack, TextField, Typography, Button, Autocomplete,
  InputAdornment, Chip, Paper, Divider, CircularProgress,
  useMediaQuery, useTheme, alpha, Alert, Dialog, DialogTitle,
  DialogContent, DialogActions, FormControl, Select, MenuItem,
  IconButton,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import SearchIcon          from "@mui/icons-material/Search";
import CleaningServicesIcon from "@mui/icons-material/CleaningServices";
import AddCircleIcon       from "@mui/icons-material/AddCircle";
import ContentCopyIcon     from "@mui/icons-material/ContentCopy";
import FileDownloadIcon    from "@mui/icons-material/FileDownload";
import PictureAsPdfIcon    from "@mui/icons-material/PictureAsPdf";
import SaveIcon            from "@mui/icons-material/Save";
import CloseIcon           from "@mui/icons-material/Close";

import customerService from "../../services/customerService";
import ClienteForm     from "./ClienteForm";

const formatARS = (n = 0) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(Number(n) || 0);

const TIPO_TABS  = ["Clínica", "Odontólogo", "Otro Lab", "Colegio"];
const CUENTAS    = ["Caja", "Banco Nación", "Banco Provincia", "Banco Galicia", "Banco Santander"];

// ── Formulario de nuevo cobro/pago ─────────────────────────────────────────
function NuevoCobroDialog({ open, onClose, clientes, onSaved }) {
  const theme = useTheme();
  const [form, setForm] = useState({
    customer_id: "",
    receipt_date: new Date().toISOString().slice(0, 10),
    type: "cobro",
    amount_cash: "",
    amount_transfer: "",
    amount_check: "",
    amount_card: "",
    check_number: "",
    check_bank: "",
    account_name: "",
    reference: "",
    note: "",
  });
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState("");

  const set = (k) => (e) => setForm((p) => ({ ...p, [k]: e.target.value }));

  const total = [form.amount_cash, form.amount_transfer, form.amount_check, form.amount_card]
    .reduce((s, v) => s + (parseFloat(v) || 0), 0);

  const submit = async () => {
    if (!form.customer_id) { setError("Seleccioná un cliente"); return; }
    if (total <= 0) { setError("El total debe ser mayor a cero"); return; }
    setSaving(true); setError("");
    try {
      await customerService.createPayment({
        ...form,
        amount_cash:     parseFloat(form.amount_cash)     || 0,
        amount_transfer: parseFloat(form.amount_transfer) || 0,
        amount_check:    parseFloat(form.amount_check)    || 0,
        amount_card:     parseFloat(form.amount_card)     || 0,
      });
      onSaved();
      onClose();
    } catch (e) {
      setError(e?.response?.data?.message || "Error al guardar");
    } finally {
      setSaving(false);
    }
  };

  const inp = { "& .MuiOutlinedInput-root": { backgroundColor: theme.palette.background.paper } };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Box>
            <Typography fontWeight={800}>Nuevo Cobro / Pago</Typography>
            <Typography variant="caption" color="text.secondary">Registrar comprobante de caja</Typography>
          </Box>
          <IconButton size="small" onClick={onClose}><CloseIcon /></IconButton>
        </Stack>
      </DialogTitle>
      <DialogContent>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        <Grid container spacing={1.5} sx={{ mt: 0.5 }}>
          <Grid item xs={12} sm={8}>
            <Typography variant="caption" color="text.secondary">Cliente *</Typography>
            <Autocomplete
              options={clientes}
              getOptionLabel={(o) => o.name}
              onChange={(_, v) => setForm((p) => ({ ...p, customer_id: v?.id ?? "" }))}
              renderInput={(p) => <TextField {...p} size="small" sx={inp} />}
            />
          </Grid>
          <Grid item xs={6} sm={4}>
            <Typography variant="caption" color="text.secondary">Tipo *</Typography>
            <FormControl fullWidth size="small" sx={inp}>
              <Select value={form.type} onChange={set("type")}>
                <MenuItem value="cobro">Cobro</MenuItem>
                <MenuItem value="pago">Pago</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="caption" color="text.secondary">Fecha *</Typography>
            <TextField fullWidth size="small" type="date" value={form.receipt_date} onChange={set("receipt_date")} sx={inp} InputLabelProps={{ shrink: true }} />
          </Grid>
          <Grid item xs={6}>
            <Typography variant="caption" color="text.secondary">Cuenta destino</Typography>
            <Autocomplete freeSolo options={CUENTAS} value={form.account_name}
              onInputChange={(_, v) => setForm((p) => ({ ...p, account_name: v }))}
              renderInput={(p) => <TextField {...p} size="small" sx={inp} />} />
          </Grid>
          <Grid item xs={6} sm={3}>
            <Typography variant="caption" color="text.secondary">Efectivo</Typography>
            <TextField fullWidth size="small" type="number" value={form.amount_cash} onChange={set("amount_cash")} sx={inp}
              InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment> }} />
          </Grid>
          <Grid item xs={6} sm={3}>
            <Typography variant="caption" color="text.secondary">Transferencia</Typography>
            <TextField fullWidth size="small" type="number" value={form.amount_transfer} onChange={set("amount_transfer")} sx={inp}
              InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment> }} />
          </Grid>
          <Grid item xs={6} sm={3}>
            <Typography variant="caption" color="text.secondary">Cheque</Typography>
            <TextField fullWidth size="small" type="number" value={form.amount_check} onChange={set("amount_check")} sx={inp}
              InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment> }} />
          </Grid>
          <Grid item xs={6} sm={3}>
            <Typography variant="caption" color="text.secondary">Tarjeta</Typography>
            <TextField fullWidth size="small" type="number" value={form.amount_card} onChange={set("amount_card")} sx={inp}
              InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment> }} />
          </Grid>
          {parseFloat(form.amount_check) > 0 && (
            <>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">N° Cheque</Typography>
                <TextField fullWidth size="small" value={form.check_number} onChange={set("check_number")} sx={inp} />
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">Banco</Typography>
                <TextField fullWidth size="small" value={form.check_bank} onChange={set("check_bank")} sx={inp} />
              </Grid>
            </>
          )}
          <Grid item xs={12}>
            <Typography variant="caption" color="text.secondary">Observación</Typography>
            <TextField fullWidth size="small" value={form.note} onChange={set("note")} sx={inp} multiline rows={2} />
          </Grid>
          {total > 0 && (
            <Grid item xs={12}>
              <Paper sx={{ p: 1.5, background: alpha("#5AAD9C", 0.1), border: `1px solid ${alpha("#5AAD9C", 0.3)}` }}>
                <Typography variant="subtitle1" fontWeight={800} sx={{ color: "#5AAD9C" }}>
                  Total: {formatARS(total)}
                </Typography>
              </Paper>
            </Grid>
          )}
        </Grid>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} variant="outlined">Cancelar</Button>
        <Button onClick={submit} variant="contained" disabled={saving} startIcon={<SaveIcon />}
          sx={{ bgcolor: "#397B9C", "&:hover": { bgcolor: "#49949C" } }}>
          {saving ? "Guardando…" : "Guardar"}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ── Main ────────────────────────────────────────────────────────────────────
export default function PagosCte() {
  const theme  = useTheme();
  const isDark = theme.palette.mode === "dark";
  const isXs   = useMediaQuery(theme.breakpoints.down("sm"));

  const [tipoTab, setTipoTab] = useState(0);
  const [rows,    setRows]    = useState([]);
  const [totalFiltrado, setTotalFiltrado] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");
  const [clientes, setClientes] = useState([]);

  // Filtros
  const [cliente,   setCliente]   = useState(null);
  const [formaPago, setFormaPago] = useState(null);
  const [desde,     setDesde]     = useState("");
  const [hasta,     setHasta]     = useState("");
  const [search,    setSearch]    = useState("");

  // Dialogs
  const [openCobro,       setOpenCobro]       = useState(false);
  const [openNuevoCliente, setOpenNuevoCliente] = useState(false);

  const formasPagoOptions = [
    { label: "Efectivo" }, { label: "Transferencia" },
    { label: "Cheque" }, { label: "Tarjeta" }, { label: "Mixto" },
  ];

  // Cargar clientes para selector
  useEffect(() => {
    customerService.getCustomers({ per_page: 200, with_stats: false })
      .then((r) => setClientes(r.data ?? r ?? []))
      .catch(() => setClientes([]));
  }, []);

  const fetchRows = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const res = await customerService.getPayments({
        customer_id:    cliente?.id,
        payment_method: formaPago?.label,
        from:           desde || undefined,
        to:             hasta || undefined,
        search:         search || undefined,
        per_page:       100,
      });
      setRows(res.data?.data ?? res.data ?? []);
      setTotalFiltrado(res.total_filtrado ?? 0);
    } catch (e) {
      setError("Error al cargar pagos");
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [cliente, formaPago, desde, hasta, search]);

  useEffect(() => { fetchRows(); }, [fetchRows]);

  const limpiar = () => {
    setCliente(null); setFormaPago(null);
    setDesde(""); setHasta(""); setSearch("");
  };

  const inp = { "& .MuiOutlinedInput-root": { backgroundColor: theme.palette.background.paper } };

  const columns = [
    { field: "tipo",        headerName: "Tipo",         flex: 0.5, minWidth: 80 },
    { field: "clinica",     headerName: "Cliente",       flex: 1.4, minWidth: 200 },
    { field: "tPago",       headerName: "T.Pago",        flex: 0.8, minWidth: 110 },
    { field: "comp",        headerName: "Comprobante",   flex: 0.8, minWidth: 120 },
    { field: "observacion", headerName: "Observación",   flex: 1.1, minWidth: 150 },
    { field: "cheque",      headerName: "Cheque",        flex: 0.7, minWidth: 100 },
    { field: "fecha",       headerName: "Fecha",         flex: 0.8, minWidth: 110 },
    { field: "efectivo",    headerName: "Efectivo",      flex: 0.9, minWidth: 120, valueFormatter: ({ value }) => formatARS(value) },
    { field: "impCheque",   headerName: "Imp. Cheque",   flex: 0.9, minWidth: 130, valueFormatter: ({ value }) => formatARS(value) },
    { field: "total",       headerName: "Total",         flex: 0.9, minWidth: 120, valueFormatter: ({ value }) => formatARS(value) },
    { field: "usuario",     headerName: "Usuario",       flex: 0.8, minWidth: 110 },
    { field: "cuenta",      headerName: "Cuenta",        flex: 0.9, minWidth: 130 },
  ];

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3, flexWrap: "wrap", gap: 1 }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Pagos de Clientes</Typography>
          <Typography variant="body2" sx={{ color: theme.palette.text.secondary, mt: 0.3 }}>
            Cobros y pagos registrados
          </Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Button variant="contained" color="secondary" startIcon={<AddCircleIcon />}
            onClick={() => setOpenCobro(true)}>
            Nuevo Cobro
          </Button>
          <Button variant="outlined" startIcon={<AddCircleIcon />}
            onClick={() => setOpenNuevoCliente(true)}>
            Nuevo Cliente
          </Button>
        </Stack>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Context tabs */}
      <Stack direction="row" spacing={1} sx={{ mb: 2.5, flexWrap: "wrap", gap: 1 }}>
        {TIPO_TABS.map((t, i) => (
          <Chip key={t} label={t} onClick={() => setTipoTab(i)} variant={tipoTab === i ? "filled" : "outlined"}
            sx={{ fontWeight: 700, cursor: "pointer",
              ...(tipoTab === i ? { background: alpha(theme.palette.primary.main, 0.15), color: theme.palette.primary.main, border: `1px solid ${alpha(theme.palette.primary.main, 0.4)}` }
                : { borderColor: theme.palette.divider }) }} />
        ))}
      </Stack>

      {/* Filtros */}
      <Paper sx={{ p: { xs: 2, md: 2.5 }, mb: 3, borderLeft: `3px solid ${theme.palette.primary.main}` }}>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 2, color: theme.palette.primary.main }}>Filtros</Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="caption" sx={{ mb: 0.5, display: "block", color: theme.palette.text.secondary }}>Cliente / Odontólogo</Typography>
            <Autocomplete options={clientes} getOptionLabel={(o) => o.name}
              value={cliente} onChange={(_, v) => setCliente(v)}
              renderInput={(p) => <TextField {...p} size="small" placeholder="Seleccionar..." sx={inp} />} />
          </Grid>
          <Grid item xs={12} sm={6} md={2}>
            <Typography variant="caption" sx={{ mb: 0.5, display: "block", color: theme.palette.text.secondary }}>Forma de pago</Typography>
            <Autocomplete options={formasPagoOptions} value={formaPago} onChange={(_, v) => setFormaPago(v)}
              renderInput={(p) => <TextField {...p} size="small" placeholder="Todas..." sx={inp} />} />
          </Grid>
          <Grid item xs={6} sm={3} md={2}>
            <Typography variant="caption" sx={{ mb: 0.5, display: "block", color: theme.palette.text.secondary }}>Fecha desde</Typography>
            <TextField fullWidth size="small" type="date" value={desde} onChange={(e) => setDesde(e.target.value)} sx={inp} />
          </Grid>
          <Grid item xs={6} sm={3} md={2}>
            <Typography variant="caption" sx={{ mb: 0.5, display: "block", color: theme.palette.text.secondary }}>Fecha hasta</Typography>
            <TextField fullWidth size="small" type="date" value={hasta} onChange={(e) => setHasta(e.target.value)} sx={inp} />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="caption" sx={{ mb: 0.5, display: "block", color: theme.palette.text.secondary }}>Total filtrado</Typography>
            <TextField fullWidth size="small" value={formatARS(totalFiltrado)}
              InputProps={{ readOnly: true, startAdornment: <InputAdornment position="start"><Typography variant="caption" color="text.secondary">$</Typography></InputAdornment> }}
              sx={{ ...inp, "& .MuiOutlinedInput-root": { backgroundColor: alpha(theme.palette.secondary.main, isDark ? 0.14 : 0.08) } }} />
          </Grid>
          <Grid item xs={12}>
            <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
              <Button variant="contained" startIcon={<SearchIcon />} onClick={fetchRows}>Buscar</Button>
              <Button variant="outlined" startIcon={<CleaningServicesIcon />} onClick={() => { limpiar(); setTimeout(fetchRows, 0); }}>
                Mostrar Todo
              </Button>
            </Stack>
          </Grid>
        </Grid>
      </Paper>

      {/* Resultados */}
      <Paper sx={{ p: { xs: 1.5, md: 2 }, display: "flex", flexDirection: "column" }}>
        <Stack direction={{ xs: "column", sm: "row" }} justifyContent="space-between" alignItems={{ sm: "center" }} gap={1} sx={{ mb: 1.5 }}>
          <Typography variant="subtitle1" fontWeight={700}>Resultados ({rows.length})</Typography>
          <Stack direction="row" spacing={0.75} flexWrap="wrap" useFlexGap>
            {[["Copy", <ContentCopyIcon />], ["Excel", <FileDownloadIcon />], ["CSV", <FileDownloadIcon />], ["PDF", <PictureAsPdfIcon />]].map(([l, icon]) => (
              <Button key={l} size="small" variant="outlined" startIcon={icon} sx={{ fontSize: "0.72rem" }}>{l}</Button>
            ))}
          </Stack>
        </Stack>
        <Divider sx={{ mb: 1.5 }} />
        {loading ? (
          <Box sx={{ display: "grid", placeItems: "center", py: 6 }}>
            <CircularProgress sx={{ color: theme.palette.primary.main }} />
          </Box>
        ) : isXs ? (
          <Stack spacing={1}>
            {rows.map((r) => (
              <Box key={r.id} sx={{ p: 1.5, border: `1px solid ${theme.palette.divider}`, borderRadius: 2 }}>
                <Stack direction="row" justifyContent="space-between">
                  <Box>
                    <Typography variant="body2" fontWeight={700}>{r.clinica}</Typography>
                    <Typography variant="caption" color="text.secondary">{r.fecha} · {r.tPago} · {r.comp}</Typography>
                  </Box>
                  <Typography variant="body2" fontWeight={800} sx={{ color: "#5AAD9C" }}>{formatARS(r.total)}</Typography>
                </Stack>
              </Box>
            ))}
          </Stack>
        ) : (
          <Box sx={{ minHeight: 400 }}>
            <DataGrid rows={rows} columns={columns} disableRowSelectionOnClick density="compact"
              hideFooterSelectedRowCount pageSizeOptions={[10, 25, 50]}
              initialState={{ pagination: { paginationModel: { pageSize: 25 } } }}
              sx={{ height: 450, border: `1px solid ${theme.palette.divider}`, borderRadius: 2,
                "& .MuiDataGrid-columnHeaders": { backgroundColor: alpha(theme.palette.primary.main, 0.06) },
                "& .MuiDataGrid-row:hover": { backgroundColor: alpha(theme.palette.primary.main, 0.05) },
                "& .MuiDataGrid-cell": { borderBottom: `1px solid ${theme.palette.divider}` } }} />
          </Box>
        )}
      </Paper>

      {/* Dialogs */}
      <NuevoCobroDialog
        open={openCobro} onClose={() => setOpenCobro(false)}
        clientes={clientes} onSaved={fetchRows} />

      <ClienteForm
        open={openNuevoCliente}
        onClose={() => setOpenNuevoCliente(false)}
        onCreated={() => { setOpenNuevoCliente(false); fetchRows(); }} />
    </Box>
  );
}