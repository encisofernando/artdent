// src/scenes/clientes/Ficha.jsx
// Perfil completo de cliente — Labs / E-commerce / CRM
import React, { useState } from "react";
import {
  Dialog, DialogContent, DialogTitle, Box, Typography, IconButton,
  Grid, Chip, Tabs, Tab, Button, Table, TableHead, TableBody,
  TableRow, TableCell, Stack, Divider, Avatar, Tooltip, Paper,
  useTheme, useMediaQuery, alpha,
} from "@mui/material";
import CloseIcon       from "@mui/icons-material/Close";
import PrintIcon       from "@mui/icons-material/Print";
import WhatsAppIcon    from "@mui/icons-material/WhatsApp";
import EmailIcon       from "@mui/icons-material/Email";
import EditIcon        from "@mui/icons-material/Edit";
import ScienceIcon     from "@mui/icons-material/Science";
import StorefrontIcon  from "@mui/icons-material/Storefront";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import PersonIcon      from "@mui/icons-material/Person";
import WorkIcon        from "@mui/icons-material/Work";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";

import {
  trabajosByCliente, pedidosByCliente,
  movimientosByCliente, formatARS,
} from "./clientesMock";

/* ── Mini status chip ── */
const StatusChip = ({ label, color }) => (
  <Chip label={label} size="small" sx={{
    background: alpha(color, 0.14),
    color,
    fontWeight: 700,
    fontSize: "0.68rem",
    border: `1px solid ${alpha(color, 0.3)}`,
  }} />
);

/* ── Stat card inside ficha ── */
const StatBox = ({ label, value, color, icon }) => {
  const theme = useTheme();
  return (
    <Paper sx={{
      p: 1.5,
      borderLeft: `3px solid ${color}`,
      background: alpha(color, 0.07),
      display: "flex", flexDirection: "column", gap: 0.3,
    }}>
      <Typography variant="caption" sx={{ color, fontWeight: 700, fontSize: "0.62rem", textTransform: "uppercase", letterSpacing: "0.07em" }}>
        {label}
      </Typography>
      <Typography variant="subtitle1" fontWeight={800} sx={{ color }}>{value}</Typography>
    </Paper>
  );
};

/* ── Datos personales ── */
const TabDatos = ({ c, onEdit }) => {
  const theme = useTheme();
  const fields = [
    { l: "Código",        v: c.code        },
    { l: "CUIT/CUIL",    v: c.tax_id      },
    { l: "Condición IVA", v: c.tax_condition },
    { l: "Email",         v: c.email       },
    { l: "Teléfono",      v: c.phone       },
    { l: "Dirección",     v: c.address     },
    { l: "Ciudad",        v: c.city        },
    { l: "Provincia",     v: c.state       },
    { l: "CP",            v: c.zip         },
    { l: "Límite CC",     v: formatARS(c.credit_limit) },
    ...(c.es_odontologo ? [{ l: "Clínica", v: c.clinica }] : []),
  ];
  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "flex-end", mb: 1.5 }}>
        <Button size="small" variant="outlined" startIcon={<EditIcon />} onClick={onEdit}>
          Editar datos
        </Button>
      </Box>
      <Grid container spacing={1.5}>
        {fields.map(({ l, v }) => (
          <Grid item xs={6} sm={4} key={l}>
            <Typography variant="caption" sx={{
              display: "block", fontWeight: 700, letterSpacing: "0.07em",
              textTransform: "uppercase", fontSize: "0.6rem",
              color: theme.palette.text.secondary,
            }}>
              {l}
            </Typography>
            <Typography variant="body2" fontWeight={600} sx={{ mt: 0.2 }}>{v || "—"}</Typography>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

/* ── Trabajos laboratorio ── */
const TabTrabajos = ({ clienteId }) => {
  const theme = useTheme();
  const rows  = trabajosByCliente(clienteId);
  const estados = {
    "En proceso": "#397B9C",
    "Terminado":  "#5AAD9C",
    "Pendiente":  "#FFB020",
  };
  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1.5 }}>
        <Typography variant="subtitle2" fontWeight={700}>Trabajos de Laboratorio</Typography>
        <Button size="small" variant="contained" startIcon={<WorkIcon sx={{ fontSize: 14 }} />}
          color="primary" sx={{ fontSize: "0.72rem" }}>
          Nuevo Trabajo
        </Button>
      </Box>
      <Paper sx={{ overflow: "hidden" }}>
        <Table size="small">
          <TableHead>
            <TableRow>
              {["Ticket", "Paciente", "Trabajo", "Fecha", "Estado", "Total"].map((h) => (
                <TableCell key={h}>{h}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.id} hover>
                <TableCell>
                  <Chip label={r.ticket} size="small" sx={{
                    background: alpha("#397B9C", 0.15), color: "#397B9C", fontWeight: 700,
                  }} />
                </TableCell>
                <TableCell><Typography variant="body2" fontWeight={500}>{r.paciente}</Typography></TableCell>
                <TableCell><Typography variant="caption">{r.trabajo}</Typography></TableCell>
                <TableCell><Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{r.fecha}</Typography></TableCell>
                <TableCell><StatusChip label={r.estado} color={estados[r.estado] ?? "#FFB020"} /></TableCell>
                <TableCell>
                  <Typography variant="body2" fontWeight={700} sx={{ color: "#5AAD9C" }}>
                    {formatARS(r.total)}
                  </Typography>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
};

/* ── Pedidos e-commerce / insumos ── */
const TabPedidos = ({ clienteId }) => {
  const theme = useTheme();
  const rows  = pedidosByCliente(clienteId);
  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1.5 }}>
        <Typography variant="subtitle2" fontWeight={700}>Pedidos de Insumos</Typography>
        <Button size="small" variant="contained" startIcon={<ShoppingCartIcon sx={{ fontSize: 14 }} />}
          color="secondary" sx={{ fontSize: "0.72rem" }}>
          Nueva Venta
        </Button>
      </Box>
      <Paper sx={{ overflow: "hidden" }}>
        <Table size="small">
          <TableHead>
            <TableRow>
              {["N° Pedido", "Fecha", "Artículos", "Total", "Estado"].map((h) => (
                <TableCell key={h}>{h}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.id} hover>
                <TableCell>
                  <Chip label={r.nro} size="small" sx={{
                    background: alpha("#5AAD9C", 0.15), color: "#5AAD9C", fontWeight: 700,
                  }} />
                </TableCell>
                <TableCell><Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{r.fecha}</Typography></TableCell>
                <TableCell><Typography variant="caption">{r.items}</Typography></TableCell>
                <TableCell>
                  <Typography variant="body2" fontWeight={700} sx={{ color: "#5AAD9C" }}>
                    {formatARS(r.total)}
                  </Typography>
                </TableCell>
                <TableCell>
                  <StatusChip label={r.estado} color="#5AAD9C" />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
};

/* ── Cuenta Corriente ── */
const TabCtaCte = ({ clienteId, saldo }) => {
  const theme = useTheme();
  const rows  = movimientosByCliente(clienteId);
  const saldoColor = saldo >= 0 ? "#5AAD9C" : "#E63946";

  return (
    <Box>
      {/* Summary strip */}
      <Grid container spacing={1.5} sx={{ mb: 2 }}>
        <Grid item xs={6} sm={3}>
          <StatBox label="Saldo actual" value={formatARS(saldo)} color={saldoColor} />
        </Grid>
        <Grid item xs={6} sm={3}>
          <StatBox label="Total debe"
            value={formatARS(rows.reduce((s, r) => s + r.debe, 0))}
            color="#E63946" />
        </Grid>
        <Grid item xs={6} sm={3}>
          <StatBox label="Total haber"
            value={formatARS(rows.reduce((s, r) => s + r.haber, 0))}
            color="#5AAD9C" />
        </Grid>
        <Grid item xs={6} sm={3}>
          <StatBox label="Movimientos" value={rows.length} color="#397B9C" />
        </Grid>
      </Grid>

      <Box sx={{ display: "flex", gap: 1, mb: 1.5, flexWrap: "wrap" }}>
        <Button size="small" variant="outlined"
          startIcon={<PrintIcon sx={{ fontSize: 14 }} />} sx={{ fontSize: "0.72rem" }}>
          Imprimir
        </Button>
        <Button size="small" variant="outlined"
          startIcon={<EmailIcon sx={{ fontSize: 14 }} />} sx={{ fontSize: "0.72rem" }}>
          Email
        </Button>
        <Button size="small" variant="outlined"
          startIcon={<WhatsAppIcon sx={{ fontSize: 14 }} />}
          sx={{ fontSize: "0.72rem", borderColor: alpha("#25D366", 0.5), color: "#25D366" }}>
          WhatsApp
        </Button>
      </Box>

      <Paper sx={{ overflow: "hidden" }}>
        <Table size="small">
          <TableHead>
            <TableRow>
              {["Fecha", "Comprobante", "Concepto", "Debe", "Haber", "Saldo"].map((h) => (
                <TableCell key={h}>{h}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.id} hover>
                <TableCell>
                  <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>{r.fecha}</Typography>
                </TableCell>
                <TableCell>
                  <Chip label={r.comp} size="small" sx={{
                    background: alpha(theme.palette.divider, 1),
                    color: theme.palette.text.secondary, fontWeight: 600, fontSize: "0.65rem",
                  }} />
                </TableCell>
                <TableCell><Typography variant="caption">{r.concepto}</Typography></TableCell>
                <TableCell>
                  {r.debe > 0 ? (
                    <Typography variant="body2" fontWeight={600} sx={{ color: "#E63946" }}>
                      {formatARS(r.debe)}
                    </Typography>
                  ) : "—"}
                </TableCell>
                <TableCell>
                  {r.haber > 0 ? (
                    <Typography variant="body2" fontWeight={600} sx={{ color: "#5AAD9C" }}>
                      {formatARS(r.haber)}
                    </Typography>
                  ) : "—"}
                </TableCell>
                <TableCell>
                  <Typography variant="body2" fontWeight={700}
                    sx={{ color: r.saldo >= 0 ? "#5AAD9C" : "#E63946" }}>
                    {formatARS(r.saldo)}
                  </Typography>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
};

/* ════════════════════════════════════ */
export default function Ficha({ open, onClose, cliente, onEdit }) {
  const theme    = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [tab,    setTab]    = useState(0);

  if (!cliente) return null;

  /* Context tags */
  const tags = [];
  if (cliente.es_odontologo)    tags.push({ label: "Laboratorio",   color: "#397B9C", icon: <ScienceIcon sx={{ fontSize: 13 }} /> });
  if (cliente.es_cliente_insumos) tags.push({ label: "E-commerce",   color: "#5AAD9C", icon: <StorefrontIcon sx={{ fontSize: 13 }} /> });

  /* Avatar initial */
  const initials = (cliente.name || "?")
    .split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase();

  /* Saldo color */
  const saldoColor = cliente.saldo >= 0 ? "#5AAD9C" : "#E63946";

  /* Tabs available */
  const tabList = [
    { label: "Datos",    icon: <PersonIcon sx={{ fontSize: 16 }} /> },
    ...(cliente.es_odontologo ? [{ label: "Trabajos", icon: <WorkIcon sx={{ fontSize: 16 }} /> }] : []),
    ...(cliente.es_cliente_insumos ? [{ label: "Pedidos", icon: <ShoppingCartIcon sx={{ fontSize: 16 }} /> }] : []),
    { label: "Cta. Cte.", icon: <AccountBalanceWalletIcon sx={{ fontSize: 16 }} /> },
  ];

  /* Map visible tab index to component */
  const tabContent = [
    <TabDatos key="datos" c={cliente} onEdit={onEdit} />,
    ...(cliente.es_odontologo ? [<TabTrabajos key="trab" clienteId={cliente.id} />] : []),
    ...(cliente.es_cliente_insumos ? [<TabPedidos key="ped" clienteId={cliente.id} />] : []),
    <TabCtaCte key="cta" clienteId={cliente.id} saldo={cliente.saldo} />,
  ];

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      fullScreen={isMobile}
      PaperProps={{ sx: { borderRadius: isMobile ? 0 : 3, maxHeight: "90vh" } }}
    >
      {/* ── Header ── */}
      <DialogTitle sx={{
        pb: 0,
        borderBottom: `1px solid ${theme.palette.divider}`,
      }}>
        <Box sx={{ display: "flex", alignItems: "flex-start", gap: 2, pb: 2 }}>
          {/* Avatar */}
          <Avatar sx={{
            width: 52, height: 52,
            background: "linear-gradient(135deg, #397B9C, #5AAD9C)",
            fontSize: 20, fontWeight: 800,
            flexShrink: 0,
          }}>
            {initials}
          </Avatar>

          {/* Info */}
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1, flexWrap: "wrap" }}>
              <Typography variant="h6" fontWeight={800} sx={{ lineHeight: 1.2 }}>
                {cliente.name}
              </Typography>
              {tags.map((t) => (
                <Chip
                  key={t.label}
                  icon={t.icon}
                  label={t.label}
                  size="small"
                  sx={{
                    background: alpha(t.color, 0.14),
                    color: t.color,
                    fontWeight: 700,
                    border: `1px solid ${alpha(t.color, 0.3)}`,
                    "& .MuiChip-icon": { color: t.color },
                  }}
                />
              ))}
              <Chip
                label={cliente.is_active ? "Activo" : "Inactivo"}
                size="small"
                sx={{
                  background: alpha(cliente.is_active ? "#5AAD9C" : "#666", 0.14),
                  color: cliente.is_active ? "#5AAD9C" : "#999",
                  fontWeight: 700,
                  border: `1px solid ${alpha(cliente.is_active ? "#5AAD9C" : "#666", 0.3)}`,
                }}
              />
            </Box>

            <Typography variant="caption" sx={{ color: theme.palette.text.secondary, mt: 0.4, display: "block" }}>
              {[cliente.code, cliente.tax_id, cliente.clinica].filter(Boolean).join(" · ")}
            </Typography>

            {/* Quick stats strip */}
            <Stack direction="row" spacing={2} sx={{ mt: 1, flexWrap: "wrap", gap: 1 }}>
              {cliente.es_odontologo && (
                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                  <WorkIcon sx={{ fontSize: 13, color: "#397B9C" }} />
                  <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>
                    <strong style={{ color: "#397B9C" }}>{cliente.trabajos_pendientes}</strong> pend. · {cliente.trabajos_total} total
                  </Typography>
                </Box>
              )}
              {cliente.es_cliente_insumos && (
                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                  <StorefrontIcon sx={{ fontSize: 13, color: "#5AAD9C" }} />
                  <Typography variant="caption" sx={{ color: theme.palette.text.secondary }}>
                    <strong style={{ color: "#5AAD9C" }}>{cliente.pedidos_total}</strong> pedidos
                  </Typography>
                </Box>
              )}
              <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                <AccountBalanceWalletIcon sx={{ fontSize: 13, color: saldoColor }} />
                <Typography variant="caption" sx={{ color: saldoColor, fontWeight: 700 }}>
                  {formatARS(cliente.saldo)}
                </Typography>
              </Box>
            </Stack>
          </Box>

          {/* Actions + close */}
          <Stack direction="row" spacing={0.5} sx={{ flexShrink: 0, alignItems: "center" }}>
            <Tooltip title="WhatsApp">
              <IconButton size="small" sx={{ color: "#25D366" }}>
                <WhatsAppIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            <Tooltip title="Enviar email">
              <IconButton size="small">
                <EmailIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            <IconButton size="small" onClick={onClose}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Stack>
        </Box>

        {/* Tabs */}
        <Tabs
          value={tab}
          onChange={(_, v) => setTab(v)}
          variant="scrollable"
          scrollButtons="auto"
          sx={{
            minHeight: 40,
            "& .MuiTab-root": { minHeight: 40, py: 0.5, fontSize: "0.78rem", fontWeight: 700, textTransform: "none" },
            "& .Mui-selected": { color: theme.palette.primary.main },
            "& .MuiTabs-indicator": { backgroundColor: theme.palette.primary.main },
          }}
        >
          {tabList.map((t, i) => (
            <Tab key={i} label={t.label} icon={t.icon} iconPosition="start" />
          ))}
        </Tabs>
      </DialogTitle>

      {/* ── Tab content ── */}
      <DialogContent sx={{ pt: 2.5 }}>
        {tabContent[tab]}
      </DialogContent>
    </Dialog>
  );
}