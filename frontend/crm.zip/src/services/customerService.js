// src/services/customerService.js
/**
 * ══════════════════════════════════════════════════════════════════════════════
 * ARTDENT — Servicio de Clientes
 * ══════════════════════════════════════════════════════════════════════════════
 *
 * Centraliza TODOS los llamados a la API del módulo Clientes:
 *  - CRUD de clientes
 *  - KPIs del hub
 *  - Pagos / cobros (pagos.jsx)
 *  - Estado de cuenta / cuenta corriente (resumen_cta.jsx)
 *
 * Requiere: src/services/api.js  (instancia axios con baseURL y token)
 * ══════════════════════════════════════════════════════════════════════════════
 */

import api from "./api";

// ── Helpers ────────────────────────────────────────────────────────────────

/**
 * Limpia los parámetros: elimina claves undefined, null y string vacío.
 */
const clean = (params = {}) =>
  Object.fromEntries(
    Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== "")
  );

// ══════════════════════════════════════════════════════════════════════════════
// CLIENTES — CRUD
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Listado paginado de clientes.
 *
 * @param {Object} params
 * @param {string}  params.search         — búsqueda libre
 * @param {string}  params.context        — todos | lab | ecommerce
 * @param {string}  params.estado         — todos | activos | inactivos
 * @param {boolean} params.with_stats     — incluir stats de trabajos y pedidos (default true)
 * @param {number}  params.page
 * @param {number}  params.per_page
 *
 * @returns {Promise<{ data: Customer[], meta: PaginationMeta }>}
 */
export const getCustomers = async (params = {}) => {
  const res = await api.get("/customers", { params: clean(params) });
  return res.data;
};

/**
 * Obtiene un cliente por ID con stats completos.
 * @returns {Promise<Customer>}
 */
export const getCustomer = async (id) => {
  const res = await api.get(`/customers/${id}`);
  return res.data;
};

/**
 * Crea un nuevo cliente.
 *
 * @param {Object} payload
 * @param {string}  payload.name               * requerido
 * @param {string}  [payload.code]
 * @param {string}  [payload.tax_id]
 * @param {string}  [payload.tax_condition]     consumidor_final | responsable_inscripto | monotributista | exento
 * @param {string}  [payload.email]
 * @param {string}  [payload.phone]
 * @param {string}  [payload.address]
 * @param {string}  [payload.city]
 * @param {string}  [payload.state]
 * @param {string}  [payload.zip]
 * @param {number}  [payload.credit_limit]
 * @param {boolean} [payload.is_active]         default true
 * @param {boolean} [payload.es_odontologo]      default false
 * @param {boolean} [payload.es_cliente_insumos] default true
 * @param {string}  [payload.clinica]
 * @param {number}  [payload.dentist_id]
 *
 * @returns {Promise<Customer>}
 */
export const createCustomer = async (payload) => {
  const res = await api.post("/customers", payload);
  return res.data;
};

/**
 * Actualiza un cliente existente.
 * @param {number} id
 * @param {Object} payload  — mismos campos que createCustomer
 * @returns {Promise<Customer>}
 */
export const updateCustomer = async (id, payload) => {
  const res = await api.put(`/customers/${id}`, payload);
  return res.data;
};

/**
 * Elimina (soft delete) un cliente.
 * @returns {Promise<void>}
 */
export const deleteCustomer = async (id) => {
  await api.delete(`/customers/${id}`);
};

// ══════════════════════════════════════════════════════════════════════════════
// CLIENTES — KPIs del hub
// ══════════════════════════════════════════════════════════════════════════════

/**
 * KPI cards del hub de clientes.
 * @returns {Promise<{ total, lab, ecomm, pendientes, facturacion }>}
 */
export const getCustomerKpis = async () => {
  const res = await api.get("/customers/kpis");
  return res.data;
};

// ══════════════════════════════════════════════════════════════════════════════
// PAGOS / COBROS  (pagos.jsx)
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Listado paginado de comprobantes de cobro/pago.
 *
 * @param {Object} params
 * @param {number}  [params.customer_id]
 * @param {string}  [params.type]            cobro | pago
 * @param {string}  [params.payment_method]  Efectivo | Transferencia | Cheque | Tarjeta | Mixto
 * @param {string}  [params.from]            YYYY-MM-DD
 * @param {string}  [params.to]              YYYY-MM-DD
 * @param {string}  [params.search]
 * @param {number}  [params.per_page]
 *
 * @returns {Promise<{ data: { data: Receipt[], ... }, total_filtrado: number }>}
 */
export const getPayments = async (params = {}) => {
  const res = await api.get("/customers/payments", { params: clean(params) });
  return res.data;
};

/**
 * Registra un nuevo cobro o pago.
 *
 * @param {Object} payload
 * @param {number}  payload.customer_id         * requerido
 * @param {string}  payload.receipt_date         YYYY-MM-DD  * requerido
 * @param {string}  payload.type                 cobro | pago  * requerido
 * @param {number}  [payload.amount_cash]        parte en efectivo
 * @param {number}  [payload.amount_transfer]    parte en transferencia
 * @param {number}  [payload.amount_check]       parte en cheque
 * @param {number}  [payload.amount_card]        parte en tarjeta
 * @param {string}  [payload.check_number]
 * @param {string}  [payload.check_bank]
 * @param {string}  [payload.check_due_date]     YYYY-MM-DD
 * @param {string}  [payload.account_name]       Caja | Banco Nación | etc.
 * @param {string}  [payload.reference]          N° de transferencia u otro ref externo
 * @param {string}  [payload.note]               Observación libre
 *
 * @returns {Promise<Receipt>}
 */
export const createPayment = async (payload) => {
  const res = await api.post("/customers/payments", payload);
  return res.data;
};

/**
 * Anula (soft delete + contra-asiento) un comprobante de pago.
 * @returns {Promise<void>}
 */
export const deletePayment = async (id) => {
  await api.delete(`/customers/payments/${id}`);
};

// ══════════════════════════════════════════════════════════════════════════════
// CUENTA CORRIENTE  (resumen_cta.jsx)
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Estado de cuenta de un cliente con detalle de movimientos.
 *
 * @param {number} customerId
 * @param {Object} [params]
 * @param {string}  [params.from]  YYYY-MM-DD  — inicio del período
 * @param {string}  [params.to]    YYYY-MM-DD  — fin del período
 *
 * @returns {Promise<{
 *   customer:        { id, name, email, phone },
 *   saldo_anterior:  number,
 *   suma_pagos:      number,
 *   suma_deuda:      number,
 *   saldo_actual:    number,
 *   data: Array<{
 *     id, fecha, comp, concepto, tPago, dPago, observ,
 *     debe, haber, saldo, destino
 *   }>
 * }>}
 */
export const getCustomerStatement = async (customerId, params = {}) => {
  const res = await api.get(`/customers/${customerId}/statement`, {
    params: clean(params),
  });
  return res.data;
};

/**
 * Solo el saldo actual de un cliente (sin el detalle completo).
 * @param {number} customerId
 * @returns {Promise<{ saldo: number }>}
 */
export const getCustomerBalance = async (customerId) => {
  const res = await api.get(`/customers/${customerId}/statement/summary`);
  return res.data;
};

// ══════════════════════════════════════════════════════════════════════════════
// EXPORTS nombrados (para uso selectivo)
// ══════════════════════════════════════════════════════════════════════════════

const customerService = {
  // Clientes
  getCustomers,
  getCustomer,
  createCustomer,
  updateCustomer,
  deleteCustomer,
  getCustomerKpis,
  // Pagos
  getPayments,
  createPayment,
  deletePayment,
  // Cuenta corriente
  getCustomerStatement,
  getCustomerBalance,
};

export default customerService;