// src/components/ToothSelector.jsx
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Box, Typography, Tooltip, Chip, IconButton, alpha, useTheme,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { useState } from "react";
import { coloresDentales, upperTeeth, lowerTeeth } from "../utils/trabajosData";

/* ── Una pieza dental ── */
const ToothButton = ({ number, selected, onClick }) => {
  const theme  = useTheme();
  const isDark = theme.palette.mode === "dark";
  const front  = [11, 12, 13, 21, 22, 23, 31, 32, 33, 41, 42, 43].includes(number);

  return (
    <Tooltip title={`Pieza ${number}`} arrow>
      <Box
        onClick={() => onClick(number)}
        sx={{
          width:   { xs: 26, sm: 32 },
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "3px",
          cursor: "pointer",
          userSelect: "none",
          "&:hover .tooth-body": { transform: "scale(1.18)" },
        }}
      >
        <Box className="tooth-body" sx={{
          width:  { xs: 18, sm: 24 },
          height: { xs: 22, sm: 28 },
          borderRadius: front ? "40% 40% 35% 35%" : "28%",
          background: selected
            ? `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`
            : isDark ? "linear-gradient(135deg, #2e4a5a, #1d3644)" : "linear-gradient(135deg, #d4e8f0, #b8d4e2)",
          border: `2px solid ${selected ? theme.palette.primary.main : alpha(theme.palette.primary.main, 0.3)}`,
          boxShadow: selected ? `0 0 10px ${alpha(theme.palette.primary.main, 0.45)}` : "none",
          transition: "all .2s ease",
          flexShrink: 0,
        }} />
        <Typography sx={{
          fontSize:   "0.58rem",
          fontWeight: selected ? 700 : 500,
          color:      selected ? theme.palette.primary.main : theme.palette.text.secondary,
          lineHeight: 1,
        }}>
          {number}
        </Typography>
      </Box>
    </Tooltip>
  );
};

/* ════════════════════════════════════ */
export default function ToothSelector({ open, onClose, onSave, initialTeeth = [], initialColor = "A3" }) {
  const theme  = useTheme();

  const [selected, setSelected] = useState(initialTeeth);
  const [color,    setColor]    = useState(initialColor);

  const toggle = (n) =>
    setSelected((prev) => prev.includes(n) ? prev.filter((t) => t !== n) : [...prev, n]);

  const handleSave = () => {
    const label = selected.length > 0
      ? `PD ${selected.sort((a, b) => a - b).join(", ")} Color ${color}`
      : "";
    onSave(label, [...selected], color);
    onClose();
  };

  const handleClear = () => { setSelected([]); setColor("A3"); };

  const Arcade = ({ label, teeth }) => (
    <Box sx={{ mb: 2 }}>
      <Typography variant="caption" sx={{
        display: "block", textAlign: "center", mb: 1,
        fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase",
        color: theme.palette.text.secondary, fontSize: "0.65rem",
      }}>
        {label}
      </Typography>
      <Box sx={{
        display: "flex", justifyContent: "center",
        gap: { xs: 0.3, sm: 0.5 },
        overflowX: "auto", pb: 0.5,
      }}>
        {teeth.map((n) => (
          <ToothButton key={n} number={n} selected={selected.includes(n)} onClick={toggle} />
        ))}
      </Box>
    </Box>
  );

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth
      PaperProps={{ sx: { borderRadius: 3 } }}>
      <DialogTitle sx={{ pb: 1, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Typography variant="h6" fontWeight={700}>Seleccionar Dientes</Typography>
        <IconButton size="small" onClick={onClose}><CloseIcon fontSize="small" /></IconButton>
      </DialogTitle>

      <DialogContent sx={{ pb: 1 }}>
        {/* Counter + clear */}
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
          <Chip label={`Seleccionados: ${selected.length}`} size="small" sx={{
            background: alpha(theme.palette.primary.main, 0.15),
            color: theme.palette.primary.main, fontWeight: 700,
            border: `1px solid ${alpha(theme.palette.primary.main, 0.3)}`,
          }} />
          {selected.length > 0 && (
            <Button size="small" onClick={handleClear}
              sx={{ color: theme.palette.text.secondary, fontSize: "0.75rem" }}>
              Limpiar
            </Button>
          )}
        </Box>

        <Arcade label="Arcada Superior" teeth={upperTeeth} />
        <Arcade label="Arcada Inferior" teeth={lowerTeeth} />

        {/* Selected chips */}
        {selected.length > 0 && (
          <Box sx={{ display: "flex", gap: 0.5, flexWrap: "wrap", mb: 2 }}>
            {[...selected].sort((a, b) => a - b).map((n) => (
              <Chip key={n} label={n} size="small" onDelete={() => toggle(n)}
                sx={{
                  background: theme.palette.primary.main, color: "#fff",
                  "& .MuiChip-deleteIcon": { color: "rgba(255,255,255,.7)" },
                  fontWeight: 700,
                }}
              />
            ))}
          </Box>
        )}

        {/* Color picker */}
        <Box>
          <Typography variant="caption" sx={{
            display: "block", textAlign: "center", mb: 1.5,
            fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase",
            color: theme.palette.text.secondary, fontSize: "0.65rem",
          }}>
            Color de la pieza dental
          </Typography>
          {/* Labels row */}
          <Box sx={{ display: "flex", justifyContent: "center", gap: { xs: 0.7, sm: 1.1 }, flexWrap: "wrap", mb: 0.5 }}>
            {coloresDentales.map((c) => (
              <Typography key={c.label} sx={{
                width: { xs: 22, sm: 28 }, textAlign: "center", fontSize: "0.58rem",
                fontWeight: color === c.label ? 800 : 400,
                color: color === c.label ? theme.palette.primary.main : theme.palette.text.secondary,
              }}>
                {c.label}
              </Typography>
            ))}
          </Box>
          {/* Swatches */}
          <Box sx={{ display: "flex", justifyContent: "center", gap: { xs: 0.7, sm: 1.1 }, flexWrap: "wrap" }}>
            {coloresDentales.map((c) => (
              <Tooltip key={c.label} title={c.label} arrow>
                <Box onClick={() => setColor(c.label)} sx={{
                  width: { xs: 22, sm: 28 }, height: { xs: 22, sm: 28 },
                  borderRadius: "7px", background: c.code,
                  border: color === c.label
                    ? `3px solid ${theme.palette.primary.main}`
                    : `2px solid ${alpha(theme.palette.divider, 0.5)}`,
                  cursor: "pointer",
                  boxShadow: color === c.label ? `0 0 8px ${alpha(theme.palette.primary.main, 0.5)}` : "none",
                  transition: "all .15s ease",
                  "&:hover": { transform: "scale(1.2)", borderColor: theme.palette.secondary.main },
                }} />
              </Tooltip>
            ))}
          </Box>
          {color && (
            <Typography variant="caption" sx={{
              display: "block", textAlign: "center", mt: 1,
              color: theme.palette.primary.main, fontWeight: 700,
            }}>
              Color seleccionado: {color}
            </Typography>
          )}
        </Box>
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} variant="outlined">Cerrar</Button>
        <Button onClick={handleSave} variant="contained" disabled={selected.length === 0}>
          Guardar
        </Button>
      </DialogActions>
    </Dialog>
  );
}