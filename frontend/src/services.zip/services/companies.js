import api from "./api";
import { unwrap } from "./utils";

// Obtiene la empresa actual asociada al usuario autenticado
// Preferido: /companies/me (backend nuevo)
// Fallback: /company (legacy)
export const get = async () => {
  try {
    return await unwrap(api.get("/companies/me"));
  } catch (e) {
    // si el backend no tiene /companies/me
    return await unwrap(api.get("/company"));
  }
};
