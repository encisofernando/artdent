<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RoleMiddleware
{
    public function handle(Request $request, Closure $next, ...$roles)
    {
        $user = $request->user();
        if (!$user) {
            return response()->json(['message' => 'Unauthenticated'], 401);
        }

        // If no role constraint, allow.
        if (empty($roles)) {
            return $next($request);
        }

        // Normalize roles
        $wanted = array_map(fn($r) => strtolower(trim($r)), $roles);

        try {
            $userRoles = DB::table('roles')
                ->join('role_user', 'roles.id', '=', 'role_user.role_id')
                ->where('role_user.user_id', $user->id)
                ->pluck('roles.name')
                ->map(fn($n) => strtolower(trim($n)))
                ->toArray();

            foreach ($wanted as $r) {
                if (in_array($r, $userRoles, true)) {
                    return $next($request);
                }
            }
        } catch (\Throwable $e) {
            // If roles tables are missing for some reason, fail closed unless it's clearly the admin user.
            if (strtolower($user->email ?? '') === 'admin@artdent.com.ar' || (int)($user->id ?? 0) === 1) {
                return $next($request);
            }
        }

        return response()->json(['message' => 'Forbidden'], 403);
    }
}
