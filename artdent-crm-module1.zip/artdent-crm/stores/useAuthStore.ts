import { create } from "zustand";
import { persist } from "zustand/middleware";
import { clearAuth } from "@/lib/auth";

interface User {
  id?:     number | string;
  name?:   string;
  email?:  string;
  role?:   string;
  [key: string]: unknown;
}

interface AuthState {
  isAuthenticated: boolean;
  token:           string | null;
  user:            User | null;

  setAuth:   (token: string, user?: User) => void;
  setUser:   (user: User) => void;
  logout:    () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isAuthenticated: false,
      token:           null,
      user:            null,

      setAuth: (token, user) => {
        localStorage.setItem("token", token);
        if (user) localStorage.setItem("user", JSON.stringify(user));
        set({ isAuthenticated: true, token, user: user ?? null });
      },

      setUser: (user) => set({ user }),

      logout: () => {
        clearAuth();
        set({ isAuthenticated: false, token: null, user: null });
      },
    }),
    {
      name: "artdent-auth",
      // Solo persiste el booleano + user; el token ya va a localStorage vía setAuth
      partialize: (state) => ({
        isAuthenticated: state.isAuthenticated,
        user:            state.user,
      }),
    }
  )
);
