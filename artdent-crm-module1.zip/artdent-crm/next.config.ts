import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "artdent.com.ar" },
    ],
  },
  // Permite importar SVG como componentes React si hace falta en el futuro
  // webpack(config) {
  //   config.module.rules.push({ test: /\.svg$/, use: ["@svgr/webpack"] });
  //   return config;
  // },
};

export default nextConfig;
