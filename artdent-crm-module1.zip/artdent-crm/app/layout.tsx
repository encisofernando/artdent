import type { Metadata } from "next";
import { Toaster } from "react-hot-toast";
import { ThemeProvider } from "@/components/providers/ThemeProvider";
import "./globals.css";

export const metadata: Metadata = {
  title:       "ARTDENT CRM",
  description: "Sistema de gestión clínica ARTDENT",
  icons:       { icon: "/favicon.ico" },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body>
        <ThemeProvider>
          {children}
          <Toaster
            position="top-right"
            toastOptions={{
              style: {
                background:  "hsl(var(--card))",
                color:       "hsl(var(--card-foreground))",
                border:      "1px solid hsl(var(--border))",
                borderRadius:"var(--radius)",
                fontSize:    "0.875rem",
              },
            }}
          />
        </ThemeProvider>
      </body>
    </html>
  );
}
