"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import Sidebar from "@/components/layout/Sidebar";
import Topbar  from "@/components/layout/Topbar";
import { useSidebarStore, SIDEBAR_WIDTH, COLLAPSED_WIDTH } from "@/stores/useSidebarStore";
import { useAuthStore } from "@/stores/useAuthStore";
import { isTokenValid } from "@/lib/auth";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router        = useRouter();
  const isAuthed      = useAuthStore((s) => s.isAuthenticated);
  const { isCollapsed } = useSidebarStore();

  // Guard client-side (refuerzo al middleware)
  useEffect(() => {
    if (!isAuthed || !isTokenValid()) {
      router.replace("/login");
    }
  }, [isAuthed, router]);

  const sidebarW = isCollapsed ? COLLAPSED_WIDTH : SIDEBAR_WIDTH;

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Topbar  />
      <main
        className="pt-16 transition-all duration-300"
        style={{ marginLeft: sidebarW }}
      >
        {/* En mobile el sidebar es un drawer, no desplaza el contenido */}
        <div className="md:hidden" style={{ marginLeft: 0 }} />

        <div className="p-4 md:p-6 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
