# ARTDENT CRM — Next.js + shadcn/ui + Tailwind CSS

## Stack
- **Next.js 15** (App Router)
- **React 19**
- **TypeScript**
- **Tailwind CSS 3** + **shadcn/ui**
- **Zustand** (estado global — reemplaza Redux)
- **next-themes** (dark/light toggle)
- **Axios** (HTTP client)
- **react-hot-toast** (notificaciones)

---

## Setup rápido

```bash
# 1. Instalar dependencias
npm install

# 2. Variables de entorno
cp .env.local.example .env.local
# Editar NEXT_PUBLIC_API_URL si hace falta

# 3. Instalar componentes shadcn (una vez, según vayas necesitando)
npx shadcn@latest init          # (ya configurado en components.json)
npx shadcn@latest add button input label dialog select tooltip badge avatar

# 4. Dev server
npm run dev
```

---

## Estructura — Módulo 1 (Auth + Layout Shell)

```
app/
├── layout.tsx                  ← Root (ThemeProvider + Toaster)
├── globals.css                 ← Tokens CSS + Tailwind
├── (auth)/
│   ├── layout.tsx
│   ├── login/page.tsx          ✅ Migrado
│   ├── register/page.tsx       ✅ Migrado
│   └── crearcontrasena/page.tsx ✅ Migrado
└── (dashboard)/
    ├── layout.tsx              ✅ Shell con Sidebar + Topbar
    └── page.tsx                ← Placeholder (próximos módulos)

components/
├── providers/
│   └── ThemeProvider.tsx       ✅ next-themes
└── layout/
    ├── Sidebar.tsx             ✅ Migrado — colapsable + mobile drawer
    └── Topbar.tsx              ✅ Migrado — dark toggle + API status

stores/
├── useAuthStore.ts             ✅ Zustand (reemplaza Redux auth)
└── useSidebarStore.ts          ✅ Zustand (reemplaza SidebarContext)

lib/
├── api.ts                      ✅ Axios (reemplaza src/services/api.js)
├── auth.ts                     ✅ JWT helpers (reemplaza src/auth/auth.js)
└── utils.ts                    ✅ cn() helper

services/
├── authService.ts              ✅ Migrado a TypeScript
├── utils.ts                    ✅ unwrap + toQueryString
└── index.ts                    ✅ Barrel (resto comentado, agregar por módulo)

middleware.ts                   ✅ Auth guard (reemplaza ProtectedRoute)
```

---

## Próximos módulos

- **Módulo 2**: Dashboard (KPIs, gráficos Nivo)
- **Módulo 3**: Clientes (tabla, ficha, cta. corriente, pagos)
- **Módulo 4**: Facturación / POS
- **Módulo 5**: Artículos + Categorías
- **Módulo 6**: Proveedores
- **Módulo 7**: Team + Colaboradores
- **Módulo 8**: Trabajos (SelectorDientes SVG)
- **Módulo 9**: Settings + Profile

---

## Notas de migración

### MUI → Tailwind/shadcn

| MUI | Equivalente |
|-----|-------------|
| `<Box sx={{...}}>` | `<div className="...">` |
| `<Typography variant="h4">` | `<h4 className="text-xl font-semibold">` |
| `<TextField>` | `<Input>` (shadcn) |
| `<Button variant="contained">` | `<Button>` (shadcn) |
| `<Dialog>` | `<Dialog>` (shadcn) |
| `<DataGrid>` | `<DataTable>` (shadcn) |
| `useTheme()` + `tokens()` | CSS variables + `useTheme()` de next-themes |
| `ThemeProvider` | `ThemeProvider` (next-themes) |
| `ColorModeContext` | `useTheme()` de next-themes |

### Redux → Zustand
- `useSelector` → `useStore((s) => s.campo)`
- `useDispatch` + `action` → `useStore((s) => s.accion)()`
