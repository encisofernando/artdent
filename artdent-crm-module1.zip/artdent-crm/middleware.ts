import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

/** Rutas públicas que NO requieren autenticación */
const PUBLIC_PATHS = ["/login", "/register", "/crearcontrasena", "/forgot"];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Dejar pasar assets y rutas internas de Next.js
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api") ||
    pathname.includes(".")
  ) {
    return NextResponse.next();
  }

  const isPublic  = PUBLIC_PATHS.some((p) => pathname.startsWith(p));
  // El token viaja en cookies cuando se usa SSR; si no, el store de Zustand (client-side) se encarga.
  const token =
    request.cookies.get("token")?.value ||
    request.cookies.get("artdent_token")?.value;

  if (!isPublic && !token) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("from", pathname);
    return NextResponse.redirect(url);
  }

  if (isPublic && token && pathname === "/login") {
    const url = request.nextUrl.clone();
    url.pathname = "/";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
