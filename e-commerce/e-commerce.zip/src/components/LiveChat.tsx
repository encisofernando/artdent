// src/components/LiveChat.tsx

import { useEffect } from 'react'

// Declaración global para que TypeScript conozca los objetos de Tawk
declare global {
  interface Window {
    Tawk_API?: any
    Tawk_LoadStart?: Date
  }
}

export default function LiveChat() {
  useEffect(() => {
    const propertyId = import.meta.env.VITE_TAWK_PROPERTY_ID?.trim()
    const widgetId   = import.meta.env.VITE_TAWK_WIDGET_ID?.trim()

    if (!propertyId || !widgetId) {
      console.warn('[LiveChat] Faltan variables de entorno: VITE_TAWK_PROPERTY_ID o VITE_TAWK_WIDGET_ID')
      return
    }

    // Evitamos duplicados
    if (document.getElementById('tawk-script')) {
      console.log('[LiveChat] Script de Tawk ya está cargado')
      return
    }

    console.log('[LiveChat] Cargando widget nativo de Tawk.to →', { propertyId, widgetId })

    const script = document.createElement('script')
    script.id = 'tawk-script'
    script.async = true
    script.src = `https://embed.tawk.to/${propertyId}/${widgetId}`
    script.charset = 'UTF-8'
    script.crossOrigin = '*'

    script.onload = () => {
      console.log('[LiveChat] Script de Tawk.to cargado → botón nativo debería aparecer')
    }

    script.onerror = (err) => {
      console.error('[LiveChat] Error al cargar script de Tawk.to:', err)
    }

    document.body.appendChild(script)

    // Inicializamos los objetos globales (Tawk los usa y expande)
    window.Tawk_API = window.Tawk_API || {}
    window.Tawk_LoadStart = new Date()

    // No llamamos hideWidget() ni nada → dejamos que Tawk maneje el botón nativo y todo el comportamiento

  }, [])

  // No renderizamos nada → Tawk inserta su botón flotante automáticamente
  return null
}