import { Link } from 'react-router-dom'
import logoBlanco from '../assets/logo-blanco.png'
import NewsletterSubscribe from '../components/NewsletterSubscribe'

export default function Footer() {
  return (
    <footer className="mt-16" style={{ background: 'var(--brand-primary)' }}>
      <div className="mx-auto max-w-6xl px-4 py-10 text-white">
        {/* Newsletter Section */}
        <div className="mb-10 border-b border-white/20 pb-10">
          <div className="max-w-2xl mx-auto">
            <NewsletterSubscribe variant="footer" />
          </div>
        </div>

        {/* Footer Content */}
        <div className="grid gap-8 md:grid-cols-4">
          <div>
            <img src={logoBlanco} alt="ARTDENT" className="h-10 w-auto" />
            <p className="mt-3 text-sm/6 text-white/90">
              Tu sonrisa, es nuestra prioridad. El arte de crear para toda la vida.
            </p>
          </div>
          
          <div>
            <p className="text-sm font-semibold">E-commerce</p>
            <ul className="mt-3 space-y-2 text-sm text-white/90">
              <li>
                <Link to="/productos" className="hover:text-white transition">
                  Catálogo
                </Link>
              </li>
              <li>
                <Link to="/comparar" className="hover:text-white transition">
                  Comparar productos
                </Link>
              </li>
              <li>
                <Link to="/promociones" className="hover:text-white transition">
                  Promociones
                </Link>
              </li>
              <li>
                <Link to="/novedades" className="hover:text-white transition">
                  Novedades
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <p className="text-sm font-semibold">Empresa</p>
            <ul className="mt-3 space-y-2 text-sm text-white/90">
              <li>
                <Link to="/nosotros" className="hover:text-white transition">
                  Quiénes somos
                </Link>
              </li>
              <li>
                <Link to="/contacto" className="hover:text-white transition">
                  Contacto
                </Link>
              </li>
              <li>
                <Link to="/politicas" className="hover:text-white transition">
                  Políticas
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <p className="text-sm font-semibold">Soporte</p>
            <ul className="mt-3 space-y-2 text-sm text-white/90">
              <li>
                <Link to="/ayuda" className="hover:text-white transition">
                  Ayuda
                </Link>
              </li>
              <li>
                <Link to="/devoluciones" className="hover:text-white transition">
                  Devoluciones
                </Link>
              </li>
              <li>
                <Link to="/facturacion" className="hover:text-white transition">
                  Facturación
                </Link>
              </li>
              <li>
                <Link to="/mi-cuenta" className="hover:text-white transition">
                  Mi cuenta
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-10 border-t border-white/20 pt-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="text-xs text-white/80">
            © {new Date().getFullYear()} ARTDENT. Todos los derechos reservados.
          </div>
          
          <div className="flex items-center gap-4 text-xs text-white/80">
            <Link to="/terminos" className="hover:text-white transition">
              Términos y condiciones
            </Link>
            <Link to="/privacidad" className="hover:text-white transition">
              Privacidad
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}