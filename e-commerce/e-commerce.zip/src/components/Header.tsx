import { Link, NavLink, useNavigate } from 'react-router-dom'
import { ShoppingCart, User } from 'lucide-react'
import { useAuth } from '../store/auth'
import { useCart } from '../store/cart'
import logoAzul from '../assets/logo-azul.png'
import AdvancedSearch from '../components/AdvancedSearch'

function navClass({ isActive }: { isActive: boolean }) {
  return [
    'text-sm font-semibold transition',
    isActive ? 'text-[var(--brand-primary)]' : 'text-gray-700 hover:text-[var(--brand-primary)]'
  ].join(' ')
}

export default function Header() {
  const { user, isAuthenticated, signOut } = useAuth()
  const cart = useCart()
  const navigate = useNavigate()
  const count = cart.items.reduce((acc, it) => acc + (it.qty || 0), 0)

  return (
    <header className="sticky top-0 z-50 border-b bg-white/80 backdrop-blur">
      <div className="mx-auto max-w-7xl px-4 py-3">
        {/* Primera fila: Logo + Búsqueda + Acciones */}
        <div className="grid grid-cols-[auto,1fr,auto] items-center gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 shrink-0">
            <img src={logoAzul} alt="ARTDENT" className="h-9 w-auto" />
          </Link>

          {/* Búsqueda Avanzada - Responsive */}
          <div className="hidden md:flex justify-center">
            <div className="w-full max-w-2xl">
            <AdvancedSearch 
              onSearch={(query) => navigate(`/productos?q=${encodeURIComponent(query)}`)}
            />
            </div>
          </div>

          {/* Botones de acción */}
          <div className="flex items-center gap-2 shrink-0">
            <Link to="/carrito" className="btn btn-outline">
              <ShoppingCart size={18} />
              <span className="hidden sm:inline">Carrito</span>
              {count > 0 && (
                <span className="ml-2 rounded-full bg-[var(--brand-primary)] px-2 py-0.5 text-xs font-bold text-white">
                  {Math.round(count)}
                </span>
              )}
            </Link>

            {isAuthenticated ? (
              <button
                className="btn btn-primary"
                onClick={() => signOut()}
                title={user ? `Salir (${user.email})` : 'Salir'}
              >
                <User size={18} />
                <span className="hidden sm:inline">Salir</span>
              </button>
            ) : (
              <Link to="/iniciar-sesion" className="btn btn-primary">
                <User size={18} />
                <span className="hidden sm:inline">Iniciar sesión</span>
              </Link>
            )}
          </div>
        </div>

        {/* Segunda fila: Navegación + Búsqueda móvil */}
        <div className="mt-3 flex flex-col gap-3 md:flex-row md:items-center md:justify-center">
          {/* Navegación */}
          <nav className="flex items-center gap-6 md:mx-auto">
            <NavLink to="/" className={navClass}>Inicio</NavLink>
            <NavLink to="/productos" className={navClass}>Productos</NavLink>
            <NavLink to="/comparar" className={navClass}>Comparar</NavLink>
            <NavLink to="/mi-cuenta" className={navClass}>Mi cuenta</NavLink>
          </nav>

          {/* Búsqueda móvil */}
          <div className="md:hidden">
            <AdvancedSearch 
              onSearch={(query) => navigate(`/productos?q=${encodeURIComponent(query)}`)}
            />
          </div>
        </div>
      </div>
    </header>
  )
}