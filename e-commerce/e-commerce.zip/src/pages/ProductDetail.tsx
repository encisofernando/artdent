import { useQuery } from '@tanstack/react-query'
import { useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Share2 } from 'lucide-react'
import { getProduct } from '../api/products'
import { useCart } from '../store/cart'
import ProductReviews from '../components/ProductReviews'
import WishlistButton from '../components/WishlistButton'
import SEOHead from '../components/SEOHead'
import { analytics } from '../api/analytics'

export default function ProductDetail() {
  const params = useParams()
  const id = Number(params.id)

  const productQuery = useQuery({
    queryKey: ['product', id],
    queryFn: () => getProduct(id),
    enabled: Number.isFinite(id) && id > 0,
  })

  const cart = useCart()
  const p = productQuery.data

  const images = useMemo(() => {
    const list = (p?.images || []).slice().sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0))
    if (list.length) return list
    if (p?.primary_image_url) return [{ id: 0, url: p.primary_image_url, alt: p.name, is_primary: true }]
    return []
  }, [p])

  const [activeUrl, setActiveUrl] = useState<string | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [showShareToast, setShowShareToast] = useState(false)
  
  const mainUrl = activeUrl ?? images.find(i => i.is_primary)?.url ?? images[0]?.url ?? null

  // Track product view when data loads
  useMemo(() => {
    if (p) {
      analytics.viewProduct({
        id: p.id,
        name: p.name,
        price: Number(p.price_final ?? p.price ?? 0),
        category: p.category?.name,
        brand: 'ARTDENT',
      })
    }
  }, [p])

  const handleAddToCart = () => {
    if (p) {
      cart.add(p, quantity)
      
      // Track add to cart
      analytics.addToCart({
        id: p.id,
        name: p.name,
        price: Number(p.price_final ?? p.price ?? 0),
        quantity: quantity,
        category: p.category?.name,
      })
    }
  }

  const handleShare = async () => {
    const url = window.location.href
    const text = `${p?.name} - ARTDENT`

    if (navigator.share) {
      try {
        await navigator.share({ title: text, url })
      } catch (err) {
        copyToClipboard(url)
      }
    } else {
      copyToClipboard(url)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setShowShareToast(true)
    setTimeout(() => setShowShareToast(false), 2000)
  }

  if (productQuery.isLoading) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-10">
        <div className="animate-pulse space-y-6">
          <div className="h-8 w-32 bg-gray-200 rounded"></div>
          <div className="grid gap-6 lg:grid-cols-2">
            <div className="h-96 bg-gray-200 rounded-2xl"></div>
            <div className="space-y-4">
              <div className="h-8 bg-gray-200 rounded"></div>
              <div className="h-12 bg-gray-200 rounded"></div>
              <div className="h-32 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (productQuery.isError || !p) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-10">
        <div className="card p-8 text-center">
          <p className="text-lg font-semibold text-red-600">No se pudo cargar el producto.</p>
          <p className="mt-2 text-sm text-gray-600">Verifica sesión, CORS y la URL del backend.</p>
          <Link to="/productos" className="mt-6 inline-block btn btn-primary">
            Volver al catálogo
          </Link>
        </div>
      </div>
    )
  }

  const price = Number(p.price_final ?? p.price ?? 0)
  const hasStock = (p.stock ?? 0) > 0
  const availability = hasStock ? 'InStock' : 'OutOfStock'

  return (
    <>
      {/* SEO Head - Optimización para buscadores */}
      <SEOHead
        title={p.name}
        description={p.description || `${p.name} - Productos dentales profesionales en ARTDENT`}
        keywords={[p.category?.name, 'dental', 'odontología', p.name, 'ARTDENT'].filter(Boolean)}
        image={mainUrl || undefined}
        url={`/productos/${p.id}`}
        type="product"
        productData={{
          name: p.name,
          price: price,
          currency: 'ARS',
          availability: availability,
          brand: 'ARTDENT',
          sku: p.sku,
          image: mainUrl || undefined,
          rating: p.average_rating,
          reviewCount: p.review_count,
        }}
        breadcrumbs={[
          { name: 'Inicio', url: '/' },
          { name: 'Productos', url: '/productos' },
          ...(p.category ? [{ name: p.category.name, url: `/categoria/${p.category.id}` }] : []),
          { name: p.name, url: `/productos/${p.id}` },
        ]}
      />

      <div className="mx-auto max-w-6xl px-4 py-10">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
          <Link to="/" className="hover:text-[var(--brand-primary)]">Inicio</Link>
          <span>/</span>
          <Link to="/productos" className="hover:text-[var(--brand-primary)]">Productos</Link>
          {p.category && (
            <>
              <span>/</span>
              <Link to={`/categoria/${p.category.id}`} className="hover:text-[var(--brand-primary)]">
                {p.category.name}
              </Link>
            </>
          )}
          <span>/</span>
          <span className="font-semibold text-gray-900">{p.name}</span>
        </div>

        {/* Product Grid */}
        <div className="grid gap-8 lg:grid-cols-2">
          {/* Images */}
          <div className="space-y-4">
            <div className="card p-4">
              <div className="relative h-96 rounded-2xl border bg-white overflow-hidden" style={{ borderColor: 'var(--border)' }}>
                {mainUrl ? (
                  <img src={mainUrl} alt={p.name} className="h-full w-full object-contain" />
                ) : (
                  <div className="h-full w-full grid place-items-center">
                    <span className="text-sm text-gray-500">Sin imagen</span>
                  </div>
                )}
              </div>

              {images.length > 1 && (
                <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
                  {images.map((img) => (
                    <button
                      key={img.id}
                      type="button"
                      className={`h-20 w-20 shrink-0 overflow-hidden rounded-xl border-2 transition ${
                        mainUrl === img.url 
                          ? 'border-[var(--brand-primary)] ring-2 ring-[var(--brand-primary)]/20' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setActiveUrl(img.url)}
                      aria-label="Cambiar imagen"
                    >
                      <img 
                        src={img.url} 
                        alt={img.alt || p.name} 
                        className="h-full w-full object-cover" 
                        loading="lazy" 
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  {p.category && (
                    <Link 
                      to={`/categoria/${p.category.id}`}
                      className="text-xs font-semibold text-[var(--brand-primary)] hover:underline"
                    >
                      {p.category.name}
                    </Link>
                  )}
                  <h1 className="mt-2 text-3xl font-bold">{p.name}</h1>
                  <p className="mt-1 text-sm text-gray-600">SKU: {p.sku || '—'}</p>
                </div>

                {/* Botones de acción */}
                <div className="flex gap-2">
                  <WishlistButton productId={p.id} />
                  <button
                    onClick={handleShare}
                    className="rounded-xl border-2 border-gray-300 p-2 hover:border-[var(--brand-primary)] hover:text-[var(--brand-primary)] transition"
                    title="Compartir"
                  >
                    <Share2 size={20} />
                  </button>
                </div>
              </div>

              {/* Reviews Summary */}
              {p.review_count > 0 && (
                <div className="mt-3 flex items-center gap-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <svg
                        key={star}
                        className={`h-5 w-5 ${
                          star <= Math.round(p.average_rating || 0)
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'text-gray-300'
                        }`}
                        viewBox="0 0 20 20"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  <span className="text-sm text-gray-600">
                    {p.average_rating?.toFixed(1)} ({p.review_count} {p.review_count === 1 ? 'valoración' : 'valoraciones'})
                  </span>
                </div>
              )}
            </div>

            {/* Price */}
            <div className="card p-6">
              <div className="flex items-end justify-between">
                <div>
                  <p className="text-sm text-gray-600">Precio</p>
                  <p className="text-4xl font-bold">${price.toLocaleString('es-AR')}</p>
                  <p className="mt-1 text-xs text-gray-500">IVA {Number(p.tax_rate || 0)}% incluido</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-600">Stock</p>
                  <p className={`text-lg font-bold ${hasStock ? 'text-green-600' : 'text-red-600'}`}>
                    {hasStock ? `${p.stock} disponibles` : 'Sin stock'}
                  </p>
                </div>
              </div>
            </div>

            {/* Product Details */}
            <div className="card p-6">
              <h3 className="font-bold mb-4">Detalles del producto</h3>
              <div className="grid gap-3 text-sm">
                <div className="flex items-center justify-between border-b pb-2">
                  <span className="text-gray-600">Unidad</span>
                  <span className="font-semibold">{p.unit || 'UN'}</span>
                </div>
                <div className="flex items-center justify-between border-b pb-2">
                  <span className="text-gray-600">Código de barras</span>
                  <span className="font-semibold">{p.barcode || '—'}</span>
                </div>
                <div className="flex items-center justify-between border-b pb-2">
                  <span className="text-gray-600">Estado</span>
                  <span className={`font-semibold ${p.is_active ? 'text-green-600' : 'text-red-600'}`}>
                    {p.is_active ? 'Activo' : 'Inactivo'}
                  </span>
                </div>
              </div>
            </div>

            {/* Add to Cart */}
            <div className="card p-6">
              <div className="flex items-center gap-4">
                <div>
                  <label className="text-xs font-semibold text-gray-600 block mb-2">Cantidad</label>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="rounded-xl border-2 px-4 py-2 font-bold hover:bg-gray-50"
                      disabled={quantity <= 1}
                    >
                      −
                    </button>
                    <span className="w-12 text-center font-bold">{quantity}</span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="rounded-xl border-2 px-4 py-2 font-bold hover:bg-gray-50"
                      disabled={!hasStock || quantity >= (p.stock || 0)}
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="flex-1">
                  <label className="text-xs font-semibold text-gray-600 block mb-2">&nbsp;</label>
                  <button
                    className="btn btn-primary w-full"
                    onClick={handleAddToCart}
                    disabled={!hasStock}
                  >
                    {hasStock ? 'Agregar al carrito' : 'Sin stock'}
                  </button>
                </div>
              </div>

              <p className="mt-4 text-xs text-gray-500">
                Checkout real: se crea un pedido (orden + ítems) en el backend.
              </p>
            </div>
          </div>
        </div>

        {/* Description */}
        {p.description && (
          <div className="mt-8 card p-8">
            <h2 className="text-xl font-bold mb-4">Descripción</h2>
            <p className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">
              {p.description}
            </p>
          </div>
        )}

        {/* Reviews Section - Sistema completo de valoraciones */}
        <div className="mt-8">
          <ProductReviews productId={p.id} />
        </div>

        {/* Share Toast */}
        {showShareToast && (
          <div className="fixed bottom-4 right-4 z-50 rounded-xl bg-green-600 px-6 py-3 text-white shadow-lg">
            ¡Enlace copiado al portapapeles!
          </div>
        )}
      </div>
    </>
  )
}