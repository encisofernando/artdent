import { http, Paginated } from './http'

export type Product = {
  id: number
  company_id: number
  category_id: number | null
  sku: string | null
  barcode: string | null
  name: string
  description: string | null
  unit: string | null
  cost: number
  price: number
  tax_rate: number
  tax_id: number | null
  is_active: boolean
  track_stock: boolean
  min_stock: number
}

export type PricingInfo = {
  mode: 'b2c' | 'b2b'
  base: number
  discount_percent: number
  final: number
}

export type CatalogProduct = Product & {
  pricing?: PricingInfo
  price_final?: number
  price_mode?: 'b2c' | 'b2b'
  primary_image_url?: string | null
  images?: Array<{ id: number; url: string; alt?: string | null; sort_order?: number; is_primary?: boolean }>
}

export type StockSummary = {
  product_id: number
  warehouse_id: number
  quantity: number
}

export async function listProducts(params: { q?: string; page?: number; category_id?: number; per_page?: number; company_id?: number } = {}): Promise<Paginated<CatalogProduct>> {
  const { data } = await http.get('/catalog/products', { params })
  return data
}

export async function getProduct(id: number, params: { company_id?: number } = {}): Promise<CatalogProduct> {
  const { data } = await http.get(`/catalog/products/${id}`, { params })
  return data
}

export async function getProductStock(id: number): Promise<any> {
  const { data } = await http.get(`/products/${id}/stock`)
  return data
}
